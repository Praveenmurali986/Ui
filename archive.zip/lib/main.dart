import 'package:flutter/material.dart';
import 'package:login_signup_page/autosar_chat_app/ChatScreen/chat_layout.dart';
import 'package:login_signup_page/autosar_chat_app/ChatScreen/provider.dart';
import 'package:login_signup_page/autosar_chat_app/MainScreen/ArchitectureAutosar.dart';
import 'package:login_signup_page/norms_analyzer/ChatScreen/provider.dart';
import 'home_app/pages/login.dart';
import 'home_app/pages/home_page.dart';
import 'package:provider/provider.dart';
 

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => SelectedItemProvider()),
        ChangeNotifierProvider(create: (_) => SelectedVersionProvider()),
 
      ],
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    return MaterialApp(
      title: 'LILA Acsia Copilot',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      // home: LoginScreen(), // Set LoginScreen as the home screen
      // home: AcsiaHomePage(screenWidth: screenWidth,screenHeight: screenHeight,),
      home: LoginScreen(),

      routes: {
        '/first': (context) => const MyHomePage(),
        '/second': (context) => const ChatLayout(),
      },
    );
  }
}