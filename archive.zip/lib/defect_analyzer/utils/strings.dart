class ApiConfig {
  static const String baseUrl = 'http://172.18.14.2:8800/analyze_ticket';
  static const String apiKey = 'your_api_key_here';
  // static const String dataEndpoint = '/data';"http://172.30.8.202:8800
  // static const String authEndpoint = '/auth';
}