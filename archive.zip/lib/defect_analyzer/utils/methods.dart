// lib/utils/methods.dart

import 'dart:async';
import 'dart:typed_data';
import 'dart:convert';
import 'package:login_signup_page/defect_analyzer/pages/full_screen_page.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:file_picker/file_picker.dart';
import 'dart:html' as html;

String comparisonResult='';

String formatElapsedTime(int seconds) {
  if (seconds < 60) {
    return '$seconds s';
  } else if (seconds < 3600) {
    int minutes = seconds ~/ 60;
    int remainingSeconds = seconds % 60;
    return '${minutes}m ${remainingSeconds}s';
  } else {
    int hours = seconds ~/ 3600;
    int minutes = (seconds % 3600) ~/ 60;
    int remainingSeconds = seconds % 60;
    return '${hours}h ${minutes}m ${remainingSeconds}s';
  }
}



// Future<String?> compareFiles(
//   BuildContext context,
//   Function setState,
//   Uint8List? _fileBytes1,
//   String? _fileName1,
//   bool _isLoading,
//   int _elapsedTime,
//   String comparisonResult
// ) async {
//   if (_fileBytes1 == null) {
//     ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
//       content: Text('Please select both files to compare.'),
//     ));
//     return null;
//   }

//   setState(() {
//     _isLoading = true;
//     _elapsedTime = 0;
//   });

//   Timer? _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
//     setState(() {
//       _elapsedTime++;
//     });
//   });

//   var request = http.MultipartRequest('POST', Uri.parse('http://172.30.8.209:8080/doc-compare/'));
//   request.files.add(http.MultipartFile.fromBytes('file1', _fileBytes1!, filename: _fileName1));
//   request.headers.addAll({'accept': 'application/json'});

//   try {
//     var response = await request.send();
//     if (response.statusCode == 200) {
//       String result = await response.stream.bytesToString();
//       Map<String, dynamic> jsonResponse = jsonDecode(result);
//       var comparisonValue = jsonResponse['comparison'];

//       setState(() {
//         comparisonResult = comparisonValue;
//         _isLoading = false;
//       });

//       _timer?.cancel();

//       // Return the comparison result
//       return comparisonResult;  // This will return the comparison result
//     } else {
//       throw Exception('Failed to compare files: ${response.statusCode}');
//     }
//   } catch (e) {
//     setState(() {
//       _isLoading = false;
//     });
//     _timer?.cancel();
//     ScaffoldMessenger.of(context).showSnackBar(SnackBar(
//       content: Text('Error: $e'),
//     ));
//     return null;  // In case of error, return null
//   }
// }


// void showFullscreenResult(String comparisonResult, BuildContext context) {
//     if (comparisonResult.isEmpty) {
//       ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
//         content: Text('No comparison result to display.'),
//       ));
//       return;
//     }

//     Navigator.push(
//       context,
//       MaterialPageRoute(
//         builder: (context) => MarkdownDisplayPage(markdownData: comparisonResult),
//       ),
//     );
//   }


//   // Method to download the comparison result as a text file
//   void downloadComparisonResult(BuildContext context, String comparisonResult,Uint8List? _fileBytes1,
//   Uint8List? _fileBytes2,
//   String? _fileName1,
//   String? _fileName2,) async {
//   if (comparisonResult.isEmpty) {
//     ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
//       content: Text('No comparison result to download.'),
//     ));
//     return;
//   }

//   // Show dialog to choose file format
//   final result = await showDialog<String>(
//     context: context,
//     builder: (context) {
//       return AlertDialog(
//         title: Text('Choose file format'),
//         actions: [
//           TextButton(
//             onPressed: () {
//               Navigator.of(context).pop('text');
//             },
//             child: Text('Text File'),
//           ),
//           TextButton(
//             onPressed: () {
//               Navigator.of(context).pop('excel');
//             },
//             child: Text('Excel File'),
//           ),
//         ],
//       );
//     },
//   );

//   if (result == 'text') {
//     // Download as Text File
//     final blob = html.Blob([comparisonResult], 'text/plain', 'native');
//     final url = html.Url.createObjectUrlFromBlob(blob);
//     final anchor = html.AnchorElement(href: url)
//       ..target = 'blank'
//       ..setAttribute('download', 'comparison_result.txt')
//       ..click();
//     html.Url.revokeObjectUrl(url);
//   } else if (result == 'excel') {
//     // Download Excel File by sending HTTP request
//     var request = http.MultipartRequest('GET', Uri.parse('http://172.30.8.209:8080/download_xl/'));

//     // Assuming you need to send the files again for comparison or additional data
//     request.files.add(http.MultipartFile.fromBytes('file1', _fileBytes1!, filename: _fileName1));
//     request.files.add(http.MultipartFile.fromBytes('file2', _fileBytes2!, filename: _fileName2));
//     request.headers.addAll({'accept': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}); // Ensure the server knows you want Excel.

//     try {
//       // Send the request and get the response
//       var response = await request.send();
//       if (response.statusCode == 200) {
//         // Read the bytes of the Excel file from the response
//         final bytes = await response.stream.toBytes();

//         // Create a Blob from the bytes
//         final blob = html.Blob([bytes], 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'native');
        
//         // Create a download URL for the Blob
//         final url = html.Url.createObjectUrlFromBlob(blob);
        
//         // Create an anchor element to trigger the download
//         final anchor = html.AnchorElement(href: url)
//           ..target = 'blank'
//           ..setAttribute('download', 'comparison_result.xlsx')
//           ..click();

//         // Revoke the object URL to release memory
//         html.Url.revokeObjectUrl(url);
//       } else {
//         // Handle the case where the server response is not 200 OK
//         throw Exception('Failed to download Excel file: ${response.statusCode}');
//       }
//     } catch (e) {
//       ScaffoldMessenger.of(context).showSnackBar(SnackBar(
//         content: Text('Error: $e'),
//       ));
//     }
//   }
// }

// Future<void> downloadPPT(
//   BuildContext context,
//   Uint8List? fileBytes,
//   String? fileName,
// ) async {
//   if (fileBytes != null) {
//     try {
//       var request = http.MultipartRequest(
//         'POST', Uri.parse('http://172.30.8.209:8080/ppt/')
//       );

//       // Add the file bytes and file name
//       request.files.add(http.MultipartFile.fromBytes('xl_file', fileBytes, filename: fileName));
//       request.headers.addAll({'accept': 'application/vnd.openxmlformats-officedocument.presentationml.presentation'});
      
//       var response = await request.send();

//       if (response.statusCode == 200) {
//         // Await the response stream to get the bytes of the PPTX file
//         final bytes = await response.stream.toBytes();

//         // Create a Blob from the PPTX bytes
//         final blob = html.Blob([bytes], 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'native');

//         // Create a download URL for the Blob
//         final url = html.Url.createObjectUrlFromBlob(blob);

//         // Create an anchor element to trigger the download
//         final anchor = html.AnchorElement(href: url)
//           ..target = 'blank'
//           ..setAttribute('download', 'presentation.pptx')  // Ensure file is downloaded as .pptx
//           ..click();

//         // Revoke the object URL to release memory
//         html.Url.revokeObjectUrl(url);
//       } else {
//         throw Exception('Failed to download PPTX file: ${response.statusCode}');
//       }
//     } catch (e) {
//       ScaffoldMessenger.of(context).showSnackBar(SnackBar(
//         content: Text('Error: $e'),
//       ));
//     }
//   } else {
//     ScaffoldMessenger.of(context).showSnackBar(SnackBar(
//       content: Text('Please select a file first.'),
//     ));
//   }
// }


// Future<void> pickFile(int fileNumber) async {
//   FilePickerResult? result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);

//   if (result != null && result.files.isNotEmpty) {
//     final platformFile = result.files.single;
//     if (platformFile.bytes != null) {
//       setState(() {
//         if (fileNumber == 1) {
//           _fileBytes1 = platformFile.bytes;
//           _fileName1 = platformFile.name;  // Store file name for file 1
//         } else if (fileNumber == 2) {
//           _fileBytes2 = platformFile.bytes;
//           _fileName2 = platformFile.name;  // Store file name for file 2
//         }
//       });
//     } else {
//       ScaffoldMessenger.of(widget.context).showSnackBar(const SnackBar(
//         content: Text('File selected, but bytes are not available.'),
//       ));
//     }
//   } else {
//     ScaffoldMessenger.of(widget.context).showSnackBar(const SnackBar(
//       content: Text('No file selected. Please try again.'),
//     ));
//   }
// }
