import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:login_signup_page/defect_analyzer/utils/app_colors.dart'; // Import colors from app_colors.dart
import 'dart:async';
import 'dart:typed_data';
import 'dart:convert';
import 'package:login_signup_page/defect_analyzer/utils/methods.dart';
import 'package:http/http.dart' as http;
import 'dart:html' as html;
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:login_signup_page/defect_analyzer/pages/full_screen_page.dart';
import 'package:login_signup_page/defect_analyzer/utils/strings.dart';

class TabContent extends StatefulWidget {
  final TabController tabController;
  final double screenWidth;
  final double screenHeight;
  final BuildContext context;

  TabContent({
    required this.context,
    required this.tabController,
    required this.screenWidth,
    required this.screenHeight,
  });

  @override
  State<TabContent> createState() => _TabContentState();
}

class _TabContentState extends State<TabContent> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  // TextEditingController _controller = TextEditingController();
  // FocusNode _focusNode = FocusNode();

  bool _isLoading = false;
  Timer? _timer;
  int _elapsedTime = 0;
  bool _isResultGenerated = false;
  String reportResult = '';
  String ticketSummary = '';
  String defectSolution = '';
  String similarDefectDescription = '';
  String resultSimilarIssues = '';
  String resultSummary = '';
  String resultSolutionFromComments = '';
  final FocusNode _focusNodeTicketNo = FocusNode();
  final TextEditingController _controllerTicketNo = TextEditingController();

  Future<void> analyseDefect() async {
    // Check if a file is selected

    if (_isLoading) {
      ScaffoldMessenger.of(widget.context).showSnackBar(
        SnackBar(content: Text("Generation in progress. Please wait.")),
      );
      return; // Exit the function if a download is already in progress
    }

    setState(() {
      _isLoading = true;
    });

    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _elapsedTime++;
      });
    });

    // Construct the URL dynamically using the text from the controller
    String dynamicContext = Uri.encodeQueryComponent(_controllerTicketNo.text);
    var url = Uri.parse(ApiConfig.baseUrl);

    // Create a JSON payload with the ticket number
    var payload = {'ticket_number': _controllerTicketNo.text};

    // Convert the payload to a JSON string
    var jsonPayload = jsonEncode(payload);

    try {
      // Send the request
      // Send the request
      var response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'accept': 'application/json'
        },
        body: jsonPayload,
      );
      // Check if the server responded successfully
      if (response.statusCode == 200) {
        // print(response.body);
        String result = await response.body;
        // print(result);
        Map<String, dynamic> jsonResponse = jsonDecode(result);
        print(jsonResponse);
        var summary = jsonResponse['summary'];
        var similar_issues = jsonResponse['similar_issues'];
        var solution_from_comments = jsonResponse['solution_from_comments'];

        setState(() {
          reportResult = result;
          resultSimilarIssues = similar_issues;
          resultSolutionFromComments = solution_from_comments;
          resultSummary = summary;
          _isLoading = false;
          _isResultGenerated = true;
        });
      } else {
        throw Exception('Failed to generate result: ${response.statusCode}');
      }
    } catch (e) {
      print(e);
      setState(() {
        _isLoading = false;
      });
      _timer?.cancel();

      // Show error message
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Error: $e'),
      ));
    }
  }

// logic for downloading the file
  void downloadComparisonResult(int value) {
    if (value == 1) {
      print("downloadComparisonResult1");
      if (reportResult.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('No generated result to download.'),
        ));
        return;
      } else {
        // Download as Text File
        final blob = html.Blob([reportResult], 'text/plain', 'native');
        final url = html.Url.createObjectUrlFromBlob(blob);
        final anchor = html.AnchorElement(href: url)
          ..target = 'blank'
          ..setAttribute('download', 'generated_rules.txt')
          ..click();
        html.Url.revokeObjectUrl(url);
      }
    } else if (value == 2) {
      print("downloadComparisonResult2");
      if (reportResult.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('No report generated to download.'),
        ));
        return;
      } else {
        // Download as csv File
        final blob = html.Blob([reportResult], 'text/plain', 'native');
        final url = html.Url.createObjectUrlFromBlob(blob);
        final anchor = html.AnchorElement(href: url)
          ..target = 'blank'
          ..setAttribute('download', 'generated_report.csv')
          ..click();
        html.Url.revokeObjectUrl(url);
      }
    }
  }

  @override
  void dispose() {
    _focusNodeTicketNo
        .dispose(); // Dispose the focus node when the widget is disposed
    super.dispose();
  }

  void showFullscreenResult(int value) {
    if (value == 1) {
      if (reportResult.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('No generated result to display.'),
        ));
        return;
      }

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) =>
              MarkdownDisplayPage(markdownData: reportResult, type: "rule"),
        ),
      );
    } else if (value == 2) {
      if (reportResult.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('No report generated to display.'),
        ));
        return;
      }

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => MarkdownDisplayPage(
            markdownData: reportResult,
            type: "report",
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: TabBarView(
        controller: widget.tabController,
        children: [
// Content for Option 1 - PCAP Rule Generation
          Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                // First box inside the content for Option 1 with decoration
                Container(
                  width: widget.screenWidth * 0.25,
                  height: widget.screenHeight * 0.77,
                  decoration: BoxDecoration(
                    color: AppColors.appBarBackground, // Box color
                    borderRadius: BorderRadius.all(
                        Radius.circular(15)), // Rounded corners
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(16), // Add padding inside the box
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment
                          .center, // Center the buttons inside the box
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Stack(
                          children: [
                            // ElevatedButton
                            // Replace ElevatedButton with Container
                            Container(
                              width: widget.screenWidth * 0.23,
                              height: widget.screenHeight * 0.5,
                              decoration: BoxDecoration(
                                color: Colors
                                    .white, // Background color of the container
                                borderRadius: BorderRadius.circular(
                                    15), // Rounded corners
                              ),
                              child: Stack(
                                children: [
                                  // Image at the center
                                  Positioned(
                                    top: widget.screenHeight *
                                        0.014, // 8px from the top edge
                                    left: widget.screenWidth *
                                        0.014, // 8px from the left edge
                                    child: Text(
                                      _controllerTicketNo.text.isEmpty
                                          ? "Enter Ticket No"
                                          : "Ticket No: ${_controllerTicketNo.text}", // Dynamic text change  // Text at the top-left corner
                                      style: TextStyle(
                                        color: const Color.fromARGB(
                                            210, 50, 54, 58),
                                        fontSize: widget.screenWidth * 0.0095,
                                        fontWeight: FontWeight.w100,
                                      ),
                                    ),
                                  ),

                                  // Editable Text Field below the text
                                  Positioned(
                                    top: widget.screenHeight * 0.37,
                                    left: widget.screenWidth * 0.015,
                                    right: widget.screenWidth * 0.015,
                                    child: TextField(
                                      style: TextStyle(
                                          fontSize:
                                              widget.screenWidth * 0.0095),
                                      focusNode: _focusNodeTicketNo,
                                      controller: _controllerTicketNo,
                                      onTap: () {
                                        FocusScope.of(context)
                                            .requestFocus(_focusNodeTicketNo);
                                      },
                                      decoration: InputDecoration(
                                        hintText:
                                            'Ticket No...', // Placeholder text
                                        hintStyle: TextStyle(
                                          color: const Color.fromARGB(150, 141,
                                              153, 161), // Light hint color
                                          fontSize: widget.screenWidth * 0.01,
                                        ),
                                        contentPadding: EdgeInsets.symmetric(
                                            vertical:
                                                widget.screenHeight * 0.01,
                                            horizontal:
                                                widget.screenWidth * 0.005),
                                        hoverColor: Colors.black,
                                        focusedBorder: UnderlineInputBorder(
                                          borderSide:
                                              BorderSide(color: Colors.blue),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                            height: widget.screenHeight *
                                0.03), // Space between buttons

                        Center(
                          child: Padding(
                            padding: EdgeInsets.symmetric(
                                vertical: widget.screenHeight * 0.03),
                            child: ElevatedButton(
                              onPressed: () async {
                                // Start the comparison process by setting _isLoading to true
                                // setState(() {
                                //   if (_controllerTicketNo.text.isNotEmpty) {
                                //     _isLoading = true;
                                //     _elapsedTime =
                                //         0; // Reset the elapsed time when the comparison starts
                                //   }
                                // });

                                // Call the compareFiles method and wait for the result
                                analyseDefect();
                              },
                              style: ElevatedButton.styleFrom(
                                padding: EdgeInsets.symmetric(
                                  vertical: widget.screenHeight *
                                      0.04, // Vertical padding
                                  horizontal: widget.screenWidth *
                                      0.07, // Horizontal padding
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(
                                      20), // Rounded corners
                                ),
                                backgroundColor: Colors.blue,
                              ),
                              child: Text(
                                _isLoading
                                    ? formatElapsedTime(
                                        _elapsedTime) // Display elapsed time when loading
                                    : ( // Display comparison result when available
                                        "Generate"), // Display "Compare" when not loading
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: widget.screenWidth * 0.014
                                    ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                SizedBox(
                    width: widget.screenWidth * 0.01), // Space between boxes
                // Second box inside the content for Option 1 with decoration
                if (!_isResultGenerated)
                  Container(
                    width: widget.screenWidth * 0.7,
                    height: widget.screenHeight * 0.77,
                    decoration: BoxDecoration(
                      color: AppColors.appBarBackground, // Box color
                      borderRadius: BorderRadius.all(
                          Radius.circular(15)), // Rounded corners
                    ),
                    child: Stack(
                      children: [
                        Center(
                          child: SvgPicture.asset(
                            'assets/Generate_Icon.svg',
                            width: widget.screenWidth * 0.2,
                            height: widget.screenWidth * 0.2,
                            color: const Color.fromARGB(210, 163, 212, 247),
                          ),
                        )
                      ],
                    ),
                  ),

                if (_isResultGenerated)
                  Column(
                    children: [
                      Container(
                        width: widget.screenWidth * 0.345,
                        height: widget.screenHeight * 0.3,
                        decoration: BoxDecoration(
                          color: AppColors.appBarBackground, // Box color
                          borderRadius: BorderRadius.all(
                              Radius.circular(15)), // Rounded corners
                        ),
                        child: Column(
                          children: [
                            Container(
                              child: Text("Ticket Summary",
                              style: TextStyle(
                                color: Colors.black, 
                                fontSize: widget.screenWidth*0.015),
                                ),
                                padding: EdgeInsets.only(top:widget.screenHeight * 0.02),
                              ), 
                            Container( //Ticket Summary
                            width: widget.screenWidth * 0.32,
                              height: widget.screenHeight * 0.2,
                              // padding: EdgeInsets.all(widget.screenHeight * 0.02),
                              child: Markdown(
                                data: resultSummary,
                              ),
                            ),
                            
                          ],
                        ),
                      ),
                      
                      SizedBox(height: widget.screenHeight * 0.01),
                      
                      Container(
                        width: widget.screenWidth * 0.345,
                        height: widget.screenHeight * 0.465,
                        decoration: BoxDecoration(
                          color: AppColors.appBarBackground, // Box color
                          borderRadius: BorderRadius.all(
                              Radius.circular(15)), // Rounded corners
                        ),
                        child: Column(
                          children: [
                            Container(
                              child: Text("Similar Tickets",
                              style: TextStyle(
                                color: Colors.black, 
                                fontSize: widget.screenWidth*0.015),
                                ),
                                padding: EdgeInsets.only(top:widget.screenHeight * 0.02, bottom: widget.screenHeight * 0.01),
                              ), 
                            Container( //Similar Tickets
                            // color: Colors.amber,
                            width: widget.screenWidth * 0.32,
                              height: widget.screenHeight * 0.35,
                              // padding: EdgeInsets.all(widget.screenHeight * 0.02),
                              child: Markdown(
                                data: resultSimilarIssues,
                              ),
                            ),
                            
                          ],
                        ),
                      ),
                    ],
                  ),
                if (_isResultGenerated)
                  SizedBox(width: widget.screenWidth * 0.01),
                if (_isResultGenerated)
                  Container(
                    width: widget.screenWidth * 0.345,
                    height: widget.screenHeight * 0.77,
                    decoration: BoxDecoration(
                      color: AppColors.appBarBackground, // Box color
                      borderRadius: BorderRadius.all(
                          Radius.circular(15)), // Rounded corners
                    ),
                    child: Stack(
                      children: [
                          Container(
                              padding: EdgeInsets.only(top:widget.screenHeight * 0.02, left: widget.screenWidth*0.09, bottom: widget.screenHeight * 0.02),
                              child: Text("Recommended Solutions",
                              style: TextStyle(
                                color: Colors.black, 
                                fontSize: widget.screenWidth*0.015),
                                ),
                              ),                   
                          // Display markdown after the result is loaded
                          Container(
                            // color: Colors.amber,
                            width: widget.screenWidth * 0.35,
                            height: widget.screenHeight * 0.75,
                            padding: EdgeInsets.only(top:widget.screenHeight * 0.07, right: widget.screenHeight * 0.02,left: widget.screenHeight * 0.02),
                            child: Markdown(
                              data: resultSolutionFromComments,
                              // styleSheet: MarkdownStyleSheet(
                                // h1: TextStyle(fontSize: 24, fontWeight: FontWeight.bold), // Apply style to headings
                                // h2: TextStyle(fontSize: 20, fontWeight: FontWeight.bold), // Apply style to subheadings
                                // p: TextStyle(fontSize: widget.screenWidth*0.012), // Apply style to paragraphs
                              // ),
                            ),
                          ),

                        // Image at the top-right corner
                        Positioned(
                          top: widget.screenWidth *
                              0.01, // Align to the top of the container
                          right: widget.screenWidth *
                              0.01, // Align to the right of the container
                          child: GestureDetector(
                            onTap: () {
                              showFullscreenResult(1); // Call the function
                            },
                            child: Icon(
                              Icons.fullscreen,
                              size: widget.screenWidth * 0.03,
                              color: Colors.grey,
                            ),
                          ),
                        ),

                        // Image at the bottom-right corner
                        Positioned(
                          bottom: widget.screenWidth *
                              0.01, // Align to the bottom of the container
                          right: widget.screenWidth *
                              0.01, // Align to the right of the container
                          child: GestureDetector(
                            onTap: () {
                              downloadComparisonResult(1); // Call the function
                              print("downloadComparisonResult");
                            },
                            child: Icon(
                              Icons.download,
                              size: widget.screenWidth * 0.03,
                              color: Colors.blue,
                            ),
                          ),
                          // child: Icon(Icons.download,size: widget.screenWidth*0.03,color: Colors.blue,)
                        ),
                      ],
                    ),
                  )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
