import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:login_signup_page/hr_app//utils/app_colors.dart';  // Import colors from app_colors.dart
import 'dart:async';
import 'dart:typed_data';
import 'dart:convert';
import 'package:login_signup_page/hr_app//utils/methods.dart';
import 'package:http/http.dart' as http;
import 'dart:html' as html;
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:login_signup_page/hr_app//pages/full_screen_page.dart';


class TabContent extends StatefulWidget {
  final TabController tabController;
  final double screenWidth;
  final double screenHeight;
  final BuildContext context;

  TabContent({
    required this.context,
    required this.tabController,
    required this.screenWidth,
    required this.screenHeight,
  });

  @override
  State<TabContent> createState() => _TabContentState();
}

class _TabContentState extends State<TabContent> {

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final TextEditingController _controller = TextEditingController();
  final TextEditingController _controllerKeywords = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  final FocusNode _focusNodeKeywords = FocusNode();
  final FocusNode _focusNodeCriteria = FocusNode();


  Uint8List? _fileBytes1;
  String? _fileName1;
  List<Uint8List?> _fileBytesList = []; // List to store file bytes for multiple files
  List<String?> _fileNameList = []; // List to store file names for multiple files
  String jdResult = '';
  Timer? _timer;
  int _elapsedTime = 0;
  bool _isGeneratingJd = false;
  bool _isGeneratingReport = false;
  bool _isJdGenerated = false;
  bool _isReportGenerated = false;
  bool _isCriteriaGenerating = false;
  bool _isCriteriaGenerated = false;
  String reportResult = '';
  bool _selectAll = false;
  List<String> checkedTitles = [];

  List<dynamic> initialTitles = [];

  // List to store checkbox titles and their status
  List<Map<String, dynamic>> _checkboxes = [];

  // Controller for the text input field
  TextEditingController _titleController = TextEditingController();


Future<void> pickFile(int fileNumber) async {

  FilePickerResult? result = await FilePicker.platform.pickFiles(
    type: FileType.custom,
    allowedExtensions: ['pdf', 'pcapng', 'docx', 'txt','pptx'],
    allowMultiple: fileNumber == 2, 
  );

  if (result != null && result.files.isNotEmpty) {
    if (fileNumber == 1) {
      final platformFile = result.files.single;
      if (platformFile.bytes != null) {
        setState(() {
          _fileBytes1 = platformFile.bytes;
          _fileName1 = platformFile.name; // Store file name for file 1
        });
      } else {
        ScaffoldMessenger.of(widget.context).showSnackBar(const SnackBar(
          content: Text('File selected, but bytes are not available.'),
        ));
      }
    } else if (fileNumber == 2) {
      // Clear previous selections
      // _fileBytesList.clear();
      // _fileNameList.clear();

      for (var platformFile in result.files) {
        if (platformFile.bytes != null) {
          _fileBytesList.add(platformFile.bytes);
          _fileNameList.add(platformFile.name); // Store file names for multiple files
        }
      }
      // print(_fileNameList);
      setState(() {
        
      });


    }
  } else {
    ScaffoldMessenger.of(widget.context).showSnackBar(const SnackBar(
      content: Text('No file selected. Please try again.'),
    ));
  }
}

// Funtion to Clear previous selections
void clearCvList()
{
  setState(() {
      if(_fileBytesList.isNotEmpty)
      {
          _fileBytesList.clear();
      }
      if(_fileNameList.isNotEmpty)
      {
          _fileNameList.clear();
      }
  });
  
}

void _selectAllCheckboxes(bool? value) {
    setState(() {
      _selectAll = value!;
      for (var checkbox in _checkboxes) {
        checkbox['isChecked'] = value;
      }
    });
  }

Future<void> generateJd() async {

  if (_controller.text.isEmpty || _controllerKeywords.text.isEmpty) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('Please enter the text to generate the jobdescription.'),
    ));
    return;
  }

  if (_isGeneratingJd || _isGeneratingReport || _isCriteriaGenerating) {
    ScaffoldMessenger.of(widget.context).showSnackBar(
      SnackBar(content: Text("Generation in progress. Please wait.")),
    );
    return; 
  }

  setState(() {
    _isGeneratingJd= true;
    // _isLoading = true;
    _elapsedTime = 0;
  });

  _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
    setState(() {
      _elapsedTime++;
      // print(_elapsedTime);
    });
  });

  String dynamicContext = _controller.text;
  String dynamicKeywords = _controllerKeywords.text;

  Map<String, dynamic> jsonData = {
    'keywords': dynamicKeywords,
    'job_role':dynamicContext,
  };

  // print(dynamicContext);
  String jsonString = jsonEncode(jsonData);
  // print(jsonString);
  String encodedJson = Uri.encodeQueryComponent(jsonString);

  var url = Uri.parse('http://172.18.14.2:9000/generate_job_description/?data=$encodedJson');
  // print(url);

  var request = http.MultipartRequest('POST', url);
  request.headers.addAll({'accept': 'application/json'});

  try {
    var response = await request.send();
    
    if (response.statusCode == 200) {
      String result = await response.stream.bytesToString();
      Map<String, dynamic> jsonResponse = jsonDecode(result);
      var comparisonValue = jsonResponse['job_description'];

      // print(comparisonValue);

      setState(() {
        jdResult = comparisonValue;
        // _isLoading = false;
        _isGeneratingJd = false;
      });
    } else {
      throw Exception('Failed to generate rule: ${response.statusCode}');
    }

  } catch (e) {
    setState(() {
      _isGeneratingJd= false;
      _elapsedTime =0;
      // _isLoading = false;
    });
    _timer?.cancel();

    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Error: $e'),
    ));
  }
  _timer?.cancel();
}

Future <void>reportGeneration() async {
    if (_fileName1 == null || _fileNameList.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Please select both files.'),
      ));
      return;
    }

    if (_isGeneratingReport || _isGeneratingJd) 
    {
    ScaffoldMessenger.of(widget.context).showSnackBar(
      SnackBar(content: Text("Generation in progress. Please wait.")),
    );
    return; // Exit the function if a download is already in progress
  }

  setState(() {
    _isGeneratingReport= true;
    _elapsedTime = 0;
  });

  _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
    setState(() {
      _elapsedTime++;
    });
  });

  var request = http.MultipartRequest('POST', Uri.parse('http://172.18.14.2:8000/CV_Comparison'));

  // request.files.add(await http.MultipartFile.fromBytes('JD_file', await _fileBytes1!, filename: _fileName1));

  for (int i = 0; i < _fileBytesList.length; i++) {
    request.files.add(await http.MultipartFile.fromBytes(
      'files', 
      await _fileBytesList[i]!,
      filename: _fileNameList[i], 
    ));
  }
  String criteria = checkedTitles.join(', ');

  request.fields['criteria'] = criteria;
  // request.headers.addAll({'accept': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}); 

  try {
    var response = await request.send();
    if (response.statusCode == 200) {
    //   final bytes = await response.stream.toBytes();
    //   final blob = html.Blob([bytes], 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'native');
    //   final url = html.Url.createObjectUrlFromBlob(blob);
    //   final anchor = html.AnchorElement(href: url)
    //     ..target = 'blank'
    //     ..setAttribute('download', 'generated_report.xlsx')
    //     ..click();
    //   html.Url.revokeObjectUrl(url);
    //   _showDownloadSuccessDialog(context); 
    //   setState(() {
    //   _isGeneratingReport = false;
    //   _isReportGenerated = true;
    // });

    String result = await response.stream.bytesToString();
    Map<String, dynamic> jsonResponse = jsonDecode(result);
    var comparisonValue = jsonResponse['output'];
    print(result);

    setState(() 
    {
      _isGeneratingReport = false;
      _isReportGenerated = true;
      reportResult = comparisonValue;
    });



    }
    else 
    {
      throw Exception('Failed to download Report file: ${response.statusCode}');
    }
    
  } catch (e) {
    setState(() {
      _isGeneratingReport = false;
      _isReportGenerated = false;
    });
    _timer?.cancel();

    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Error: $e'),
    ));
  }
    _timer?.cancel();
}

Future <void>downloadExcel() async {
    var request = http.MultipartRequest('GET', Uri.parse('http://172.18.14.2:8000/Excel'));
    request.headers.addAll({'accept': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}); 

    try {
      var response = await request.send();
      if (response.statusCode == 200) {
        final bytes = await response.stream.toBytes();
        final blob = html.Blob([bytes], 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'native');
        final url = html.Url.createObjectUrlFromBlob(blob);
        final anchor = html.AnchorElement(href: url)
          ..target = 'blank'
          ..setAttribute('download', 'generated_report.xlsx')
          ..click();

        html.Url.revokeObjectUrl(url);
        _showDownloadSuccessDialog(context);
      } else {
        throw Exception('Failed to download Excel file: ${response.statusCode}');
      }
    } 
    catch (e) 
    {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Error: $e'),
      ));
    }
}

Future <void>generateCriteria() async {
    if (_fileName1 == null ) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Please select Jd to continue.'),
      ));
      return;
    }

    if (_isGeneratingReport || _isGeneratingJd ||_isCriteriaGenerating) 
    { 
    ScaffoldMessenger.of(widget.context).showSnackBar(
      SnackBar(content: Text("Generation in progress. Please wait.")),
    );
    return; 
  }

  setState(() {
    _isCriteriaGenerating= true;
    _isCriteriaGenerated = false;
    _isReportGenerated = false;
    _elapsedTime = 0;
    _selectAll = false;
  });

  _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
    setState(() {
      _elapsedTime++;
    });
  });

  var url = Uri.parse('http://172.18.14.2:8000/generate_criteria');

  var request = http.MultipartRequest('POST', url);
  request.files.add(await http.MultipartFile.fromBytes('JD_file', await _fileBytes1!, filename: _fileName1));
  request.headers.addAll({'Content-Type': 'multipart/form-data',});

  try {
    var response = await request.send();
    
    if (response.statusCode == 200) {
      String result = await response.stream.bytesToString();
      // print(result);
      Map<String, dynamic> jsonResponse = jsonDecode(result);
      setState(() 
      {
          initialTitles = jsonResponse['criteria'];
          // print(initialTitles.length);
          // print(initialTitles.elementAt(0));
          _checkboxes = initialTitles.map((title) {
          return {'title': title, 'isChecked': false};
        }).toList();
        _isCriteriaGenerating = false;
        _isCriteriaGenerated = true;
      });
    } else {
      throw Exception('Failed to generate rule: ${response.statusCode}');
    }

  } catch (e) {
    print(e);
    setState(() {
      _isCriteriaGenerating = false;
      _isCriteriaGenerated = false;
      _elapsedTime =0;
    });
    _timer?.cancel();

    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Error: $e'),
    ));
  }
  _timer?.cancel();
}

// Function to show success dialog
void _showDownloadSuccessDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text('Download Successful'),
        content: Text('The file has been downloaded successfully.'),
        actions: <Widget>[
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();  // Close the dialog
            },
            child: Text('OK'),
          ),
        ],
      );
    },
  );
}

// logic for downloading the file 
Future<void> downloadComparisonResult(int value) async {
  if(value==1)
  {
    print("downloadResult1");
    if (jdResult.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('No generated jd to download.'),
      ));
      return;
    }
    else{
      // Download as Text File
    final blob = html.Blob([jdResult], 'text/plain', 'native');
    final url = html.Url.createObjectUrlFromBlob(blob);
    final anchor = html.AnchorElement(href: url)
      ..target = 'blank'
      ..setAttribute('download', 'generated_jd.txt')
      ..click();
    html.Url.revokeObjectUrl(url);
    }
  }
  else if(value==2)
  {
    final result = await showDialog<String>(
    context: context,
    builder: (context) {
      return AlertDialog(
        // contentPadding: EdgeInsets.only(left: MediaQuery.of(context).size.width*0.01),
        title: Text('Choose file format',textAlign: TextAlign.center,),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop('text');
            },
            iconAlignment: IconAlignment.start,
            child: Text('Text File'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop('excel');
            },
            child: Text('Excel File'),
          ),
        ],
      );
    },
  );
  if(result == 'text')
  {
    print("downloadResult2");
    if (reportResult.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('No report generated to download.'),
      ));
      return;
    }
    else{
      // Download as csv File
    final blob = html.Blob([reportResult], 'text/plain', 'native');
    final url = html.Url.createObjectUrlFromBlob(blob);
    final anchor = html.AnchorElement(href: url)
      ..target = 'blank'
      ..setAttribute('download', 'generated_report.txt')
      ..click();
    html.Url.revokeObjectUrl(url);
    }
  }
  else if(result == 'excel')
  {
      downloadExcel();
  }
  
  }
    
  }

@override
void dispose() {
  _focusNode.dispose();  // Dispose the focus node when the widget is disposed
  _focusNodeKeywords.dispose();
  _focusNodeCriteria.dispose();
  super.dispose();
}

void showFullscreenResult( int value) {

    if(value==1)
    {
      if (jdResult.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('No generated rule to display.'),
      ));
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MarkdownDisplayPage(markdownData: jdResult,type: "rule"),
      ),
    );
    }
    else if(value==2)
    {
      if (reportResult.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('No report generated to display.'),
      ));
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MarkdownDisplayPage(markdownData: reportResult, type: "report",),
      ),
    );
      
    }
    
  }

// Function to print all checked checkboxes
void _printCheckedCheckboxes() {
  // Create a list of titles for checked checkboxes
  
  for (var checkbox in _checkboxes) {
    if (checkbox['isChecked']) {
      checkedTitles.add(checkbox['title']);
    }
  }

  // Print the checked titles
  // print("Checked Checkboxes: $checkedTitles");
}
// Function to add a new checkbox only if the text field is not empty
void _addCheckbox() {
  String title = _titleController.text.trim();
  if (title.isNotEmpty) {
    setState(() {
      // Add a new checkbox with the title from the text field and unchecked state
      _checkboxes.add({'title': title, 'isChecked': false});
      _titleController.clear(); // Clear the text field after adding
    });
  } else {
    // Optionally show a message if the text field is empty
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Please enter a title for the new checkbox')),
    );
  }
}

@override
  void initState() {
    super.initState();
    // Initialize the checkboxes with the predefined titles
    for (var title in initialTitles) {
      _checkboxes.add({'title': title, 'isChecked': false});
    }
  }

  @override
  Widget build(BuildContext context) 
  {
    return Expanded(
      child: TabBarView(
        controller: widget.tabController,
        children: [
// Content for Option 1 - GD Generation
          Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                // First box inside the content for Option 1 with decoration
                Container(
                  width: widget.screenWidth * 0.3,
                  height: widget.screenHeight * 0.77,
                  decoration: BoxDecoration(
                    color: AppColors.appBarBackground, // Box color
                    borderRadius: BorderRadius.all(Radius.circular(15)),  // Rounded corners
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(16),  // Add padding inside the box
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,  // Center the buttons inside the box
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        SizedBox(height: widget.screenHeight * 0.03),  // Space between buttons
                        
                  Stack(
                    children: [
                      // Container with image and text
                      Container(
                        width: widget.screenWidth * 0.25,
                        height: widget.screenHeight * 0.25,
                        decoration: BoxDecoration(
                          color: Colors.white,  // Background color of the container
                          borderRadius: BorderRadius.circular(15),  // Rounded corners
                        ),
                        child: Stack(
                          children: [
                            // Text at the top-left corner
                            Positioned(
                              top: widget.screenHeight*0.008,  // 8px from the top edge
                              left: widget.screenWidth*0.008,  // 8px from the left edge
                              child: Text(
                                _controller.text.isEmpty ? "Enter Job Role" : "Job Role: ${_controller.text}",  // Dynamic text change  // Text at the top-left corner
                                style: TextStyle(
                                  color: const Color.fromARGB(210, 50, 54, 58),
                                  fontSize: widget.screenWidth*0.0095,
                                  fontWeight: FontWeight.w100,
                                ),
                              ),
                            ),

                            // Editable Text Field below the text
                            Positioned(
                              top: widget.screenHeight * 0.15,  // 28px from the top edge (adjust to position below "Enter Criteria")
                              left: widget.screenWidth * 0.015,  // 8px from the left edge
                              right: widget.screenWidth * 0.015,  // 8px from the right edge (makes the text field expand)
                              child: TextField(
                                style: TextStyle(fontSize: widget.screenWidth*0.0095),
                                focusNode: _focusNode,
                                controller: _controller,
                                onTap: () {
                                    FocusScope.of(context).requestFocus(_focusNode);
                                  },
                                decoration: InputDecoration(
                                  hintText: 'Job Role...',  // Placeholder text
                                  hintStyle: TextStyle(
                                    color: const Color.fromARGB(150, 141, 153, 161),  // Light hint color
                                    fontSize: widget.screenWidth*0.01,
                                  ),
                                  contentPadding: EdgeInsets.symmetric(vertical: widget.screenHeight * 0.01, horizontal: widget.screenWidth * 0.01),
                                  // border: OutlineInputBorder(
                                  //   borderRadius: BorderRadius.circular(8),
                                  //   borderSide: BorderSide(color: Colors.grey),
                                  // ),
                                  hoverColor: Colors.black,
                                  focusedBorder: UnderlineInputBorder(
                        // borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide(color: Colors.blue),  // Color of the border when focused (typing)
                      ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: widget.screenHeight*0.03,),

                  Stack(
                    children: [
                      // Container with image and text
                      Container(
                        width: widget.screenWidth * 0.25,
                        height: widget.screenHeight * 0.25,
                        decoration: BoxDecoration(
                          color: Colors.white,  // Background color of the container
                          borderRadius: BorderRadius.circular(15),  // Rounded corners
                        ),
                        child: Stack(
                          children: [
                            // Text at the top-left corner
                            Positioned(
                              top: widget.screenHeight*0.008,  // 8px from the top edge
                              left: widget.screenWidth*0.008,  // 8px from the left edge
                              child: Text(
                                _controllerKeywords.text.isEmpty ? "Enter Keywords" : "Keywords: ${_controllerKeywords.text}",  // Dynamic text change  // Text at the top-left corner
                                style: TextStyle(
                                  color: const Color.fromARGB(210, 50, 54, 58),
                                  fontSize: widget.screenWidth*0.0095,
                                  fontWeight: FontWeight.w100,
                                ),
                              ),
                            ),

                            // Editable Text Field below the text
                            Positioned(
                              top: widget.screenHeight * 0.15,  
                              left: widget.screenWidth * 0.015,  
                              right: widget.screenWidth * 0.015, 
                              child: TextField(
                                style: TextStyle(fontSize: widget.screenWidth*0.0095),
                                focusNode: _focusNodeKeywords,
                                controller: _controllerKeywords,
                                onTap: () {
                                    FocusScope.of(context).requestFocus(_focusNodeKeywords);
                                  },
                                decoration: InputDecoration(
                                  hintText: 'Keywords...',  // Placeholder text
                                  hintStyle: TextStyle(
                                    color: const Color.fromARGB(150, 141, 153, 161),  // Light hint color
                                    fontSize: widget.screenWidth*0.01,
                                  ),
                                  contentPadding: EdgeInsets.symmetric(vertical: widget.screenHeight * 0.01, horizontal: widget.screenWidth * 0.01),
                                  // border: OutlineInputBorder(
                                  //   borderRadius: BorderRadius.circular(8),
                                  //   borderSide: BorderSide(color: Colors.grey),
                                  // ),
                                  hoverColor: Colors.black,
                                  focusedBorder: UnderlineInputBorder(
                        // borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide(color: Colors.blue),  // Color of the border when focused (typing)
                      ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                        
                  Center(
                    child: Padding(
                      padding: EdgeInsets.symmetric(vertical: widget.screenHeight * 0.03),
                      child: ElevatedButton(
                        
                        onPressed: () async {
                          // Start the comparison process by setting _isLoading to true
                          setState(() {
                            if(_controller.text.isNotEmpty)
                            {
                              // _isLoading = true;
                            // _elapsedTime = 0;  // Reset the elapsed time when the comparison starts
                            }
                            
                          });

                          // Call the compareFiles method and wait for the result
                          generateJd();

                        },
                        style: ElevatedButton.styleFrom(
                          // padding: EdgeInsets.symmetric(
                          //   vertical: widget.screenHeight * 0.04, // Vertical padding
                          //   horizontal: widget.screenWidth * 0.08, // Horizontal padding
                          // ),
                          fixedSize: Size(widget.screenWidth * 0.23, widget.screenHeight * 0.09),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20), // Rounded corners
                          ),
                          backgroundColor: Colors.blue,
                        ),
                        child: Text(
                          _isGeneratingJd 
                              ? formatElapsedTime(_elapsedTime)  // Display elapsed time when loading
                              : (  // Display comparison result when available
                                "Generate JD"),  // Display "Compare" when not loading
                                style: TextStyle(color: Colors.white, fontSize: widget.screenWidth*0.013,),
                        ),
                      ),
                    ),
                  ),
                      ],
                    ),
                  ),
                ),
                
                
                SizedBox(width: widget.screenWidth * 0.01), // Space between boxes
                // Second box inside the content for Option 1 with decoration
                Container(
                  width: widget.screenWidth * 0.65,
                  height: widget.screenHeight * 0.77,
                  decoration: BoxDecoration(
                    color: AppColors.appBarBackground, // Box color
                    borderRadius: BorderRadius.all(Radius.circular(15)),  // Rounded corners
                  ),
                  child: Stack(
                    children: [
                      // Main content of the container (existing content)
                      if (jdResult.isEmpty)
                            Center(
                              child: SvgPicture.asset(
                                'assets/Generate_Icon.svg',
                                width: widget.screenWidth * 0.2,
                                height: widget.screenWidth * 0.2,
                                color: const Color.fromARGB(210, 163, 212, 247),
                              ),
                            )
                          else
                            // Display markdown after the result is loaded
                            Container(
                              padding: EdgeInsets.all(widget.screenHeight*0.01),
                              child: Markdown(
                                data: jdResult,
                                styleSheet: MarkdownStyleSheet(a: TextStyle(fontWeight: FontWeight.w500)),
                              ),
                            ),
                      
                      // Image at the top-right corner
                      Positioned(
                        top: widget.screenWidth * 0.01,  // Align to the top of the container
                        right: widget.screenWidth * 0.01,  // Align to the right of the container
                        child: GestureDetector(
                          onTap: () {
                            showFullscreenResult(1);  // Call the function
                          },
                          child: Icon(
                            Icons.fullscreen,
                            size: widget.screenWidth * 0.03,
                            color: Colors.grey,
                          ),
                        ),
                      ),


                      // Image at the bottom-right corner
                      Positioned(
                        bottom: widget.screenWidth * 0.01,  // Align to the bottom of the container
                        right: widget.screenWidth * 0.01,   // Align to the right of the container
                        child: GestureDetector(
                          onTap: () {
                            downloadComparisonResult(1);  // Call the function
                            print("downloadComparisonResult");
                          },
                          child: Icon(
                            Icons.download,
                            size: widget.screenWidth * 0.03,
                            color: Colors.blue,
                          ),
                        ),
                        // child: Icon(Icons.download,size: widget.screenWidth*0.03,color: Colors.blue,)
                      ),
                    ],
                  ),
                ),

              ],
            ),
          ),


// Content for Option 2 - Report Generation
          Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                // First box inside the content for Option 1 with decoration                
                Container(
                  width: widget.screenWidth * 0.3,
                  height: widget.screenHeight * 0.77,
                  decoration: BoxDecoration(
                    color: AppColors.appBarBackground, // Box color
                    borderRadius: BorderRadius.all(Radius.circular(15)),  // Rounded corners
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(widget.screenHeight*0.01),  // Add padding inside the box
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,  // Center the buttons inside the box
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Stack(
                          children: [

                            Container(
                              width: widget.screenWidth * 0.25,
                              height: widget.screenHeight * 0.25,
                              decoration: BoxDecoration(
                                color: Colors.white,  // Background color of the container
                                borderRadius: BorderRadius.circular(15),  // Rounded corners
                              ),
                              child: Stack(
                                children: [
                                  // Image at the center
                                  Center(
                                    child: SvgPicture.asset(
                                      height: widget.screenHeight * 0.1,
                                      width: widget.screenWidth * 0.06,
                                      'assets/Drop_button.svg',  // Replace with your image path
                                      fit: BoxFit.contain,  // Adjust image to fit within the container
                                    ),
                                  ),
                                  // Text at the bottom
                                  Positioned(
                                    bottom:  widget.screenHeight*0.01,  // 8px from the bottom edge
                                    left: 0,
                                    right: 0,
                                    child: Text(
                                      "Drag and drop file",  // Display file name or default text
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: const Color.fromARGB(210, 141, 153, 161),
                                        fontSize: widget.screenWidth*0.0095,
                                        fontWeight: FontWeight.w100,
                                      ),
                                    ),
                                  ),
                                  // Text at the top-left corner
                                  Positioned(
                                    top: widget.screenHeight*0.01,  // 8px from the top edge
                                    left:  widget.screenWidth*0.008,  // 8px from the left edge
                                    child: Container(
                                      width: widget.screenWidth*0.2,
                                      child: Text(
                                        _fileName1 ?? "Select Job Description",  // Text at the top-left corner
                                        style: TextStyle(
                                          color: const Color.fromARGB(210, 50, 54, 58),
                                          fontSize: widget.screenWidth*0.0095,
                                          fontWeight: FontWeight.w100,
                                        ),
                                      ),
                                    ),
                                  ),
                                  // "+" Button positioned on top-right of Container
                                  Positioned(
                                    right: widget.screenWidth*0.008,  // 8px from the right edge
                                    top: widget.screenHeight*0.01,    // 8px from the top edge
                                    child: GestureDetector(
                                      onTap: () {
                                        // Define action for the "+" button here
                                        pickFile(1);
                                      },
                                      child: CircleAvatar(
                                        backgroundColor: Colors.blue,  // Background color of the button
                                        radius:  widget.screenWidth*0.0155,  // Radius of the circular button
                                        child: Icon(
                                          Icons.add,  // "+" icon
                                          color: Colors.white,  // Icon color
                                          size: widget.screenWidth*0.02,  // Icon size
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        
                  SizedBox(height: widget.screenHeight * 0.03),
                        Stack(
                          children: [

                            Container(
                              width: widget.screenWidth * 0.25,
                              height: widget.screenHeight * 0.25,
                              decoration: BoxDecoration(
                                color: Colors.white,  // Background color of the container
                                borderRadius: BorderRadius.circular(15),  // Rounded corners
                              ),
                              child: Stack(
                                children: [
                                  // Image at the center
                                  Center(
                                    child: SvgPicture.asset(
                                      height: widget.screenHeight * 0.1,
                                      width: widget.screenWidth * 0.06,
                                      'assets/Drop_button.svg',  // Replace with your image path
                                      fit: BoxFit.contain,  // Adjust image to fit within the container
                                    ),
                                  ),
                                  // Text at the bottom
                                  Positioned(
                                    bottom:  widget.screenHeight*0.01,  // 8px from the bottom edge
                                    left: 0,
                                    right: 0,
                                    child: Text(
                                      "Drag and drop file",  // Display file name or default text
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: const Color.fromARGB(210, 141, 153, 161),
                                        fontSize: widget.screenWidth*0.0095,
                                        fontWeight: FontWeight.w100,
                                      ),
                                    ),
                                  ),
                                  // Text at the top-left corner
                                  Positioned(
                              top: widget.screenHeight * 0.01,  // 8px from the top edge
                              left: widget.screenWidth * 0.008,  // 8px from the left edge
                              child: Container(
                                width: widget.screenWidth * 0.2, // Set a specific width
                                height: widget.screenHeight * 0.2, // Set a specific height
                                child: _fileNameList.isNotEmpty 
                                  ? SingleChildScrollView( // Make it scrollable if needed
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: _fileNameList.map((fileName) {
                                          return Text(
                                            fileName ?? '',
                                            style: TextStyle(
                                              color: const Color.fromARGB(210, 50, 54, 58),
                                              fontSize: widget.screenWidth * 0.0095,
                                              fontWeight: FontWeight.w100,
                                            ),
                                          );
                                        }).toList(),
                                      ),
                                    )
                                  : Text(
                                      "Select Profiles",
                                      style: TextStyle(
                                        color: const Color.fromARGB(210, 50, 54, 58),
                                        fontSize: widget.screenWidth * 0.0095,
                                        fontWeight: FontWeight.w100,
                                      ),
                                    ),
                              ),
                            ),
                                  // "+" Button positioned on top-right of Container
                                  Positioned(
                                    right: widget.screenWidth*0.008,  // 8px from the right edge
                                    top: widget.screenHeight*0.01,    // 8px from the top edge
                                    child: GestureDetector(
                                      onTap: () {
                                        // Define action for the "+" button here
                                        pickFile(2);
                                      },
                                      child: CircleAvatar(
                                        backgroundColor: Colors.blue,  // Background color of the button
                                        radius:  widget.screenWidth*0.0155,  // Radius of the circular button
                                        child: Icon(
                                          Icons.add,  // "+" icon
                                          color: Colors.white,  // Icon color
                                          size: widget.screenWidth*0.02,  // Icon size
                                        ),
                                      ),
                                    ),
                                  ),
                                  // Hyperlink text at the bottom right

                                  Positioned(
                                    bottom: widget.screenHeight * 0.01, // Adjust the position as needed
                                    right: widget.screenWidth * 0.01, // Align to the right of the container
                                    child: GestureDetector(
                                      onTap: () {
                                        clearCvList(); // Call your function here
                                      },
                                      child: SvgPicture.asset(
                                        'assets/reset.svg',
                                        width: widget.screenWidth * 0.023, // Fixed size without hover effect
                                        color: Colors.blue, // Fixed color without hover effect
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: widget.screenHeight * 0.03),  // Space between buttons

                        
                        Center(
                          child: Padding(
                            padding: EdgeInsets.symmetric(vertical: widget.screenHeight * 0.03),
                            child: ElevatedButton(
                              onPressed: () async {
                                // Start the comparison process by setting _isLoading to true
                                // setState(() {
                                //   _isGeneratingReport = true;
                                //   _elapsedTime = 0;  // Reset the elapsed time when the comparison starts
                                // });

                                // Call the compareFiles method and wait for the result
                                generateCriteria();

                                // print("Report generation");
                              },
                              style: ElevatedButton.styleFrom(
                                // padding: EdgeInsets.symmetric(
                                //   vertical: widget.screenHeight * 0.04, // Vertical padding
                                //   horizontal: widget.screenWidth * 0.07, // Horizontal padding
                                // ),
                                fixedSize: Size(widget.screenWidth * 0.23, widget.screenHeight * 0.09),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20), // Rounded corners
                                ),
                                backgroundColor: Colors.blue,
                              ),
                              child: Text(
                                _isCriteriaGenerating
                                    ? formatElapsedTime(_elapsedTime)  // Display elapsed time when loading
                                    : (  // Display comparison result when available
                                      "Generate Criteria"),  // Display "Compare" when not loading
                                      style: TextStyle(color: Colors.white,fontSize: widget.screenWidth*0.013),
                              ),
                            ),
                          ),
                        ),


                      ],
                    ),
                  ),
                ),
                SizedBox(width: widget.screenWidth * 0.01),
                // SizedBox(height: widget.screenHeight * 0.01),
                _isCriteriaGenerated?
                Container(
                  width: widget.screenWidth * 0.32,
                  height: widget.screenHeight * 0.77,
                  decoration: BoxDecoration(
                  color: AppColors.appBarBackground, // Box color
                  borderRadius: BorderRadius.all(Radius.circular(15)),  // Rounded corners
                  ),
                  child: Column(
                    children: [
                      // Container for scrollable checkboxes with grey background
                      Container(
                        height: widget.screenHeight * 0.5,
                        width: widget.screenWidth * 0.32,
                        // color: Colors.grey[300], // Set background color to grey
                        child: Padding(
                          padding: EdgeInsets.only(
                              top: MediaQuery.of(context).size.height * 0.02,
                              left: MediaQuery.of(context).size.width * 0.015,
                              right: MediaQuery.of(context).size.width * 0.005),
                          child: SingleChildScrollView(
                            child: Column(
                              children: [
                                // "Select All" option
                                Padding(
                                  padding: EdgeInsets.only(bottom: MediaQuery.of(context).size.height * 0.01),
                                  child: CheckboxListTile(
                                    title: Text('Select All'),
                                    value: _selectAll,
                                    onChanged: (bool? value) {
                                      setState(() {
                                       _selectAllCheckboxes(value);
                                      });
                                    },
                                    activeColor: Colors.black87,
                                    // checkColor: Colors.black12,
                                  ),
                                ),
                                ...List.generate(_checkboxes.length, (index) {
                                  return CheckboxListTile(
                                    activeColor: Colors.black38,
                                    title: Text(_checkboxes[index]['title']),
                                    value: _checkboxes[index]['isChecked'],
                                    onChanged: (bool? value) {
                                      setState(() {
                                        _checkboxes[index]['isChecked'] = value!;
                                      });
                                    },
                                  );
                                }),
                              ],
                            ),
                          ),
                        ),
                      ),

                      SizedBox(height: widget.screenHeight * 0.01),
                  
                      // TextField for user input (to add new checkbox title)
                      
                      Row(
                        children: [
                          SizedBox(width: widget.screenWidth*0.015),
                          Container(
                            height: widget.screenHeight * 0.055,
                            width: widget.screenWidth * 0.25,
                            // padding: EdgeInsets.symmetric(vertical: 8.0),
                            child: TextField(
                              controller: _titleController,
                              focusNode: _focusNodeCriteria,
                              cursorColor: Colors.black38,
                              onTap: () {
                                    FocusScope.of(context).requestFocus(_focusNodeCriteria);
                                  },
                              decoration: InputDecoration(
                                labelText: 'Enter criteria to be checked',
                                labelStyle: TextStyle(color: _focusNodeCriteria.hasFocus ? Colors.black : Colors.grey),
                                border: OutlineInputBorder(),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.black),
                                ),
                              ),
                            ),

                          ),
                          SizedBox(width: widget.screenWidth*0.01,),
                          GestureDetector(
                            onTap: () {
                              // Define action for the "+" button here
                              _addCheckbox();
                            },
                          child:CircleAvatar(
                            backgroundColor: Colors.blue,  // Background color of the button
                            radius:  widget.screenWidth*0.0155,  // Radius of the circular button
                            child: Icon(
                              Icons.add,  // "+" icon
                              color: Colors.white,  // Icon color
                              size: widget.screenWidth*0.02,  // Icon size
                            ),
                          ),
                          ),
                        ],
                      ),
                  
                      SizedBox(height: widget.screenHeight * 0.0173,),
                  
                      Center(
                        child: Padding(
                          padding: EdgeInsets.symmetric(vertical: widget.screenHeight * 0.03),
                          child: ElevatedButton(
                            
                            onPressed: () async {
                              _printCheckedCheckboxes();
                              reportGeneration();
                            },
                            style: ElevatedButton.styleFrom(
                              // padding: EdgeInsets.symmetric(
                              //   vertical: widget.screenHeight * 0.038, // Vertical padding
                              //   horizontal: widget.screenWidth * 0.08, // Horizontal padding
                              // ),
                              fixedSize: Size(widget.screenWidth * 0.24, widget.screenHeight * 0.09),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20), // Rounded corners
                              ),
                              backgroundColor: Colors.blue,
                            ),
                            child: Text(
                              _isGeneratingReport? formatElapsedTime(_elapsedTime):'Generate Report',
                                    style: TextStyle(color: Colors.white,fontSize: widget.screenWidth*0.013),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                )
                : 
                  Container(
                    width: widget.screenWidth * 0.65,
                    height: widget.screenHeight * 0.77,
                    decoration: BoxDecoration(
                      color: AppColors.appBarBackground, // Box color
                      borderRadius: BorderRadius.all(Radius.circular(15)),  // Rounded corners
                    ),
                    child: Stack(
                      children: [
                        Center(
                          child: SvgPicture.asset(
                            'assets/Generate_Icon.svg',
                            width: widget.screenWidth * 0.2,
                            height: widget.screenWidth * 0.2,
                            color: const Color.fromARGB(210, 163, 212, 247),
                          ),
                        ),
                      ],
                    ),
                  ),
                _isReportGenerated? 
                SizedBox(width: widget.screenWidth * 0.01):SizedBox(height: widget.screenHeight*0,width: widget.screenWidth*0,), // Space between boxes
                _isReportGenerated?
                Container(
                  width: widget.screenWidth * 0.32,
                  height: widget.screenHeight * 0.77,
                  decoration: BoxDecoration(
                    color: AppColors.appBarBackground, // Box color
                    borderRadius: BorderRadius.all(Radius.circular(15)),  // Rounded corners
                  ),
                  child: Stack(
                    children: [
                      if (reportResult.isEmpty)
                            Center(
                              child: SvgPicture.asset(
                                'assets/Generate_Icon.svg',
                                width: widget.screenWidth * 0.2,
                                height: widget.screenWidth * 0.2,
                                color: const Color.fromARGB(210, 163, 212, 247),
                              ),
                            )
                          else
                            Container(
                              padding: EdgeInsets.all(widget.screenHeight*0.015),
                              child: Markdown(
                                data: reportResult,
                                styleSheet: MarkdownStyleSheet(a: TextStyle(fontWeight: FontWeight.w500)),
                              ),
                            ),
                      
                      Positioned(
                        top: widget.screenWidth * 0.01,  
                        right: widget.screenWidth * 0.01,  
                        child: GestureDetector(
                          onTap: () {
                            showFullscreenResult(2);  // Call the function
                            print('showFullscreenResult2');
                          },
                          child: Icon(
                            Icons.fullscreen,
                            size: widget.screenWidth * 0.03,
                            color: Colors.grey,
                          ),
                        ),
                      ),


                      // Image at the bottom-right corner
                      Positioned(
                        bottom: widget.screenWidth * 0.01,  // Align to the bottom of the container
                        right: widget.screenWidth * 0.01,   // Align to the right of the container
                        child: GestureDetector(
                          onTap: () {
                            downloadComparisonResult(2);  // Call the function
                            // print("downloadComparisonResult2");
                          },
                          child: Icon(
                            Icons.download,
                            size: widget.screenWidth * 0.03,
                            color: Colors.blue,
                          ),
                        ),
                        // child: Icon(Icons.download,size: widget.screenWidth*0.03,color: Colors.blue,)
                      ),
                    ],
                  ),
                ):SizedBox(height: widget.screenHeight*0,width: widget.screenWidth*0,),
                // Container(width: widget.screenWidth*0,height: widget.screenHeight*0,),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
