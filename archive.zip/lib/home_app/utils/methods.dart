// Function to save data to localStorage
  import 'dart:convert';
import 'dart:html';


// void _saveToLocalStorage() {
//     // Create a Map of the data to be saved
//     final userDetails = {
//       'email': _emailController.text,
//       'password': _passwordController.text,
//       'confirm_password': _confirmPasswordController.text,
//     };

//     // Retrieve existing data from localStorage (if any)
//     String existingData = window.localStorage['user_details'] ?? '[]';  // Default to empty list if no data

//     // Try to decode the existing data as a List (even if it's empty)
//     var decodedData = jsonDecode(existingData);

//     // Ensure we're working with a List
//     if (decodedData is! List) {
//       print('Error: Expected a List, but found ${decodedData.runtimeType}');
//       decodedData = []; // Default to empty list if not a List
//     }

//     // Add the new user details to the list
//     decodedData.add(userDetails);

//     // Encode the updated list as JSON
//     final jsonString = jsonEncode(decodedData);

//     // Save the updated list to localStorage
//     window.localStorage['user_details'] = jsonString;

//     // Print confirmation for debugging purposes
//     print('Data saved to localStorage');
//   }


 