import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:login_signup_page/autosar_chat_app/ChatScreen/strings.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:login_signup_page/rfq_app/pages/home_page.dart'as rfq_home_page;
import 'package:login_signup_page/hr_app/pages/home_page.dart' as hr_home_page;
import 'package:login_signup_page/small_chat_bot/theme.dart';
import 'package:login_signup_page/small_chat_bot/chatScreenPop.dart';
// import 'package:login_signup_page/autosar_chat_app/MainScreen/Intro.dart'as autosar_home_page;
import 'package:login_signup_page/autosar_chat_app/MainScreen/ArchitectureAutosar.dart' as autosar_home_page;
import 'package:lottie/lottie.dart';
import 'package:login_signup_page/log_analyser/pages/home_page.dart' as log_analyser_home_page;
import 'package:login_signup_page/home_app/pages/login.dart'  as login_screen;
import 'package:login_signup_page/defect_analyzer/pages/home_page.dart' as defect_analyser_home_page;
import 'package:login_signup_page/norms_analyzer/ChatScreen/ChatLayout.dart' as norms_analyser_home_page;

class AcsiaHomePage extends StatefulWidget {
  final double screenWidth;
  final double screenHeight;

  const AcsiaHomePage(
      {Key? key, required this.screenWidth, required this.screenHeight})
      : super(key: key);

  @override
  _AcsiaHomePageState createState() => _AcsiaHomePageState();
}

class _AcsiaHomePageState extends State<AcsiaHomePage> {
  bool _isPopupVisible = false;
  final ScrollController _scrollController = ScrollController();
  
  @override
  void setState(VoidCallback fn) {
    // TODO: implement setState
    super.setState(fn);
    if (_scrollController.hasClients) {
  // print("ScrollController has a ScrollPosition attached");
} else {
  // print("ScrollController has no ScrollPosition attached");
}
  }

  void _showPopup() {
    setState(() {
      if(_isPopupVisible)
      {
        _isPopupVisible = false; // Show the popup
      }
      else
      {
        _isPopupVisible = true;
      }
      
    });
  }

  void _hidePopup() {
    setState(() {
      _isPopupVisible = false; // Hide the popup
    });
  }
  @override
void dispose() {
  _scrollController.dispose(); // Dispose the controller when not needed
  super.dispose();
}

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Container(
              
          // color: Colors.deepOrange,
          child: Stack(
            children: [
              // Positioned(child: Container(height:100 ,width: 200,color: Colors.amber,)),
               Column(
                children: [
                  Padding(
                    padding: EdgeInsets.only(
                        left: widget.screenWidth * 0.07,
                        right: widget.screenWidth * 0.07,
                        top: widget.screenHeight * 0.01),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: EdgeInsets.all(widget.screenWidth * 0.015),
                              alignment: Alignment.centerLeft,
                              child: SvgPicture.asset(
                                'assets/LilaLogo.svg',
                                width: widget.screenWidth * 0.05,
                                height: widget.screenWidth * 0.05,
                              ),
                            ),
                            SizedBox(width: widget.screenWidth*0.67,),
                            GestureDetector(
                              onTap: () {
                                Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => login_screen.LoginScreen()), // Use the alias to navigate
                              );
                              },
                              child: Container(
                              child: Icon(Icons.logout,size: widget.screenWidth*0.025,),
                            ),)
                            
                          ],
                        ),
                        Container(
                          child: Column(
                            children: [
                              Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.vertical(
                                    top: Radius.circular(20),
                                  ),
                                  color:
                                      const Color.fromARGB(255, 234, 239, 243),
                                ),
                                child: TabBar(
                                  tabs: [
                                    Tab(
                                      child: Text(
                                        'Home',
                                        style: TextStyle(
                                            fontSize:
                                                widget.screenWidth * 0.013),
                                      ),
                                    ),
                                    Tab(
                                      child: Text(
                                        'Automotive',
                                        style: TextStyle(
                                            fontSize:
                                                widget.screenWidth * 0.013),
                                      ),
                                    ),
                                    Tab(
                                      child: Text(
                                        'Purchase',
                                        style: TextStyle(
                                            fontSize:
                                                widget.screenWidth * 0.013),
                                      ),
                                    ),
                                    Tab(
                                      child: Text(
                                        'Human Resource',
                                        style: TextStyle(
                                            fontSize:
                                                widget.screenWidth * 0.013),
                                      ),
                                    ),
                                  ],
                                  labelColor: Colors.blue,
                                  unselectedLabelColor: Colors.black87,
                                  indicator: const UnderlineTabIndicator(
                                    borderSide: BorderSide(
                                        width: 3.0, color: Colors.blue),
                                  ),
                                ),
                              ),
                              SizedBox(height: widget.screenHeight * 0.01),
                              SizedBox(
                                height: widget.screenHeight * 0.6,
                                child: TabBarView(
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.vertical(
                                          bottom: Radius.circular(20),
                                        ),
                                        color: const Color.fromARGB(
                                            255, 234, 239, 243),
                                      ),
                                      child: _buildHomeTab(),
                                    ),

                                    // Automotive Tab

                                    Container(
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.vertical(
                                            bottom: Radius.circular(20),
                                          ),
                                          color: const Color.fromARGB(255, 234, 239, 243),
                                        ),
                                        padding: EdgeInsets.only(
                                          top: widget.screenHeight * 0.05,
                                          left: widget.screenWidth * 0.05,
                                          right: widget.screenWidth * 0.05,
                                        ),
                                        alignment: Alignment.topLeft,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Expanded(
                                              // height: widget.screenHeight * 0.7,
                                              child: ListView(
                                                
                                                controller: _scrollController,
                                                scrollDirection: Axis.vertical,
                                                padding: EdgeInsets.zero,
                                                children: [
                                                  // First Container
                                                  Row(
                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        width: widget.screenWidth * 0.3,
                                                        padding: EdgeInsets.all(widget.screenWidth * 0.02),
                                                        decoration: BoxDecoration(
                                                          color: Colors.white,
                                                          borderRadius: BorderRadius.circular(20),
                                                          boxShadow: [
                                                            BoxShadow(
                                                              color: Colors.black.withOpacity(0.1),
                                                              blurRadius: 5,
                                                              offset: Offset(0, 2),
                                                            ),
                                                          ],
                                                        ),
                                                        child: Column(
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          children: [
                                                            Text(
                                                              'Autosar Chat Bot',
                                                              style: TextStyle(
                                                                fontSize: widget.screenWidth * 0.015,
                                                                fontWeight: FontWeight.bold,
                                                                color: Colors.black87,
                                                              ),
                                                            ),
                                                            SizedBox(height: widget.screenHeight * 0.01),
                                                            Text(
                                                              'The AUTOSAR Expert System is a diagnostic tool that streamlines automotive software development. It provides instant solutions for error handling, architecture, and implementation across AUTOSAR layers. Backed by comprehensive documentation and industry best practices, it helps developers build compliant software faster.',
                                                              style: TextStyle(
                                                                fontSize: widget.screenWidth * 0.012,
                                                                color: Colors.black54,
                                                                fontWeight: FontWeight.w600,
                                                              ),
                                                            ),
                                                            SizedBox(height: widget.screenHeight * 0.02),
                                                            GestureDetector(
                                                              onTap: () {
                                                                Navigator.push(
                                                                  context,
                                                                  MaterialPageRoute(
                                                                    builder: (context) => autosar_home_page.MyHomePage(),
                                                                  ),
                                                                );
                                                              },
                                                              child: Container(
                                                                width: widget.screenWidth * 0.185,
                                                                height: widget.screenHeight * 0.07,
                                                                decoration: BoxDecoration(
                                                                  color: Colors.blue,
                                                                  borderRadius: BorderRadius.circular(10),
                                                                ),
                                                                child: Center(
                                                                  child: Text(
                                                                    'Explore',
                                                                    style: TextStyle(
                                                                      color: Colors.white,
                                                                      fontSize: widget.screenWidth * 0.014,
                                                                      fontWeight: FontWeight.w500,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      SizedBox(width: widget.screenWidth * 0.08),
                                                  //     Container(
                                                  //   width: widget.screenWidth * 0.3,
                                                  //   padding: EdgeInsets.all(widget.screenWidth * 0.02),
                                                  //   decoration: BoxDecoration(
                                                  //     color: Colors.white,
                                                  //     borderRadius: BorderRadius.circular(20),
                                                  //     boxShadow: [
                                                  //       BoxShadow(
                                                  //         color: Colors.black.withOpacity(0.1),
                                                  //         blurRadius: 5,
                                                  //         offset: Offset(0, 2),
                                                  //       ),
                                                  //     ],
                                                  //   ),
                                                  //   child: Column(
                                                  //     crossAxisAlignment: CrossAxisAlignment.start,
                                                  //     children: [
                                                  //       Text(
                                                  //         'Log Analyser',
                                                  //         style: TextStyle(
                                                  //           fontSize: widget.screenWidth * 0.015,
                                                  //           fontWeight: FontWeight.bold,
                                                  //           color: Colors.black87,
                                                  //         ),
                                                  //       ),
                                                  //       SizedBox(height: widget.screenHeight * 0.01),
                                                  //       Text(
                                                  //         'DLT Log Analyzer, a cutting-edge tool that leverages machine learning to analyze defect logs from Jira tickets. This innovative solution streamlines the identification of patterns and root causes, enhancing your team\'s efficiency in managing and resolving issues effectively.',
                                                  //         style: TextStyle(
                                                  //           fontSize: widget.screenWidth * 0.012,
                                                  //           color: Colors.black54,
                                                  //           fontWeight: FontWeight.w600,
                                                  //         ),
                                                  //       ),
                                                  //       SizedBox(height: widget.screenHeight * 0.02),
                                                  //       GestureDetector(
                                                  //         onTap: () {
                                                  //           Navigator.push(
                                                             
                                                  //             context,
                                                  //             MaterialPageRoute(
                                                  //               builder: (context) => log_analyser_home_page.HomePage(),
                                                  //             ),
                                                  //           );
                                                  //         },
                                                  //         child: Container(
                                                  //           width: widget.screenWidth * 0.185,
                                                  //           height: widget.screenHeight * 0.07,
                                                  //           decoration: BoxDecoration(
                                                  //             color: Colors.blue,
                                                  //             borderRadius: BorderRadius.circular(10),
                                                  //           ),
                                                  //           child: Center(
                                                  //             child: Text(
                                                  //               'Explore',
                                                  //               style: TextStyle(
                                                  //                 color: Colors.white,
                                                  //                 fontSize: widget.screenWidth * 0.014,
                                                  //                 fontWeight: FontWeight.w500,
                                                  //               ),
                                                  //             ),
                                                  //           ),
                                                  //         ),
                                                  //       ),
                                                  //     ],
                                                  //   ),
                                                  // ),
                                                  Container(
                                                        width: widget.screenWidth * 0.3,
                                                        padding: EdgeInsets.all(widget.screenWidth * 0.02),
                                                        decoration: BoxDecoration(
                                                          color: Colors.white,
                                                          borderRadius: BorderRadius.circular(20),
                                                          boxShadow: [
                                                            BoxShadow(
                                                              color: Colors.black.withOpacity(0.1),
                                                              blurRadius: 5,
                                                              offset: Offset(0, 2),
                                                            ),
                                                          ],
                                                        ),
                                                        child: Column(
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          children: [
                                                            Text(
                                                              'Log Analyzer',
                                                              style: TextStyle(
                                                                fontSize: widget.screenWidth * 0.015,
                                                                fontWeight: FontWeight.bold,
                                                                color: Colors.black87,
                                                              ),
                                                            ),
                                                            SizedBox(height: widget.screenHeight * 0.01),
                                                            Text(
                                                              'DLT Log Analyzer, a cutting-edge tool that leverages machine learning to analyze defect logs from Jira tickets. This innovative solution streamlines the identification of patterns and root causes, enhancing your team\'s efficiency in managing and resolving issues effectively.\n\n',
                                                              style: TextStyle(
                                                                fontSize: widget.screenWidth * 0.012,
                                                                color: Colors.black54,
                                                                fontWeight: FontWeight.w600,
                                                              ),
                                                            ),
                                                            SizedBox(height: widget.screenHeight * 0.02),
                                                            GestureDetector(
                                                              onTap: () {
                                                                Navigator.push(
                                                                  context,
                                                                  MaterialPageRoute(
                                                                    builder: (context) => log_analyser_home_page.HomePage(),
                                                                  ),
                                                                );
                                                              },
                                                              child: Container(
                                                                width: widget.screenWidth * 0.185,
                                                                height: widget.screenHeight * 0.07,
                                                                decoration: BoxDecoration(
                                                                  color: Colors.blue,
                                                                  borderRadius: BorderRadius.circular(10),
                                                                ),
                                                                child: Center(
                                                                  child: Text(
                                                                    'Explore',
                                                                    style: TextStyle(
                                                                      color: Colors.white,
                                                                      fontSize: widget.screenWidth * 0.014,
                                                                      fontWeight: FontWeight.w500,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  SizedBox(height: widget.screenHeight * 0.05),
                                                  // Third Container
                                                  Row(
                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        width: widget.screenWidth * 0.3,
                                                        padding: EdgeInsets.all(widget.screenWidth * 0.02),
                                                        decoration: BoxDecoration(
                                                          color: Colors.white,
                                                          borderRadius: BorderRadius.circular(20),
                                                          boxShadow: [
                                                            BoxShadow(
                                                              color: Colors.black.withOpacity(0.1),
                                                              blurRadius: 5,
                                                              offset: Offset(0, 2),
                                                            ),
                                                          ],
                                                        ),
                                                        child: Column(
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          children: [
                                                            Text(
                                                              'Defect Analyzer',
                                                              style: TextStyle(
                                                                fontSize: widget.screenWidth * 0.015,
                                                                fontWeight: FontWeight.bold,
                                                                color: Colors.black87,
                                                              ),
                                                            ),
                                                            SizedBox(height: widget.screenHeight * 0.01),
                                                            Text(
                                                              'Defect Analyzer, a cutting-edge tool that leverages Generative AI technologies such as RAG and GraphRAG to identify similar issues and their solutions  from Jira tickets. This innovative system enhances your team\'s efficiency in issue analysis and resolving issues effectively.\n',
                                                               style: TextStyle(
                                                                fontSize: widget.screenWidth * 0.012,
                                                                color: Colors.black54,
                                                                fontWeight: FontWeight.w600,
                                                              ),
                                                            ),
                                                            SizedBox(height: widget.screenHeight * 0.02),
                                                            GestureDetector(
                                                              onTap: () {
                                                                Navigator.push(
                                                                  context,
                                                                  MaterialPageRoute(
                                                                    builder: (context) => defect_analyser_home_page.HomePage(),
                                                                  ),
                                                                );
                                                              },
                                                              child: Container(
                                                                width: widget.screenWidth * 0.185,
                                                                height: widget.screenHeight * 0.07,
                                                                decoration: BoxDecoration(
                                                                  color: Colors.blue,
                                                                  borderRadius: BorderRadius.circular(10),
                                                                ),
                                                                child: Center(
                                                                  child: Text(
                                                                    'Explore',
                                                                    style: TextStyle(
                                                                      color: Colors.white,
                                                                      fontSize: widget.screenWidth * 0.014,
                                                                      fontWeight: FontWeight.w500,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      // Fourth Container
                                                  SizedBox(width: widget.screenWidth * 0.08),
                                                  Container(
                                                        width: widget.screenWidth * 0.3,
                                                        padding: EdgeInsets.all(widget.screenWidth * 0.02),
                                                        decoration: BoxDecoration(
                                                          color: Colors.white,
                                                          borderRadius: BorderRadius.circular(20),
                                                          boxShadow: [
                                                            BoxShadow(
                                                              color: Colors.black.withOpacity(0.1),
                                                              blurRadius: 5,
                                                              offset: Offset(0, 2),
                                                            ),
                                                          ],
                                                        ),
                                                        child: Column(
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          children: [
                                                            Text(
                                                              'Norms Analyzer',
                                                              style: TextStyle(
                                                                fontSize: widget.screenWidth * 0.015,
                                                                fontWeight: FontWeight.bold,
                                                                color: Colors.black87,
                                                              ),
                                                            ),
                                                            SizedBox(height: widget.screenHeight * 0.01),
                                                            Text(
                                                              'This AI application streamlines the process of extracting norms from documents across different OEMs using RAG. The application provides a clear visualization of norms data, presenting them in an organized tabular format for easy comparison, helping engineers and compliance teams quickly identify differences and similarities between OEM requirements.',
                                                              style: TextStyle(
                                                                fontSize: widget.screenWidth * 0.012,
                                                                color: Colors.black54,
                                                                fontWeight: FontWeight.w600,
                                                              ),
                                                            ),
                                                            SizedBox(height: widget.screenHeight * 0.02),
                                                            GestureDetector(
                                                              onTap: () {
                                                                Navigator.push(
                                                                  context,
                                                                  MaterialPageRoute(
                                                                    builder: (context) => norms_analyser_home_page.ChatLayout(),
                                                                  ),
                                                                );
                                                              },
                                                              child: Container(
                                                                width: widget.screenWidth * 0.185,
                                                                height: widget.screenHeight * 0.07,
                                                                decoration: BoxDecoration(
                                                                  color: Colors.blue,
                                                                  borderRadius: BorderRadius.circular(10),
                                                                ),
                                                                child: Center(
                                                                  child: Text(
                                                                    'Explore',
                                                                    style: TextStyle(
                                                                      color: Colors.white,
                                                                      fontSize: widget.screenWidth * 0.014,
                                                                      fontWeight: FontWeight.w500,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  SizedBox(height: widget.screenHeight * 0.05),
                                                  
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    

                                    // Purchase Tab
                                    Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.vertical(
                                          bottom: Radius.circular(20),
                                        ),
                                        color: const Color.fromARGB(
                                            255, 234, 239, 243),
                                      ),
                                      padding: EdgeInsets.only(
                                        top: widget.screenHeight * 0.05,
                                        left: widget.screenWidth * 0.05,
                                        right: widget.screenWidth * 0.05,
                                      ),
                                      alignment: Alignment.topLeft,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            width: widget.screenWidth * 0.6,
                                            height: widget.screenHeight * 0.5,
                                            padding: EdgeInsets.all(
                                                widget.screenWidth * 0.02),
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.black
                                                      .withOpacity(0.1),
                                                  blurRadius: 5,
                                                  offset: Offset(0, 2),
                                                ),
                                              ],
                                            ),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  'Purchase Assistant',
                                                  style: TextStyle(
                                                    fontSize:
                                                        widget.screenWidth *
                                                            0.015,
                                                    fontWeight: FontWeight.bold,
                                                    color: Colors.black87,
                                                  ),
                                                ),
                                                SizedBox(
                                                    height:
                                                        widget.screenHeight *
                                                            0.01),
                                                Row(
                                                  children: [
                                                    Container(
                                                      width: widget.screenWidth * 0.26,
                                                      // padding: const EdgeInsets.all(16.0),
                                                      child: SingleChildScrollView(
                                                        child: Text(
                                                          'You can access this AI-powered application to analyze and compare vendor requirement documents, with results automatically transformed into PowerPoint presentations featuring visual elements like tables and charts. Simply upload your vendor documents to quickly generate presentations highlighting key differences, helping stakeholders evaluate vendor offerings efficiently.',
                                                          style: TextStyle(
                                                            fontSize:
                                                                widget.screenWidth *
                                                                    0.012,
                                                            color: Colors.black54,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                          ),
                                                          // textAlign: TextAlign.justify,
                                                        ),
                                                      ),
                                                    ),
                                                     SizedBox(
                                                      width: widget.screenWidth *0.3,
                                                      height: widget.screenHeight*0.3,              
                                                      // child: SvgPicture.asset('assets/Pesales.svg', color: Colors.lightBlue,)
                                                      child: Image.asset('assets/Pesales.png',),
                                                      ),
                                                  ],
                                                ),

                                               
                                                SizedBox(
                                                    height:
                                                        widget.screenHeight *
                                                            0.01),
                                                GestureDetector(
                                                  onTap: () {
                                                    Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                          builder: (context) =>
                                                              rfq_home_page
                                                                  .HomePage()), // Use the alias to navigate
                                                    );
                                                  },
                                                  child: Container(
                                                    width: widget.screenWidth *
                                                        0.185,
                                                    height:
                                                        widget.screenHeight *
                                                            0.07,
                                                    // padding: EdgeInsets.only(
                                                    decoration: BoxDecoration(
                                                      color: Colors.blue,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              8),
                                                    ),
                                                    child: Center(
                                                      child: Text(
                                                        'Explore',
                                                        style: TextStyle(
                                                          color: Colors.white,
                                                          fontSize: widget
                                                                  .screenWidth *
                                                              0.014,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),

                                    // HR Tab
                                    Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.vertical(
                                          bottom: Radius.circular(20),
                                        ),
                                        color: const Color.fromARGB(
                                            255, 234, 239, 243),
                                      ),
                                      padding: EdgeInsets.only(
                                        top: widget.screenHeight * 0.05,
                                        left: widget.screenWidth * 0.05,
                                        right: widget.screenWidth * 0.05,
                                      ),
                                      alignment: Alignment.topLeft,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            width: widget.screenWidth * 0.6,
                                            height: widget.screenHeight * 0.5,
                                            padding: EdgeInsets.all(
                                                widget.screenWidth * 0.02),
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.black
                                                      .withOpacity(0.1),
                                                  blurRadius: 5,
                                                  offset: Offset(0, 2),
                                                ),
                                              ],
                                            ),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  'HR Assistant',
                                                  style: TextStyle(
                                                    fontSize:
                                                        widget.screenWidth *
                                                            0.015,
                                                    fontWeight: FontWeight.bold,
                                                    color: Colors.black87,
                                                  ),
                                                ),
                                                SizedBox(
                                                    height:
                                                        widget.screenHeight *
                                                            0.01),
                                                Row(
                                                  children: [
                                                    Container(
                                                      width: widget.screenWidth * 0.25,
                                                      child: Text(
                                                        'HR Assistant simplifies and enhances the efficiency of the hiring process by providing a user-friendly platform. Helps in creating JDs and systematically evaluating CVs against these specifications, ensuring a thorough and data-driven approach to candidate selection.\n',
                                                        style: TextStyle(
                                                            fontSize:
                                                                widget.screenWidth *
                                                                    0.012,
                                                            color: Colors.black54,
                                                            fontWeight:
                                                                FontWeight.w600),
                                                      ),
                                                    ),

                                                    SizedBox(
                                                      width: widget.screenWidth *0.3,
                                                      height: widget.screenHeight*0.3,              
                                                      // child: SvgPicture.asset('assets/Pesales.svg', color: Colors.lightBlue,)
                                                      child: Image.asset('assets/hr_image.png',),
                                                      ),
                                                  ],
                                                ),
                                                SizedBox(
                                                    height:
                                                        widget.screenHeight *
                                                            0.01),
                                                GestureDetector(
                                                  onTap: () {
                                                    Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                          builder: (context) =>
                                                              hr_home_page
                                                                  .HomePage()),
                                                    );
                                                  },
                                                  child: Container(
                                                    width: widget.screenWidth *
                                                        0.185,
                                                    height:
                                                        widget.screenHeight *
                                                            0.07,
                                                    // padding: EdgeInsets.only(
                                                    decoration: BoxDecoration(
                                                      color: Colors.blue,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              8),
                                                    ),
                                                    child: Center(
                                                      child: Text(
                                                        'Explore',
                                                        style: TextStyle(
                                                          color: Colors.white,
                                                          fontSize: widget
                                                                  .screenWidth *
                                                              0.014,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: widget.screenHeight * 0.05)
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Container(
                  //   height: widget.screenHeight * 0.13,
                  //   color: const Color.fromARGB(255, 32, 52, 92),
                  //   padding: EdgeInsets.all(widget.screenWidth * 0.01),
                  //   child: Row(
                  //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //     children: [
                  //       Column(
                  //         children: [
                  //           SvgPicture.asset(
                  //             'assets/Acsia_logo.svg',
                  //             height: widget.screenHeight * 0.04,
                  //             // colorFilter: ColorFilter.mode(
                  //             //   Colors.white,
                  //             //   BlendMode.srcIn,
                  //             // ),
                  //             color: Colors.white,
                  //           ),
                  //           SizedBox(
                  //             height: widget.screenHeight * 0.01,
                  //           ),
                  //           Row(
                  //             children: [
                  //               SvgPicture.asset(
                  //                 'assets/insta.svg',
                  //                 height: widget.screenHeight * 0.03,
                  //                 // colorFilter: ColorFilter.mode(
                  //                 //   Colors.white,
                  //                 //   BlendMode.srcIn,
                  //                 // ),
                  //                 color: Colors.white,
                  //               ),
                  //               SizedBox(
                  //                 width: widget.screenWidth * 0.01,
                  //               ),
                  //               SvgPicture.asset(
                  //                 'assets/linkedin.svg',
                  //                 height: widget.screenHeight * 0.03,
                  //                 // colorFilter: ColorFilter.mode(
                  //                 //   Colors.white,
                  //                 //   BlendMode.srcIn,
                  //                 // ),
                  //                 color: Colors.white,
                  //               ),
                  //             ],
                  //           )
                  //         ],
                  //       ),
                  //       Text(
                  //         'Copyright (C) 2025 Acsia Technologies Private Limited',
                  //         style: TextStyle(
                  //           color: Colors.white,
                  //           fontSize: widget.screenWidth * 0.01,
                  //         ),
                  //       ),
                  //     ],
                  //   ),
                  // ),

                  Container(
                    height: widget.screenHeight * 0.125,
                    color: const Color.fromARGB(255, 32, 52, 92),
                    padding: EdgeInsets.all(widget.screenWidth * 0.01),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Column(
                          children: [
                            SvgPicture.asset(
                              'assets/Acsia_logo.svg',
                              height: widget.screenHeight * 0.025,
                              width: widget.screenWidth * 0.01,
                              // colorFilter: ColorFilter.mode(
                              //   Colors.white,
                              //   BlendMode.srcIn,
                              // ),
                              color: Colors.white,
                            ),
                            SizedBox(
                              height: widget.screenHeight * 0.017,
                            ),

                            Padding(
                              padding: EdgeInsets.only(left: widget.screenWidth * 0.09,),
                              child: Text("Technology that drives Tomorrow.", style: TextStyle(fontSize: widget.screenHeight * 0.015, color: Colors.white),),
                            ),
                            // Row(
                            //   children: [
                            //     SvgPicture.asset(
                            //       'assets/insta.svg',
                            //       height: widget.screenHeight * 0.03,
                            //       // colorFilter: ColorFilter.mode(
                            //       //   Colors.white,
                            //       //   BlendMode.srcIn,
                            //       // ),
                            //       color: Colors.white,
                            //     ),
                            //     SizedBox(
                            //       width: widget.screenWidth * 0.01,
                            //     ),
                            //     SvgPicture.asset(
                            //       'assets/linkedin.svg',
                            //       height: widget.screenHeight * 0.03,
                            //       // colorFilter: ColorFilter.mode(
                            //       //   Colors.white,
                            //       //   BlendMode.srcIn,
                            //       // ),
                            //       color: Colors.white,
                            //     ),
                            //   ],
                            // )
                          ],
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: widget.screenWidth * 0.45,),
                          child: Text(
                            'Copyright (C) 2025 Acsia Technologies Private Limited',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: widget.screenWidth * 0.01,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),



              Positioned(
                top: widget.screenHeight*0.6,
                right: widget.screenWidth*0.015,
                child: GestureDetector(
                  onTap: () {
                    _showPopup();
                    // Define your action here
                    // print('Chat Bot tapped!');
                  },
                  child: Column(
                    children: [
                      Container(
                        height: widget.screenHeight*0.25,
                        width: widget.screenWidth*0.19,
                        child: Lottie.asset(
                          'assets/robot_blue.json', // Load the animation from the local asset
                          fit: BoxFit.fill, // Adjust the fit as needed
                        ),
                      ),
                      // const Text(
                      //   'LiLA Chat Bot',
                      //   style: TextStyle(
                      //     fontSize: 12,
                      //     color: Colors.black87,
                      //     fontWeight: FontWeight.w700,
                      //   ),
                      // ),
                    ],
                  ),
                ),
              ),

              if (_isPopupVisible) // Show the popup if it's visible
                Container(
                  alignment: Alignment.centerRight,
                  padding: EdgeInsets.only(right: widget.screenWidth * 0.146, top: widget.screenHeight*0.12),
                  // color: Colors.black54, // Semi-transparent background
                  child: Stack(
                    children: [
                      Container(
                        // Increase the width and height here
                        width:
                            widget.screenWidth * 0.3, // Adjusted width for larger popup
                        height: widget.screenHeight *
                            0.75, // Adjusted height for larger popup
                        decoration: BoxDecoration(
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.2),
                              blurRadius: 10,
                              spreadRadius: 2,
                            ),
                          ],
                          borderRadius: BorderRadius.circular(
                              12), // Added curve to the whole container
                        ),
                        child: Column(
                          children: [
                            // Top container for heading and subheading
                            Container(
                              decoration: BoxDecoration(
                                color: const Color.fromARGB(252, 107, 202, 247), // Set the background color
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.3),
                                    blurRadius: 10,
                                    spreadRadius: 1,
                                  ),
                                ],
                                borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(12),
                                  topRight: Radius.circular(12),
                                ),
                              ),
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Padding(
                                        padding: EdgeInsets.only(
                                            top: widget.screenWidth * 0.009,
                                            left: widget.screenWidth *
                                                0.12), // Adjusted left padding for main heading
                                        child: Text(
                                          'LiLA Chat Bot',
                                          style: TextStyle(
                                              fontSize: widget.screenWidth * 0.015,
                                              // fontWeight: FontWeight.bold,
                                              color: Colors.white,
                                              fontFamily: FontNames
                                                  .fontFamilyName // Change text color to white for contrast
                                              ),
                                        ),
                                      ),
                                      IconButton(
                                        padding: EdgeInsets.only(
                                            top: widget.screenWidth * 0.01,
                                            right: widget.screenWidth * 0.02),
                                        icon: const Icon(Icons.home,
                                            color: Colors
                                                .white), // Change icon color to white
                                        onPressed:
                                            _hidePopup, // Call the function to hide the popup
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            Expanded(
                              child: Padding(
                                padding: EdgeInsets.all(widget.screenWidth * 0.015),
                                child:
                                    const ChatSection(), // Assuming ChatSection is a defined widget
                              ),
                            ),
                          ],
                        ),
                      ),
                 
                      Positioned(
                        top: widget.screenWidth * 0.01, // Adjust the position as needed
                        left:
                            (widget.screenWidth * 0.01), // Center the circular container
                        child: Container(
                            width: widget.screenWidth *
                                0.08, // Width of the rectangular container
                            height: widget.screenHeight *
                                0.08, // Height of the rectangular container
                            decoration: BoxDecoration(
                              color: const Color.fromARGB(255, 245, 245,
                                  253), // Color of the rectangular container
                              borderRadius:
                                  BorderRadius.circular(15), // Curved edges
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.3),
                                  blurRadius: 10,
                                  spreadRadius: 1,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Image.asset('assets/acsia_logo.png')),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        )),
      ),
    );
  }

  Widget _buildHomeTab() {
    // Keeping the existing _buildHomeTab implementation
    return Container(
      padding: EdgeInsets.all(widget.screenWidth * 0.03),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Acsia Technologies',
            style: TextStyle(
              fontSize: widget.screenWidth * 0.02,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          SizedBox(height: widget.screenHeight * 0.02),
          Expanded(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Flexible(
                  flex: 2,
                  child: Text(
                    'Acsia is a global provider of automotive software powering Digital Cockpits & Displays, e-Mobility, and Telematics. Our capability spans AUTOSAR, Android Automotive, Automotive Linux, QNX, Human Machine Interface Development, Verification & Validation, AI/ML, Performance Optimization, Cybersecurity, and Functional Safety.'
                    '\n \nLiLA is Acsia’s AI/ML-powered automotive software developer suite designed to amplify efficiency, automate repetitive tasks, and deliver real-time insights that enhance project outcomes. '
                    ,
                    style: TextStyle(
                      fontSize: widget.screenWidth * 0.013,
                      color: Colors.black87,
                    ),
                  ),
                ),
                SizedBox(width: widget.screenWidth * 0.01),
                Flexible(
                  flex: 3,
                  child: Image.asset(
                    'assets/map_acsia.png',
                    fit: BoxFit.contain,
                    // colorFilter: ColorFilter.mode(
                    //   Colors.blueGrey,
                    //   BlendMode.srcIn,
                    // ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
