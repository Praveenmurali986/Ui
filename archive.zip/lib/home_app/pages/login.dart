import 'dart:convert';
import 'dart:html' as html;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'home_page.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool isCheckedRememberMe = false;
  bool isSignupMode = false;
  bool isAgreeTerms = false;

  final TextEditingController _nameControllerSignUp = TextEditingController();
  final TextEditingController _emailControllerSignUp = TextEditingController();
  final TextEditingController _passwordControllerSignUp =TextEditingController();
  final TextEditingController _confirmPasswordControllerSignUp =TextEditingController();
  final TextEditingController _userNameControllerLogin =TextEditingController();
  final TextEditingController _confirmEmailControllerLogin =TextEditingController();
  final TextEditingController _passwordControllerLogin =TextEditingController();
  // Function to show the success dialog
  // void _showSignUpSuccessDialog() {
  //   showDialog(
  //     context: context,
  //     builder: (context) {
  //       return AlertDialog(
  //         title: Center(child: Text('Sign Up Successful')),
  //         content: Text('Login again to continue', // Newline for 2 lines
  //         textAlign: TextAlign.center,),

  //         actions: [
  //           Center(
  //             child: TextButton(
  //               onPressed: () {
  //                 Navigator.of(context).pop(); // Close the dialog
  //               },
  //               child: Text('Close'),
  //             ),
  //           ),
  //         ],
  //       );
  //     },
  //   );
  // }

  // void _saveToLocalStorage() {
  //   // Create a Map of the data to be saved
  //   final userDetails = {
  //     // 'email': _emailController.text,
  //     // 'password': _passwordController.text,
  //     // 'confirm_password': _confirmPasswordController.text,
  //   };

  //   // Retrieve existing data from localStorage (if any)
  //   String existingData = html.window.localStorage['user_details'] ?? '[]';  // Default to empty list if no data

  //   // Try to decode the existing data as a List (even if it's empty)
  //   var decodedData = jsonDecode(existingData);

  //   // Ensure we're working with a List
  //   if (decodedData is! List) {
  //     print('Error: Expected a List, but found ${decodedData.runtimeType}');
  //     decodedData = []; // Default to empty list if not a List
  //   }

  //   // Add the new user details to the list
  //   decodedData.add(userDetails);

  //   // Encode the updated list as JSON
  //   final jsonString = jsonEncode(decodedData);

  //   // Save the updated list to localStorage
  //   html.window.localStorage['user_details'] = jsonString;

  //   // Print confirmation for debugging purposes
  //   print('Data saved to localStorage');
  // }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      body: SingleChildScrollView(
      child: Container(
        child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
        Container(
          width: screenWidth,
          height: screenHeight,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/background_login.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Stack(
            children: [
              // Logo positioned at top-left
              Positioned(
                top: screenWidth * 0.03,
                left: screenWidth * 0.03,
                child: SvgPicture.asset(
                  'assets/Lila Logo.svg',
                  width: screenWidth * 0.06,
                  height: screenWidth * 0.06,
                ),
              ),
        
              // Login container positioned on right side
              Positioned(
                right: screenWidth * 0.1,
                top: screenHeight * 0.15,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(40),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                    child: Container(
                      width: screenWidth * 0.35,
                      height: isSignupMode
                          ? screenHeight * 0.73
                          : screenHeight * 0.58, // Adjust height for signup
                      padding: EdgeInsets.all(screenWidth * 0.04),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.2),
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Text(
                            isSignupMode ? 'Create Account' : 'Welcome Back',
                            style: TextStyle(
                              fontSize: screenHeight * 0.04,
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                            ),
                          ),
                          SizedBox(height: screenHeight * 0.02),
                          if (isSignupMode)
                            SizedBox(
                              height: screenHeight * 0.06,
                              width: screenWidth * 0.27,
                              child: TextField(
                                decoration: InputDecoration(
                                  hintText: 'Name',
                                  filled: true,
                                  hintStyle:
                                      TextStyle(fontSize: screenWidth * 0.01),
                                  fillColor: Colors.white.withOpacity(0.5),
                                  contentPadding: EdgeInsets.symmetric(
                                      vertical: screenHeight * 0.015,
                                      horizontal: screenWidth * 0.01),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide.none,
                                  ),
                                ),
                              ),
                            ),
                          if (isSignupMode) SizedBox(height: screenHeight * 0.02),
                          if (isSignupMode)
                            SizedBox(
                              height: screenHeight * 0.06,
                              width: screenWidth * 0.27,
                              child: TextField(
                                decoration: InputDecoration(
                                  hintText: 'Email',
                                  filled: true,
                                  hintStyle:
                                      TextStyle(fontSize: screenWidth * 0.01),
                                  fillColor: Colors.white.withOpacity(0.5),
                                  contentPadding: EdgeInsets.symmetric(
                                      vertical: screenHeight * 0.015,
                                      horizontal: screenWidth * 0.01),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide.none,
                                  ),
                                ),
                              ),
                            ),
                          if (isSignupMode) SizedBox(height: screenHeight * 0.02),
                          if (!isSignupMode)
                            SizedBox(
                              height: screenHeight * 0.06,
                              width: screenWidth * 0.27,
                              child: TextField(
                                controller: _userNameControllerLogin,
                                decoration: InputDecoration(
                                  hintText: 'Username',
                                  filled: true,
                                  hintStyle:
                                      TextStyle(fontSize: screenWidth * 0.01),
                                  fillColor: Colors.white.withOpacity(0.5),
                                  contentPadding: EdgeInsets.symmetric(
                                      vertical: screenHeight * 0.015,
                                      horizontal: screenWidth * 0.01),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide.none,
                                  ),
                                ),
                              ),
                            ),
                          if (!isSignupMode)
                            SizedBox(height: screenHeight * 0.02),
                          if (!isSignupMode)
                            SizedBox(
                              height: screenHeight * 0.06,
                              width: screenWidth * 0.27,
                              child: TextField(
                                obscureText: true,
                                controller: _passwordControllerLogin,
                                decoration: InputDecoration(
                                  hintText: 'Password',
                                  hintStyle:
                                      TextStyle(fontSize: screenWidth * 0.01),
                                  filled: true,
                                  fillColor: Colors.white.withOpacity(0.5),
                                  contentPadding: EdgeInsets.symmetric(
                                      vertical: screenHeight * 0.015,
                                      horizontal: screenWidth * 0.01),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide.none,
                                  ),
                                ),
                              ),
                            ),
                          if (isSignupMode)
                            SizedBox(
                              height: screenHeight * 0.06,
                              width: screenWidth * 0.27,
                              child: TextField(
                                obscureText: true,
                                decoration: InputDecoration(
                                  hintText: 'Password',
                                  hintStyle:
                                      TextStyle(fontSize: screenWidth * 0.01),
                                  filled: true,
                                  fillColor: Colors.white.withOpacity(0.5),
                                  contentPadding: EdgeInsets.symmetric(
                                      vertical: screenHeight * 0.015,
                                      horizontal: screenWidth * 0.01),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide.none,
                                  ),
                                ),
                              ),
                            ),
                          if (isSignupMode) SizedBox(height: screenHeight * 0.02),
                          if (isSignupMode)
                            SizedBox(
                              height: screenHeight * 0.06,
                              width: screenWidth * 0.27,
                              child: TextField(
                                obscureText: true,
                                decoration: InputDecoration(
                                  hintText: 'Repeat Password',
                                  hintStyle:
                                      TextStyle(fontSize: screenWidth * 0.01),
                                  filled: true,
                                  fillColor: Colors.white.withOpacity(0.5),
                                  contentPadding: EdgeInsets.symmetric(
                                      vertical: screenHeight * 0.015,
                                      horizontal: screenWidth * 0.01),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide.none,
                                  ),
                                ),
                              ),
                            ),
                          if (!isSignupMode)
                            SizedBox(height: screenHeight * 0.01),
                          if (!isSignupMode)
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Checkbox(
                                      value: isCheckedRememberMe,
                                      onChanged: (bool? value) {
                                        setState(() {
                                          isCheckedRememberMe = value ?? false;
                                        });
                                      },
                                      checkColor: Colors.white60,
                                      activeColor: Colors.lightBlue,
                                      side: BorderSide(
                                        color: Colors.grey,
                                        width: 1.5,
                                      ),
                                    ),
                                    Text('Remember Me',
                                        style: TextStyle(
                                            fontSize: screenWidth * 0.01,
                                            color: Colors.white70,
                                            fontWeight: FontWeight.w100)),
                                  ],
                                ),
                                TextButton(
                                  onPressed: () {},
                                  child: Text('Forgot Password?',
                                      style: TextStyle(
                                          fontSize: screenWidth * 0.01,
                                          color: Colors.white70,
                                          fontWeight: FontWeight.w100)),
                                ),
                              ],
                            ),
                          if (isSignupMode) SizedBox(height: screenHeight * 0.01),
                          if (isSignupMode)
                            Row(
                              children: [
                                Checkbox(
                                  value: isAgreeTerms,
                                  onChanged: (bool? value) {
                                    setState(() {
                                      isAgreeTerms = value ?? false;
                                    });
                                  },
                                  checkColor: Colors.white60,
                                  activeColor: Colors.lightBlue,
                                  side: BorderSide(
                                    color: Colors.grey,
                                    width: 1.5,
                                  ),
                                ),
                                Text('I agree to the terms & conditions',
                                    style: TextStyle(
                                        fontSize: screenWidth * 0.01,
                                        color: Colors.white70,
                                        fontWeight: FontWeight.w100)),
                              ],
                            ),
                          SizedBox(height: screenHeight * 0.01),
                          SizedBox(
                            height: screenHeight * 0.06,
                            width: screenWidth * 0.27,
                            child: ElevatedButton(
                              onPressed: () {
                                if(_userNameControllerLogin.text =='admin' && _passwordControllerLogin.text == 'admin'){
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => AcsiaHomePage(
                                            screenWidth: screenWidth,
                                            screenHeight: screenHeight,
                                          )), // Use the alias to navigate
                                );
                                }
                              },
                              child: Text(isSignupMode ? 'Sign Up' : 'Login',
                                  style: TextStyle(
                                      fontSize: screenWidth * 0.012,
                                      color: Colors.white)),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.lightBlue,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: screenHeight * 0.01),
                          TextButton(
                            onPressed: () {
                              setState(() {
                                isSignupMode =
                                    !isSignupMode; // Toggle between login and signup mode
                              });
                            },
                            child: Center(
                              child: Text(
                                isSignupMode ? 'Login' : 'Signup',
                                style: TextStyle(
                                  fontSize: screenWidth * 0.012,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        // Container(
        //   width: screenWidth,
        //   height: screenHeight * 0.15, // Set the height of the footer
        //   decoration: BoxDecoration(
        //     color: Colors.white,
        //   ),
        //   child: Center(
        //     child: Text(
        // 'Copyright 2023',
        // style: TextStyle(
        //   fontSize: screenWidth * 0.01,
        //   color: Colors.black,
        // ),
        //     ),
        //   ),
        // ),
            ]
          
        ),
      ),
      )
    );
  }
}
