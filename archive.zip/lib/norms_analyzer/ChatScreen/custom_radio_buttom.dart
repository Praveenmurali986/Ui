import 'package:flutter/material.dart';

class CustomRadioButton extends StatelessWidget {
  final bool isSelected;
  final Function onPressed;
  final String label; // Label for the radio button
  final Color selectedColor;
  final Color unselectedColor;
  final Color borderColor;

  // Constructor with required parameters
  const CustomRadioButton({
    Key? key,
    required this.isSelected,
    required this.onPressed,
    required this.label,
    this.selectedColor = Colors.blue,
    this.unselectedColor = Colors.transparent,
    this.borderColor = Colors.grey,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Get screen dimensions
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;

    // Calculate size and font size based on screen dimensions
    double size = screenWidth * 0.012; // Adjust size based on screen width
    double fontSize =
        screenWidth * 0.012; // Adjust font size based on screen width

    return GestureDetector(
      onTap: () => onPressed(), // Handle tap
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Radio button (box) on the left
          Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(6),
              border: Border.all(
                color: isSelected ? selectedColor : borderColor, // Border color
                width: 2.0,
              ),
              color:
                  isSelected ? selectedColor : unselectedColor, // Inside color
            ),
            child: isSelected
                ? Icon(
                    Icons.check,
                    size: size * 0.75,
                    color: Colors.white,
                  )
                : Container(), // Empty if not selected
          ),
          const SizedBox(width: 8), // Space between radio button and label
          // Display the label to the right of the radio button
          Text(
            label,
            style: TextStyle(
              fontSize: fontSize, // Use responsive font size
              color: isSelected ? selectedColor : Colors.black,
            ),
          ),
        ],
      ),
    );
  }
}
