class PortURL {
  // static const baseURL = 'http://172.30.8.85:9005';
  static const baseURL = 'http://172.30.8.85:4120';
  // static const baseSocketURL = 'ws://172.18.14.2:4120/ws/chat';
    static const baseSocketURL = 'ws://172.30.8.209:4120/ws/chat';
 
}

class FontNames {
  static const fontFamilyName = 'Roboto';
  static const fontFamilyNameMono = 'mono';
}

class Names {
  // static const sideBarTitleName = '𝐀𝐮𝐭𝐨𝐬𝐚𝐫 𝐂𝐡𝐚𝐭𝐁𝐨𝐭';
  static const sideBarTitleName = 'AUTOSAR \nCHATBOT';

  static const hintTextName = 'Type a message...';
  static const defaultVendorName = 'OEM1';
  static const vendorNameOne = 'OEM1';
  static const vendorNameTwo = 'OEM2';

  static const uploadVisibilityButton = false;
}

class Messages {
  static const reponseMessage =
      'It seems like your message is incomplete or not properly formatted. Could you please provide the information again?';
}
