import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:login_signup_page/norms_analyzer/ChatScreen/Api_web_socket_service.dart';
import 'dart:typed_data';
import 'package:login_signup_page/norms_analyzer/ChatScreen/mark_down_list.dart';
import 'package:login_signup_page/norms_analyzer/ChatScreen/strings.dart';
import 'package:login_signup_page/norms_analyzer/ChatScreen/theme.dart';
import 'package:login_signup_page/norms_analyzer/ChatScreen/provider.dart';
import 'package:provider/provider.dart';
import 'package:flutter_svg/flutter_svg.dart';

class ChatSection extends StatefulWidget {
  const ChatSection({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _ChatSectionState createState() => _ChatSectionState();
}

class _ChatSectionState extends State<ChatSection> {
  final TextEditingController _controller = TextEditingController();
  final List<Map<String, dynamic>> _messages = [];
  List<String?>? _uploadedFileNames;
  List<Uint8List?>? _uploadedFiles;

  // final ApiService apiService = ApiService(PortURL.baseURL);
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(() {});
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients && _messages.isNotEmpty) {
      _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
    }
  }

  void _handleSendMessage(String clickedMessage, String selectedItem) {
    final String userMessage = _controller.text.trim();
    if (userMessage.isNotEmpty) {
      setState(() {
        _messages.add({'role': 'User ', 'content': userMessage});
      });
      _controller.clear();
      _getAIDAResponse(userMessage, clickedMessage, selectedItem);
      _scrollToBottom();
    }
  }

  void _getAIDAResponse(
      String userMessage, String clickedMessage, String selectedItem) async {
    if (userMessage.isEmpty) {
      String response = "Please enter a message.";

      setState(() {
        _messages.add({'role': 'assistant', 'content': response});
      });
    } else {
      try {
        WebSocketService webSocketService = WebSocketService();

        String partialResponse = '';
        setState(() {
          _messages.add({
            'role': 'assistant',
            'content': partialResponse,
          });
        });
        _scrollToBottom();
        // String jsonMessage =
        //     '{"messages": [{"role": "user", "content": "$userMessage","additional":"$clickedMessage","db_names":"$selectedItem"}]}';

       String OEMName = 'BMW';
        if (selectedItem == 'OEM1') {
          OEMName = 'BMW';
        } else if (selectedItem == 'OEM2') {
          OEMName = 'Mercedes';
        }
 
        String jsonMessage =
            '{"messages": [{"role": "user", "content": "$userMessage"}],"db_names":["${OEMName.toLowerCase()}"]}';

        webSocketService.channel.sink.add(jsonMessage);

        await for (var data in webSocketService.stream) {
          webSocketService.addToCurrentUserData(data);

          partialResponse = webSocketService.currentUserData;

          setState(() {
            if (_messages[_messages.length - 1]['role'] == 'assistant') {
              _messages[_messages.length - 1]['content'] = partialResponse;
            }
          });
          _scrollToBottom();
        }

        webSocketService.dispose();
      } catch (e) {
        setState(() {
          _messages.add({'role': 'assistant', 'content': 'Error: $e'});
        });
      }
    }
    _scrollToBottom();
  }

  void _uploadFiles() async {
    FilePickerResult? result =
        await FilePicker.platform.pickFiles(allowMultiple: true);
    if (result != null) {
      setState(() {
        _uploadedFileNames = result.files.map((file) => file.name).toList();
        _uploadedFiles = result.files.map((file) => file.bytes).toList();
        _messages.add({
          'role': 'User ',
          'content': 'Uploading   : ${_uploadedFileNames!.join(', ')}',
          'files': _uploadedFiles,
        });
        _sendFiles();
      });
    }
  }

  void _sendFiles() async {
    if (_uploadedFiles != null) {
      try {
        final files = _uploadedFiles!
            .where((file) => file != null)
            .map((file) => file!)
            .toList();
        // ignore: unused_local_variable
        // final response = await apiService.sendFiles(
        //   files,
        // );
        setState(() {
          _messages.add(
              {'role': 'assistant', 'content': 'Files uploaded successfully'});
        });
      } catch (e) {
        setState(() {
          _messages.add(
              {'role': 'assistant', 'content': 'Error uploading files: $e'});
        });
      }
      setState(() {
        _uploadedFiles = null;
        _uploadedFileNames = null;
      });
    }
  }

  @override
  void dispose() {
    super.dispose();
    _scrollController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final double screenHeight = MediaQuery.of(context).size.height;

    String clickedMessage =
        ModalRoute.of(context)!.settings.arguments as String? ??
            'Communication Services';

    // version getting from the provider
    String selectedItem =
        Provider.of<SelectedItemProvider>(context).selectedItem;

    double fontSize = (screenWidth / 80).clamp(8.0, 20.0);

    double iconSize = (screenWidth / 10).clamp(22.0, 24.0);
    double iconSizeAdd = (screenWidth / 25).clamp(10.0, 40.0);

    double minimumSize = (screenHeight * 0.1).clamp(50, 90);

    return Container(
      padding: EdgeInsets.all(screenWidth * 0.010),
      decoration: const BoxDecoration(
        color: AppTheme.lightBackgroundColor,
        borderRadius: BorderRadius.only(
          topRight: Radius.circular(30.0),
          bottomRight: Radius.circular(30.0),
        ),
      ),
      child: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final message = _messages[index];
                final isUser = message['role'] == 'User ';
                if (message.containsKey('files')) {
                  return Align(
                    alignment:
                        isUser ? Alignment.centerRight : Alignment.centerLeft,
                    child: Container(
                      padding: const EdgeInsets.all(15),
                      margin: const EdgeInsets.symmetric(
                          vertical: 5, horizontal: 10),
                      decoration: BoxDecoration(
                        color: isUser
                            ? (AppTheme.lightSecondaryColor)
                            : (AppTheme.lightPrimaryColor),
                        borderRadius:
                            const BorderRadius.all(Radius.circular(1)),
                      ),
                      child: SelectableText(
                        message['content']!,
                        style: TextStyle(
                            fontSize: screenWidth * 0.012,
                            color: AppTheme.lightTextColor,
                            fontWeight: FontWeight.normal,
                            fontFamily: FontNames.fontFamilyName),
                      ),
                    ),
                  );
                } else {
                  return Align(
                    alignment:
                        isUser ? Alignment.centerRight : Alignment.centerLeft,
                    child: Container(
                      padding: EdgeInsets.all(screenWidth * 0.012),
                      margin: const EdgeInsets.symmetric(
                          vertical: 2, horizontal: 10),
                      decoration: BoxDecoration(
                        color: isUser
                            ? (AppTheme.lightPrimaryColor)
                            : (AppTheme.lightBackgroundColor),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: isUser
                          ? SelectableText(
                              message['content'],
                              style: TextStyle(
                                color: AppTheme.lightTextColor,
                                // fontSize: screenWidth * 0.013,
                                fontSize: fontSize,
                                fontWeight: FontWeight.normal,
                              ),
                            )
                          : MarkdownBody(
                              selectable: true,
                              data: message['content'],
                              styleSheet: MarkdownStyles.getMarkdownStyleSheet(
                                  false, context),
                            ),
                    ),
                  );
                }
              },
            ),
          ),
          Row(
            children: [
              Visibility(
                visible: Names.uploadVisibilityButton,
                child: PopupMenuButton(
                  icon: Container(
                    padding: const EdgeInsets.all(12.0),
                    decoration: BoxDecoration(
                      color: AppTheme.lightUploadIconBackgroundColor,
                      borderRadius: BorderRadius.circular(screenWidth * 0.06),
                      boxShadow: [
                        BoxShadow(
                          color: AppTheme.darkShadowColor,
                          blurRadius: 0.1,
                          spreadRadius: 0.5,
                        ),
                      ],
                    ),
                    child: Icon(
                      size: iconSizeAdd,
                      Icons.add,
                      color: AppTheme.lightUploadIconColor,
                    ),
                  ),
                  itemBuilder: (context) => [
                    PopupMenuItem(
                      onTap: _uploadFiles,
                      child: const Row(
                        children: [
                          Icon(Icons.upload_file),
                          SizedBox(width: 8),
                          SelectableText('Upload Files'),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: AppTheme.lightPromptAreaColor, // Background color
                    borderRadius:
                        BorderRadius.circular(10.0), // Rounded corners
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1), // Shadow color
                        spreadRadius: 2, // Spread radius
                        blurRadius: 5, // Blur radius
                        offset: const Offset(0, 3), // Offset for the shadow
                      ),
                    ],
                  ),
                  child: TextField(
                    controller: _controller,
                    cursorHeight: fontSize,
                    style: TextStyle(
                      height: screenHeight * 0.003,
                      fontSize: fontSize,
                      color: AppTheme.lightTextColor,
                      fontWeight: FontWeight.normal,
                    ),
                    decoration: InputDecoration(
                      hintText: Names.hintTextName,
                      hintStyle: TextStyle(
                        fontSize: fontSize,
                        color: AppTheme.lightTextColor
                            .withOpacity(0.5), // Adjust opacity if needed
                      ),
                      border: InputBorder.none, // Remove the outline
                      contentPadding: const EdgeInsets.all(
                          16), // Padding inside the TextField
                    ),
                    onSubmitted: (value) {
                      _handleSendMessage(clickedMessage, selectedItem);
                    },
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Container(
                decoration: BoxDecoration(
                  color: AppTheme
                      .lightUploadIconBackgroundColor, // Match the TextField background color
                  borderRadius: BorderRadius.circular(
                      10.0), // Match the TextField border radius
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.darkShadowColor
                          .withOpacity(0.1), // Match the shadow color
                      spreadRadius: 2, // Spread radius for elevation
                      blurRadius: 5, // Blur radius for elevation
                      offset: const Offset(0, 3), // Offset for the shadow
                    ),
                  ],
                ),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    elevation: 10, // Set to 0 to avoid double elevation effect
                    shadowColor: Colors.transparent, // No additional shadow
                    minimumSize: Size(
                      minimumSize, // Adjusted minimum size for a circular button
                      minimumSize, // Make it square to fit the circular shape
                    ),
                    backgroundColor: Colors
                        .transparent, // Make the button background transparent
                    // shape: const CircleBorder(), // Keep the button circular
                  ),
                  onPressed: () =>
                      _handleSendMessage(clickedMessage, selectedItem),
                  child: SvgPicture.asset(
                    'assets/send_icon.svg', // Path to your SVG asset
                    semanticsLabel:
                        'Your SVG Image', // Optional label for accessibility
                    height: iconSize, // Set the height to match the icon size
                    width: iconSize, // Set the width to match the icon size
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
