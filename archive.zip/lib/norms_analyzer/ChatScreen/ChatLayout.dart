import 'package:flutter/material.dart';
import 'package:login_signup_page/norms_analyzer/ChatScreen/chatscreen.dart';
import 'package:login_signup_page/norms_analyzer/ChatScreen/custom_radio_buttom.dart';
import 'package:login_signup_page/norms_analyzer/ChatScreen/strings.dart';
import 'package:login_signup_page/norms_analyzer/ChatScreen/theme.dart';
import 'package:login_signup_page/norms_analyzer/ChatScreen/topBar.dart';
import 'package:login_signup_page/norms_analyzer/ChatScreen/provider.dart';
import 'package:provider/provider.dart';

class ChatLayout extends StatefulWidget {
  const ChatLayout({super.key});

  @override
  _ChatLayoutState createState() => _ChatLayoutState();
}

class _ChatLayoutState extends State<ChatLayout> {
  String _selectedItem = Names.defaultVendorName; // Store selected item

  // Function to update the selected radio button
  void _selectItem(String item) {
    setState(() {
      if (_selectedItem == item) {
        _selectedItem = ''; // Deselect if the same item is tapped
      } else {
        _selectedItem = item;
      }
    });
    Provider.of<SelectedItemProvider>(context, listen: false)
        .updateSelectedItem(_selectedItem);
  }

  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.of(context).size.height;
    double screenWidth = MediaQuery.of(context).size.width;
    double screenPadding = screenWidth * 0.010;

    // print('screenWidth : $screenWidth and screenHeight : $screenHeight');

    // Define thresholds for visibility
    double chatAreaThreshold = 170; // Height threshold for Chat Area
    double selectionThresholdHeight = 260;
    double selectionThresholdWidth = 630; // Width threshold for Selection Area

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.white,
              Colors.white,
            ],
          ),
        ),
        child: Row(
          children: [
            // Vertical Icon Container on the left
            if (screenHeight > chatAreaThreshold) ...[
              Container(
                margin: EdgeInsets.all(screenPadding),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15.0),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      spreadRadius: 3,
                      blurRadius: 5,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: const TopBar(), // Use the new VerticalIconContainer
              ),

              // Check if the available height is sufficient for the Chat Area
              Expanded(
                flex: 5,
                child: Container(
                  margin: EdgeInsets.only(
                      left: screenWidth * 0.005,
                      top: screenPadding,
                      bottom: screenPadding,
                      right: screenPadding),
                  padding: EdgeInsets.only(
                      top: screenWidth * 0.012,
                      bottom: screenWidth * 0.012,
                      right: screenWidth * 0.012),
                  decoration: BoxDecoration(
                    color: AppTheme.lightBackgroundColor,
                    borderRadius: BorderRadius.circular(screenWidth * 0.015),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        spreadRadius: 3,
                        blurRadius: 5,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      if (screenHeight > selectionThresholdHeight &&
                          screenWidth > selectionThresholdWidth) ...[
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                            padding: EdgeInsets.only(
                                left: screenWidth * 0.02,
                                top: screenWidth * 0.005),
                            child: Container(
                              width: screenWidth * 0.22,
                              alignment: Alignment.centerLeft,
                              padding: EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(
                                      screenWidth * 0.010),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withAlpha(42),
                                      spreadRadius: 3,
                                      blurRadius: 3,
                                      // offset: const Offset(0, 3),
                                    ),
                                  ]),
                              child: Padding(
                                padding:
                                    EdgeInsets.only(left: screenWidth * 0.01),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    CustomRadioButton(
                                      isSelected: _selectedItem ==
                                          Names
                                              .vendorNameOne, // Check if selected
                                      onPressed: () => _selectItem(
                                          Names.vendorNameOne), // Select BMW
                                      label: Names
                                          .vendorNameOne, // Display the label on the left
                                    ),
                                    SizedBox(width: screenWidth * 0.01),
                                    CustomRadioButton(
                                      isSelected: _selectedItem ==
                                          Names
                                              .vendorNameTwo, // Check if selected
                                      onPressed: () => _selectItem(
                                          Names.vendorNameTwo), // Select BENZ
                                      label: Names
                                          .vendorNameTwo, // Display the label on the left
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],

                      // Ensure the `ChatSection` gets a bounded size
                      SizedBox(height: screenHeight * 0.006),
                      Expanded(
                        child: ClipRRect(
                          borderRadius: BorderRadius.all(
                              Radius.circular(screenWidth * 0.0009)),
                          child: ChatSection(),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
