// selected_version_provider.dart
import 'package:flutter/material.dart';
import 'package:login_signup_page/norms_analyzer/ChatScreen/strings.dart';

class SelectedItemProvider with ChangeNotifier {
  String _selectedItem = Names.defaultVendorName; // Default value

  String get selectedItem => _selectedItem;

  void updateSelectedItem(String newItem) {
    _selectedItem = newItem;
    notifyListeners(); // Notify listeners about the change
  }
}
