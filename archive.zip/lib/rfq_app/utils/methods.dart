// lib/utils/methods.dart

import 'dart:async';
import 'dart:typed_data';
import 'dart:convert';
import 'package:login_signup_page/rfq_app//pages/full_screen_page.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:file_picker/file_picker.dart';
import 'dart:html' as html;
import 'package:device_apps/device_apps.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:android_intent/android_intent.dart';
import 'package:open_file/open_file.dart';
import 'dart:io';
import 'package:process_run/shell.dart';
import 'dart:async';
import 'dart:typed_data';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'dart:io';

// Method to download the comparison result as a text file LINUX

// Future<void> downloadComparisonResult(
//   BuildContext context,
//   String comparisonResult,
//   Uint8List? _fileBytes1,
//   Uint8List? _fileBytes2,
//   String? _fileName1,
//   String? _fileName2,
// ) async {
//   if (comparisonResult.isEmpty) {
//     ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
//       content: Text('No comparison result to download.'),
//     ));
//     return;
//   }

//   // Show dialog to choose file format
//   final result = await showDialog<String>(
//     context: context,
//     builder: (context) {
//       return AlertDialog(
//         title: Text('Choose file format', textAlign: TextAlign.center),
//         actions: [
//           TextButton(
//             onPressed: () {
//               Navigator.of(context).pop('text');
//             },
//             child: Text('Text File'),
//           ),
//           TextButton(
//             onPressed: () {
//               Navigator.of(context).pop('excel');
//             },
//             child: Text('Excel File'),
//           ),
//         ],
//       );
//     },
//   );

//   // Get the application documents directory
//   // final directory = await getDownloadsDirectory();
//     final directory = await getApplicationDocumentsDirectory();


//   if (result == 'text') {
//     // Download as Text File
//     final filePath = '${directory.path}/comparison_result.txt';
//     final file = File(filePath);

//     await file.writeAsString(comparisonResult);
//     _showDownloadSuccessDialog(context, filePath);
//   } else if (result == 'excel') {
//     // Download Excel File by sending HTTP request
//     var request = http.MultipartRequest('GET', Uri.parse('http://172.30.8.209:8080/download_xl/'));

//     // Assuming you need to send the files again for comparison or additional data
//     request.files.add(http.MultipartFile.fromBytes('file1', _fileBytes1!, filename: _fileName1));
//     request.files.add(http.MultipartFile.fromBytes('file2', _fileBytes2!, filename: _fileName2));
//     request.headers.addAll({'accept': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});

//     try {
//       // Send the request and get the response
//       var response = await request.send();
//       if (response.statusCode == 200) {
//         // Read the bytes of the Excel file from the response
//         final bytes = await response.stream.toBytes();

//         // Save the Excel file
//         final excelFilePath = '${directory.path}/comparison_result.xlsx';
//         final excelFile = File(excelFilePath);
//         await excelFile.writeAsBytes(bytes);

//         _showDownloadSuccessDialog(context, excelFilePath);
//         openRecentDownload('xlsx');
//       } else {
//         throw Exception('Failed to download Excel file: ${response.statusCode}');
//       }
//     } catch (e) {
//       ScaffoldMessenger.of(context).showSnackBar(SnackBar(
//         content: Text('Error: $e'),
//       ));
//     }
//   }
// }

// // Method to download PPT file
// Future<void> downloadPPT(
//   BuildContext context,
//   Uint8List? fileBytes,
//   String? fileName,
// ) async {
//   if (fileBytes != null) {
//     try {
//       // Get the application documents directory
//       // final directory = await getDownloadsDirectory();
//           final directory = await getApplicationDocumentsDirectory();


//       var request = http.MultipartRequest(
//         'POST', Uri.parse('http://172.30.8.209:8080/ppt/')
//       );

//       // Add the file bytes and file name
//       request.files.add(http.MultipartFile.fromBytes('xl_file', fileBytes, filename: fileName));
//       request.headers.addAll({'accept': 'application/vnd.openxmlformats-officedocument.presentationml.presentation'});

//       var response = await request.send();

//       if (response.statusCode == 200) {
//         // Await the response stream to get the bytes of the PPTX file
//         final bytes = await response.stream.toBytes();

//         // Save the PPTX file
//         final pptFilePath = '${directory.path}/presentation.pptx';
//         final pptFile = File(pptFilePath);
//         await pptFile.writeAsBytes(bytes);

//         // Show success dialog after download
//         _showDownloadSuccessDialog(context, pptFilePath);
//         openRecentDownload('pptx');
//       } else {
//         throw Exception('Failed to download PPTX file: ${response.statusCode}');
//       }
//     } catch (e) {
//       ScaffoldMessenger.of(context).showSnackBar(SnackBar(
//         content: Text('Error: $e'),
//       ));
//     }
//   } else {
//     ScaffoldMessenger.of(context).showSnackBar(SnackBar(
//       content: Text('Please select a file first.'),
//     ));
//   }
// }

// Function to show success dialog with file path
// void _showDownloadSuccessDialog(BuildContext context, String filePath) {
//   showDialog(
//     context: context,
//     builder: (BuildContext context) {
//       return AlertDialog(
//         title: Text('Download Successful'),
//         content: Text('The file has been downloaded successfully at $filePath.'),
//         actions: <Widget>[
//           TextButton(
//             onPressed: () {
//               Navigator.of(context).pop();  // Close the dialog
//             },
//             child: Text('OK'),
//           ),
//         ],
//       );
//     },
//   );
// }

String comparisonResult='';

String formatElapsedTime(int seconds) {
  // print(seconds);
  if (seconds < 60) {
    return '$seconds s';
  } else if (seconds < 3600) {
    int minutes = seconds ~/ 60;
    int remainingSeconds = seconds % 60;
    return '${minutes}m ${remainingSeconds}s';
  } else {
    int hours = seconds ~/ 3600;
    int minutes = (seconds % 3600) ~/ 60;
    int remainingSeconds = seconds % 60;
    return '${hours}h ${minutes}m ${remainingSeconds}s';
  }
}



// Future<String?> compareFiles(
//   BuildContext context,
//   Function setState,
//   Uint8List? _fileBytes1,
//   Uint8List? _fileBytes2,
//   String? _fileName1,
//   String? _fileName2,
//   bool _isLoading,
//   int _elapsedTime,
//   String comparisonResult
// ) async {
//   if (_fileBytes1 == null || _fileBytes2 == null) {
//     ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
//       content: Text('Please select both files to compare.'),
//     ));
//     return null;
//   }

//   // Start the timer before starting the comparison
//   Timer? _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
//     setState(() {
//       // print(_elapsedTime);
//       _elapsedTime++;
//     });
//   });

//   setState(() {
//     _isLoading = true;
//     _elapsedTime = 0;  // Reset elapsed time when the comparison starts
//   });

//   var request = http.MultipartRequest('POST', Uri.parse('http://172.30.8.209:8080/doc-compare/'));
//   request.files.add(http.MultipartFile.fromBytes('file1', _fileBytes1!, filename: _fileName1));
//   request.files.add(http.MultipartFile.fromBytes('file2', _fileBytes2!, filename: _fileName2));
//   request.headers.addAll({'accept': 'application/json'});

//   try {
//     var response = await request.send();
//     if (response.statusCode == 200) {
//       String result = await response.stream.bytesToString();
//       Map<String, dynamic> jsonResponse = jsonDecode(result);
//       var comparisonValue = jsonResponse['comparison'];

//       setState(() {
//         comparisonResult = comparisonValue;
//         _isLoading = false;
//       });

//       _timer.cancel();  // Stop the timer once the comparison is complete

//       // Return the comparison result
//       return comparisonResult;  // This will return the comparison result
//     } else {
//       throw Exception('Failed to compare files: ${response.statusCode}');
//     }
//   } catch (e) {
//     setState(() {
//       _isLoading = false;
//     });
//     _timer.cancel();
//     ScaffoldMessenger.of(context).showSnackBar(SnackBar(
//       content: Text('Error: $e'),
//     ));
//     return null;  // In case of error, return null
//   }
// }

Future<String?> compareFiles(
  BuildContext context,
  Uint8List? _fileBytes1,
  Uint8List? _fileBytes2,
  String? _fileName1,
  String? _fileName2,
  String comparisonResult
) async {
  if (_fileBytes1 == null || _fileBytes2 == null) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('Please select both files to compare.'),
    ));
    return null;
  }


  var request = http.MultipartRequest('POST', Uri.parse('http://172.30.8.209:8080/doc-compare/'));
  request.files.add(http.MultipartFile.fromBytes('file1', _fileBytes1!, filename: _fileName1));
  request.files.add(http.MultipartFile.fromBytes('file2', _fileBytes2!, filename: _fileName2));
  request.headers.addAll({'accept': 'application/json'});

  try {
    var response = await request.send();
    if (response.statusCode == 200) {
      String result = await response.stream.bytesToString();
      Map<String, dynamic> jsonResponse = jsonDecode(result);
      var comparisonValue = jsonResponse['comparison'];
      comparisonResult= comparisonValue;


      // Return the comparison result
      return comparisonResult;  // This will return the comparison result
    } else {
      throw Exception('Failed to compare files: ${response.statusCode}');
    }
  } catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Error: $e'),
    ));
    return null;  // In case of error, return null
  }
}


void showFullscreenResult(String comparisonResult, BuildContext context) {
    if (comparisonResult.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('No comparison result to display.'),
      ));
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MarkdownDisplayPage(markdownData: comparisonResult),
      ),
    );
  }


  // Method to download the comparison result as a text file
  void downloadComparisonResult(BuildContext context, String comparisonResult,Uint8List? _fileBytes1,
  Uint8List? _fileBytes2,
  String? _fileName1,
  String? _fileName2,) async {
  if (comparisonResult.isEmpty) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('No comparison result to download.'),
    ));
    return;
  }

  // Show dialog to choose file format
  final result = await showDialog<String>(
    context: context,
    builder: (context) {
      return AlertDialog(
        // contentPadding: EdgeInsets.only(left: MediaQuery.of(context).size.width*0.01),
        title: Text('Choose file format',textAlign: TextAlign.center,),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop('text');
            },
            iconAlignment: IconAlignment.start,
            child: Text('Text File'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop('excel');
            },
            child: Text('Excel File'),
          ),
        ],
      );
    },
  );

  if (result == 'text') {
    // Download as Text File
    final blob = html.Blob([comparisonResult], 'text/plain', 'native');
    final url = html.Url.createObjectUrlFromBlob(blob);
    final anchor = html.AnchorElement(href: url)
      ..target = 'blank'
      ..setAttribute('download', 'comparison_result.txt')
      ..click();
    html.Url.revokeObjectUrl(url);
    _showDownloadSuccessDialog(context);
  } else if (result == 'excel') {
    // Download Excel File by sending HTTP request
    var request = http.MultipartRequest('GET', Uri.parse('http://172.18.14.2:8080/download_xl/'));

    // Assuming you need to send the files again for comparison or additional data
    request.files.add(http.MultipartFile.fromBytes('file1', _fileBytes1!, filename: _fileName1));
    request.files.add(http.MultipartFile.fromBytes('file2', _fileBytes2!, filename: _fileName2));
    request.headers.addAll({'accept': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}); // Ensure the server knows you want Excel.

    try {
      // Send the request and get the response
      var response = await request.send();
      if (response.statusCode == 200) {
        // Read the bytes of the Excel file from the response
        final bytes = await response.stream.toBytes();

        // Create a Blob from the bytes
        final blob = html.Blob([bytes], 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'native');
        
        // Create a download URL for the Blob
        final url = html.Url.createObjectUrlFromBlob(blob);
        
        // Create an anchor element to trigger the download
        final anchor = html.AnchorElement(href: url)
          ..target = 'blank'
          ..setAttribute('download', 'comparison_result.xlsx')
          ..click();

        // Revoke the object URL to release memory
        html.Url.revokeObjectUrl(url);
        // ignore: use_build_context_synchronously
        _showDownloadSuccessDialog(context);
        // await openRecentDownload();

        
      } else {
        // Handle the case where the server response is not 200 OK
        throw Exception('Failed to download Excel file: ${response.statusCode}');
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Error: $e'),
      ));
    }
  }
}

Future<void> downloadPPT(
  BuildContext context,
  Uint8List? fileBytes,
  String? fileName,
) async {
  if (fileBytes != null) {
    try {
      var request = http.MultipartRequest(
        'POST', Uri.parse('http://172.18.14.2:8080/ppt/')
      );

      // Add the file bytes and file name
      request.files.add(http.MultipartFile.fromBytes('xl_file', fileBytes, filename: fileName));
      request.headers.addAll({'accept': 'application/vnd.openxmlformats-officedocument.presentationml.presentation'});

      var response = await request.send();

      if (response.statusCode == 200) {
        // Await the response stream to get the bytes of the PPTX file
        final bytes = await response.stream.toBytes();

        // Create a Blob from the PPTX bytes
        final blob = html.Blob([bytes], 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'native');

        // Create a download URL for the Blob
        final url = html.Url.createObjectUrlFromBlob(blob);

        // Create an anchor element to trigger the download
        final anchor = html.AnchorElement(href: url)
          ..target = 'blank'
          ..setAttribute('download', 'presentation.pptx')  // Ensure file is downloaded as .pptx
          ..click();

        // Revoke the object URL to release memory
        html.Url.revokeObjectUrl(url);

        // Show success dialog after download
        _showDownloadSuccessDialog(context);
      } else {
        throw Exception('Failed to download PPTX file: ${response.statusCode}');
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Error: $e'),
      ));
    }
  } else {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Please select a file first.'),
    ));
  }
}

// Function to show success dialog
void _showDownloadSuccessDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text('Download Successful'),
        content: Text('The file has been downloaded successfully.'),
        actions: <Widget>[
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();  // Close the dialog
            },
            child: Text('OK'),
          ),
        ],
      );
    },
  );
}


Future<String?> getAppPath(String appName) async {
    try {
      // Run the 'which' command to find the application path
      ProcessResult result = await Process.run('which', [appName]);
      if (result.exitCode == 0) {
        return result.stdout.trim(); // Return the path
      } else {
        print('Application not found');
        return null;
      }
    } catch (e) {
      print('Error: $e');
      return null;
    }
  }

  Future<void> openAppWithFile(String appPath, String filePath) async {
    var shell = Shell();
    try {
      // Run the application with the file as an argument
      await shell.run('$appPath $filePath');
    } catch (e) {
      print('Error: $e');
    }
  }

  // Future<void> openRecentDownload(String fileType) async {
  //   // Define the path to the Downloads directory
  //   String downloadsPath = '${Platform.environment['HOME']}/Downloads'; // Linux path

  //   print('Downloads path: $downloadsPath');

  //   // Get the list of files in the Downloads directory
  //   final directory = Directory(downloadsPath);
  //   List<FileSystemEntity> files = directory.listSync();

  //   // Filter for .xlsx files
  //   List<FileSystemEntity> xlsxFiles = files.where((file) => file.path.endsWith(fileType)).toList();

  //   // Sort files by modification date
  //   xlsxFiles.sort((a, b) => b.statSync().modified.compareTo(a.statSync().modified));

  //   // Get the most recently modified .xlsx file
  //   if (xlsxFiles.isNotEmpty) {

  //     String? appPath = await getAppPath('libreoffice');

  //     await openAppWithFile(appPath!, xlsxFiles.first.path);
  //   } else {
  //     print('No .xlsx files found in the Downloads directory.');
  //   }
  // }

