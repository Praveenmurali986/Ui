import 'package:flutter/material.dart';

class AppColors {
  // Define your colors here
  static const Color appBarBackground = Color.fromARGB(210, 211, 231, 245);  // Example color for AppBar background
  static const Color tabSelected = Color.fromARGB(210, 249, 249, 250);  // Selected tab color
  static const Color tabUnselected = Color.fromARGB(210, 211, 231, 245);  // Unselected tab color
}
