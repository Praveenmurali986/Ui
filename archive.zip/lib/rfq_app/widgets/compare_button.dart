import 'package:flutter/material.dart';

class CompareButton extends StatelessWidget {
  final bool isLoading;
  final int elapsedTime;
  final Function onPressed;
  final double screenHeight;
  final double screenWidth;

  CompareButton({
    required this.isLoading,
    required this.elapsedTime,
    required this.onPressed,
    required this.screenHeight,
    required this.screenWidth,
  });

  String formatElapsedTime(int seconds) {
    int minutes = seconds ~/ 60;
    int remainingSeconds = seconds % 60;
    return '$minutes:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: screenHeight * 0.03),
        child: ElevatedButton(
          onPressed: () => onPressed(),
          style: ElevatedButton.styleFrom(
            padding: EdgeInsets.symmetric(
              vertical: screenHeight * 0.04, // Vertical padding
              horizontal: screenWidth * 0.1, // Horizontal padding
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20), // Rounded corners
            ),
            backgroundColor: Colors.blue,
          ),
          child: Text(
            isLoading
                ? formatElapsedTime(elapsedTime) // Display elapsed time when loading
                : "Compare", // Display "Compare" when not loading
          ),
        ),
      ),
    );
  }
}
