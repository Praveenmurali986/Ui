// import 'package:flutter/material.dart';
// import 'package:flutter_svg/flutter_svg.dart';
// import 'package:rfq_demo/utils/app_colors.dart';  // Import colors from app_colors.dart

// class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
//   const CustomAppBar({Key? key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     // Get screen width and height using MediaQuery
//     double screenHeight = MediaQuery.of(context).size.height;
//     double screenWidth = MediaQuery.of(context).size.width;

//     // Set the logo size relative to the screen width
//     double logoSize = screenWidth * 0.06; // 6% of screen width (you can adjust this value)

//     return AppBar(
//       shape: RoundedRectangleBorder(
//         borderRadius: BorderRadius.all(Radius.circular(20)), // Rounded corners
//       ),
//       backgroundColor: AppColors.appBarBackground,  // Set AppBar background color
//       title: Padding(
//         padding: EdgeInsets.all(screenHeight * 0), // Add some top padding to the title
//         child: Row(
//           children: [
//             SvgPicture.asset(
//               'assets/Lila_Logo.svg',  // SVG Logo
//               width: logoSize,  // Logo size based on screen width
//               height: logoSize,  // Logo size based on screen width
//             ),
//             SizedBox(width: screenWidth * 0.3),  // Adjust the space between logo and TabBar
//             Expanded(
//               child: TabBar(
//                 labelColor: AppColors.tabSelected,  // Selected tab color
//                 unselectedLabelColor: AppColors.tabUnselected,  // Unselected tab color
//                 // Set indicator to BoxDecoration(), which removes the underline
//                 indicator: BoxDecoration(
//                   color: AppColors.tabSelected,  // Optional: Set background color for the selected tab
//                   borderRadius: BorderRadius.circular(20), // Rounded corners for the selected tab
//                 ),
//                 indicatorWeight: 10,  // Set to 0 to avoid any underline weight
//                 indicatorSize: TabBarIndicatorSize.tab,  // Ensures the indicator only covers the selected tab's area
//                 // Remove default underline behavior
//                 tabs: const [
//                   Tab(text: "Option 1"),
//                   Tab(text: "Option 2"),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   @override
//   Size get preferredSize => Size.fromHeight(120);  // Default height of the AppBar (if needed)
// }
