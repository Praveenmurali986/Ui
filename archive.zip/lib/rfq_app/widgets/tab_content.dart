import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:login_signup_page/rfq_app//utils/app_colors.dart';  // Import colors from app_colors.dart
import 'package:file_picker/file_picker.dart';
import 'dart:async';
import 'dart:typed_data';
import 'dart:convert';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:login_signup_page/rfq_app//utils/methods.dart';

import 'dart:io';


class TabContent extends StatefulWidget {
  final TabController tabController;
  final double screenWidth;
  final double screenHeight;
  final BuildContext context;

  TabContent({
    required this.context,
    required this.tabController,
    required this.screenWidth,
    required this.screenHeight,
  });

  @override
  State<TabContent> createState() => _TabContentState();
}

class _TabContentState extends State<TabContent> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  Uint8List? _fileBytes1;
  String? _fileName1;
  Uint8List? _fileBytes2;
  String? _fileName2;
  String comparisonResult = '';
  bool _isLoading = false;
  Timer? _timer;
  int _elapsedTime = 0;
  bool _isLoadingPpt=false;
  Uint8List? _fileBytesPpt;
  String? _fileNamePpt;
  String resultCompare ='';
  bool _isComparing = false; // flag to track comparison state
  bool _isDownloadingPpt = false;



  Future<void> pickFile(int fileNumber) async {
  FilePickerResult? result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf','.xlsx']);

  if (result != null && result.files.isNotEmpty) {
    final platformFile = result.files.single;
    if (platformFile.bytes != null) {
      setState(() {
        if (fileNumber == 1) {
          _fileBytes1 = platformFile.bytes;
          _fileName1 = platformFile.name;  // Store file name for file 1
        } else if (fileNumber == 2) {
          _fileBytes2 = platformFile.bytes;
          _fileName2 = platformFile.name;  // Store file name for file 2
        }
      });
    } else {
      ScaffoldMessenger.of(widget.context).showSnackBar(const SnackBar(
        content: Text('File selected, but bytes are not available.'),
      ));
    }
  } else {
    ScaffoldMessenger.of(widget.context).showSnackBar(const SnackBar(
      content: Text('No file selected. Please try again.'),
    ));
  }
}


// Future<void> pickFile(int fileNumber) async {
//   FilePickerResult? result = await FilePicker.platform.pickFiles(
//     type: FileType.custom,
//     allowedExtensions: ['pdf'],
//   );

//   if (result != null && result.files.isNotEmpty) {
//     final platformFile = result.files.single;

//     // Use the path to read the file bytes
//     if (platformFile.path != null) {
//       final file = File(platformFile.path!);
//       final bytes = await file.readAsBytes();

//       setState(() {
//         if (fileNumber == 1) {
//           _fileBytes1 = bytes;
//           _fileName1 = platformFile.name;  // Store file name for file 1
//         } else if (fileNumber == 2) {
//           _fileBytes2 = bytes;
//           _fileName2 = platformFile.name;  // Store file name for file 2
//         }
//       });
//     } else {
//       ScaffoldMessenger.of(widget.context).showSnackBar(const SnackBar(
//         content: Text('File selected, but path is not available.'),
//       ));
//     }
//   } else {
//     ScaffoldMessenger.of(widget.context).showSnackBar(const SnackBar(
//       content: Text('No file selected. Please try again.'),
//     ));
//   }
// }

Future<void> pickFilePpt() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles();
    if (result != null) {
      setState(() {
        _fileNamePpt = result.files.single.name;  // The file's name
        _fileBytesPpt = result.files.single.bytes;  // The raw bytes of the file
      });
    }
  }

// Future<void> pickFilePpt() async {
//     FilePickerResult? result = await FilePicker.platform.pickFiles(
//       type: FileType.custom, // You can specify the type if needed
//       allowedExtensions: ['xlsx'], // Specify allowed extensions for PowerPoint files
//     );
//     if (result != null && result.files.isNotEmpty) {
//       final platformFile = result.files.single;
//       // Use the path to read the file bytes
//       if (platformFile.path != null) {
//         final file = File(platformFile.path!);
//         final bytes = await file.readAsBytes();
//         setState(() {
//           _fileNamePpt = platformFile.name;  // The file's name
//           _fileBytesPpt = bytes;              // The raw bytes of the file
//         });
//       } 
//     } 
//   }


// Function to handle the file upload and download PPT
Future<void> _handleDownloadPPT() async {
  // Check if a download is already in progress
  if (_isDownloadingPpt) {
    ScaffoldMessenger.of(widget.context).showSnackBar(
      SnackBar(content: Text("Download in progress. Please wait.")),
    );
    return; // Exit the function if a download is already in progress
  }

  setState(() {
    _isDownloadingPpt = true; // Set the download state to true
    _isLoadingPpt = true; // Set loading state to true before starting the download
  });

  // Start a timer to increment elapsed time
  _timer = Timer.periodic(Duration(seconds: 1), (timer) {
    setState(() {
      _elapsedTime++;
    });
  });

  try {
    // Call the downloadPPT function
    await downloadPPT(
      context,
      _fileBytesPpt,  // The selected file's bytes
      _fileNamePpt,   // The selected file's name
    );
  } catch (e) {
    ScaffoldMessenger.of(widget.context).showSnackBar(
      SnackBar(content: Text("Error: $e")),
    );
  } finally {
    setState(() {
      _isLoadingPpt = false; // Set loading state to false after download completes
      _isDownloadingPpt = false; // Reset the download state
      _timer?.cancel(); // Stop the timer once the download is complete
      _elapsedTime = 0; // Reset elapsed time if needed
    });
  }
}

Future<void> _handleCompareFiles() async {
  // Check if a comparison is already in progress
  if (_isComparing) {
    ScaffoldMessenger.of(widget.context).showSnackBar(
      SnackBar(content: Text("Comparison in progress. Please wait.")),
    );
    return; // Exit the function if a comparison is already in progress
  }

  setState(() {
    _isLoading = true; // Set loading state to true before starting the download
    _isComparing = true; // Set the comparison state to true
  });

  // Start a timer to increment elapsed time
  _timer = Timer.periodic(Duration(seconds: 1), (timer) {
    setState(() {
      _elapsedTime++;
    });
  });

  try {
    // Call the compareFiles method and wait for the result
    resultCompare = (await compareFiles(
      widget.context,
      _fileBytes1,
      _fileBytes2,
      _fileName1,
      _fileName2,
      comparisonResult,
    ))!;
  } catch (e) {
    ScaffoldMessenger.of(widget.context).showSnackBar(
      SnackBar(content: Text("Error: $e")),
    );
  } finally {
    setState(() {
      comparisonResult = resultCompare;
      _isLoading = false; // Set loading state to false after download completes
      _isComparing = false; // Reset the comparison state
      _timer?.cancel(); // Stop the timer once the download is complete
      _elapsedTime = 0; // Reset elapsed time if needed
    });
  }
}

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: TabBarView(
        controller: widget.tabController,
        children: [
          // Content for Option 1 - Two boxes horizontally with decoration
          Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                // First box inside the content for Option 1 with decoration
                Container(
                  width: widget.screenWidth * 0.3,
                  height: widget.screenHeight * 0.77,
                  decoration: BoxDecoration(
                    color: AppColors.appBarBackground, // Box color
                    borderRadius: BorderRadius.all(Radius.circular(15)),  // Rounded corners
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(widget.screenHeight*0.01),  // Add padding inside the box
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,  // Center the buttons inside the box
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Stack(
                          children: [
                            // ElevatedButton
                            // Replace ElevatedButton with Container
                            Container(
  width: widget.screenWidth * 0.25,
  height: widget.screenHeight * 0.25,
  decoration: BoxDecoration(
    color: Colors.white,  // Background color of the container
    borderRadius: BorderRadius.circular(15),  // Rounded corners
  ),
  child: Stack(
    children: [
      // Image at the center
      Center(
        child: SvgPicture.asset(
          height: widget.screenHeight * 0.1,
          width: widget.screenWidth * 0.06,
          'assets/Drop_button.svg',  // Replace with your image path
          fit: BoxFit.contain,  // Adjust image to fit within the container
        ),
      ),
      // Text at the bottom
      Positioned(
        bottom: widget.screenHeight*0.008,  // 8px from the bottom edge
        left: 0,
        right: 0,
        child: Text(
          "Drag and drop file",  // Display file name or default text
          textAlign: TextAlign.center,
          style: TextStyle(
            color: const Color.fromARGB(210, 141, 153, 161),
            fontSize: widget.screenHeight*0.017,
            fontWeight: FontWeight.w100,
          ),
        ),
      ),
      // Text at the top-left corner
      Positioned(
        top: widget.screenHeight*0.008,  // 8px from the top edge
        left: widget.screenWidth*0.008,  // 8px from the left edge
        child: Text(
          _fileName1 ?? "Select File 1",  // Text at the top-left corner
          style: TextStyle(
            color: Colors.black,
            fontSize: widget.screenHeight*0.016,
            fontWeight: FontWeight.w100,
          ),
        ),
      ),
      // "+" Button positioned on top-right of Container
      Positioned(
        right: widget.screenWidth*0.006,  // 8px from the right edge
        top: widget.screenHeight*0.007,    // 8px from the top edge
        child: GestureDetector(
          onTap: () {
            // Define action for the "+" button here
            pickFile(1);
          },
          child: CircleAvatar(
            backgroundColor: Colors.blue,  // Background color of the button
            radius: widget.screenWidth*0.011,  // Radius of the circular button
            child: Icon(
              Icons.add,  // "+" icon
              color: Colors.white,  // Icon color
              size: widget.screenWidth*0.012,  // Icon size
            ),
          ),
        ),
      ),
    ],
  ),
),

                          ],
                        ),
                        SizedBox(height: widget.screenHeight * 0.03),  // Space between buttons
                        Stack(
                          children: [
                            // Container with image and text
                            Container(
                              width: widget.screenWidth * 0.25,
                              height: widget.screenHeight * 0.25,
                              decoration: BoxDecoration(
                                color: Colors.white,  // Background color of the container
                                borderRadius: BorderRadius.circular(15),  // Rounded corners
                              ),
                              child: Stack(
                                children: [
                                  // Image at the center
                                  Center(
                                    child: SvgPicture.asset(
                                      height: widget.screenHeight * 0.1,
                                      width: widget.screenWidth * 0.06,
                                      'assets/Drop_button.svg',  // Replace with your image path
                                      fit: BoxFit.contain,  // Adjust image to fit within the container
                                    ),
                                  ),
                                  // Text at the bottom
                                  Positioned(
                                    bottom: widget.screenHeight*0.008,  // 8px from the bottom edge
                                    left: 0,
                                    right: 0,
                                    child: Text(
                                    "Drag and drop file",  // Display file name or default text
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: const Color.fromARGB(210, 141, 153, 161),
                                      fontSize: widget.screenHeight*0.017,
                                      fontWeight: FontWeight.w100,
                                    ),
                                  ),
                                  ),
                                  // Text at the top-left corner
                                  Positioned(
                                    top: widget.screenHeight*0.008,  // 8px from the top edge
                                    left: widget.screenWidth*0.008,  // 8px from the left edge
                                    child: Text(
                                      _fileName2?? "Select File 2",  // Text at the top-left corner
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: widget.screenHeight*0.016,
                                        fontWeight: FontWeight.w100,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            // "+" Button positioned on top-right of Container
                            Positioned(
                              right: widget.screenWidth*0.008,  // 8px from the right edge
                              top: widget.screenHeight*0.008,    // 8px from the top edge
                              child: GestureDetector(
                                onTap: () {
                                  // Define action for the "+" button here
                                  pickFile(2);
                                },
                                child: CircleAvatar(
                                  backgroundColor: Colors.blue,  // Background color of the button
                                  radius:  widget.screenWidth*0.011,  // Radius of the circular button
                                  child: Icon(
                                    Icons.add,  // "+" icon
                                    color: Colors.white,  // Icon color
                                    size:  widget.screenWidth*0.012,  // Icon size
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        Center(
  child: Padding(
    padding: EdgeInsets.symmetric(vertical: widget.screenHeight * 0.03),
    child: ElevatedButton(
      onPressed: _handleCompareFiles,
      // () async {
      //   // Start the comparison process by setting _isLoading to true
      //   setState(() {
      //     _isLoading = true;
      //     _elapsedTime =0;  // Reset the elapsed time when the comparison starts
      //   });

      //   handleCompareFiles()

      //   // Handle the result if comparison is successful
      //   if (result != null) {
      //     setState(() {
      //       comparisonResult = result;  // Set the result from comparison
      //       _isLoading = false;  // Stop loadin,
      //       _elapsedTime = 0;
      //     });
      //   } else {
      //     // If there was an error, stop loading
      //     setState(() {
      //       _isLoading = false;
      //     });
      //   }

        // print("Compare button tapped");
      // },
      style: ElevatedButton.styleFrom(
        padding: EdgeInsets.symmetric(
          vertical: widget.screenHeight * 0.03, // Vertical padding
          horizontal: widget.screenWidth * 0.1, // Horizontal padding
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20), // Rounded corners
        ),
        backgroundColor: Colors.blue,
      ),
      child: Text(
        _isLoading
            ? formatElapsedTime(_elapsedTime)  // Display elapsed time when loading
            : (  // Display comparison result when available
               "Compare"), 
               style: TextStyle(color: Colors.white, fontSize: widget.screenWidth * 0.013), // Display "Compare" when not loading
      ),
    ),
  ),
),


                      ],
                    ),
                  ),
                ),
                SizedBox(width: widget.screenWidth * 0.01), // Space between boxes
                // Second box inside the content for Option 1 with decoration
                Container(
  width: widget.screenWidth * 0.65,
  height: widget.screenHeight * 0.77,
  decoration: BoxDecoration(
    color: AppColors.appBarBackground, // Box color
    borderRadius: BorderRadius.all(Radius.circular(15)),  // Rounded corners
  ),
  child: Stack(
   children: [
          // Conditionally show either the generate icon or markdown
          if (comparisonResult.isEmpty)
            Center(
              child: SvgPicture.asset(
                'assets/Generate_Icon.svg',
                width: widget.screenWidth * 0.2,
                height: widget.screenWidth * 0.2,
                color: const Color.fromARGB(210, 163, 212, 247),
              ),
            )
          else
            // Display markdown after the result is loaded
            Container(
              padding: EdgeInsets.all( widget.screenWidth*0.01),
              child: Markdown(
                data: comparisonResult,
                styleSheet: MarkdownStyleSheet(tableBody: TextStyle(fontWeight: FontWeight.w500),textScaler: TextScaler.linear(1.1)),
              ),
            ),

          // Image at the top-right corner
          Positioned(
            top: widget.screenWidth * 0.01,
            right: widget.screenWidth * 0.01,
            child: GestureDetector(
              onTap: () {
                showFullscreenResult(comparisonResult, context);
              },
              child: Icon(
                Icons.fullscreen,
                size: widget.screenWidth * 0.03,
                color: Colors.grey,
              ),
            ),
          ),

          // Image at the bottom-right corner
          Positioned(
            bottom: widget.screenWidth * 0.01,
            right: widget.screenWidth * 0.01,
            child: GestureDetector(
              onTap: () {
                downloadComparisonResult(
                    context, comparisonResult, _fileBytes1, _fileBytes2, _fileName1, _fileName2);
              },
              child: Icon(
                Icons.download,
                size: widget.screenWidth * 0.03,
                color: Colors.blue,
              ),
            ),
          ),
        ],
  ),
)

              ],
            ),
          ),
          // Content for Option 2 - One box with decoration
          Container(
            child: Container(
              width: widget.screenWidth * 0.95,
              height: widget.screenHeight * 0.75,
              decoration: BoxDecoration(
                color: AppColors.appBarBackground, // Box color
                borderRadius: BorderRadius.all(Radius.circular(15)),  // Rounded corners
              ),
              child: Padding(
                padding: EdgeInsets.only(top: widget.screenHeight * 0.01),  // Adjust this value for space from the top
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,  // Centering vertically
                    children: [
                      Container(
  width: widget.screenWidth * 0.93,
  height: widget.screenHeight * 0.6,
  decoration: BoxDecoration(
    color: Colors.white,  // Background color of the container
    borderRadius: BorderRadius.circular(15),  // Rounded corners
  ),
  child: Padding(
    padding: EdgeInsets.all(widget.screenWidth * 0.01), // Padding inside the small container
    child: Stack(
      children: [
        // Centered SVG Image
        Center(
          child: SvgPicture.asset(
            'assets/Drop_button.svg',
            width: widget.screenWidth * 0.03,
            height: widget.screenWidth * 0.06,
            color: const Color.fromARGB(210, 172, 214, 243),
            // fit: BoxFit.contain,
          ),
        ),

        // Text at the top-left corner
        Positioned(
          top:  widget.screenHeight*0.002,  // Adjust top padding
          left:  widget.screenWidth*0.002,  // Adjust left padding
          child: Text(
            _fileNamePpt?.isEmpty ?? true ? 'Select File' : _fileNamePpt!,  // Replace with your desired text
            style: TextStyle(
              fontSize: widget.screenHeight*0.020,
              color: const Color.fromARGB(249, 5, 5, 7),
              fontWeight: FontWeight.w400,
            ),
          ),
        ),

        // Text below the image, moved slightly upwards
        Positioned(
          bottom: widget.screenHeight * 0.008,  // Adjusted to move it upwards (from 8 to 16)
          left: 0,
          right: 0,
          child: Text(
            'Drag and drop file',  // Replace with your desired text
            textAlign: TextAlign.center,  // Center-align the text
            style: TextStyle(
              fontSize: widget.screenHeight*0.02,
              color: Colors.grey,
              fontWeight: FontWeight.w300,
            ),
          ),
        ),

        // Icon.add at top-right corner
        Positioned(
  top: widget.screenHeight * 0.002,  // Adjust top padding
  right: widget.screenWidth * 0.002,  // Adjust right padding
  child: GestureDetector(
    onTap: pickFilePpt,
    child: CircleAvatar(
      backgroundColor: Colors.blue,  // Background color of the button
      radius: widget.screenWidth*0.015,  // Radius of the circular button
      child: Icon(
        Icons.add,  // "+" icon
        color: Colors.white,  // Icon color
        size: widget.screenWidth*0.016,  // Icon size
      ),
    ),
  ),
),

      ],
    ),
  ),
),


                      SizedBox(height: widget.screenHeight * 0.02),  // Space between the small container and the button
                      Align(
                        alignment: Alignment.bottomRight,  // Align the button to the right
                        child: Padding(
                          padding: EdgeInsets.only(right: widget.screenWidth * 0.015),
                          child: ElevatedButton(
                            onPressed: _handleDownloadPPT,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue,  // Button background color
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12), // Rounded corners
                              ),
                              padding: EdgeInsets.symmetric(
                                vertical: widget.screenHeight * 0.03, // Vertical padding
                                horizontal: widget.screenWidth * 0.1, // Horizontal padding
                              ),
                            ),
                            child: Text(
                              _isLoadingPpt
                              ? formatElapsedTime(_elapsedTime) // Show elapsed time when loading
                              : 'Download', // Show "Download" when not loading
                              style: TextStyle(
                                color: Colors.white, // Text color
                                fontWeight: FontWeight.bold,
                                fontSize: widget.screenHeight*0.023
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
