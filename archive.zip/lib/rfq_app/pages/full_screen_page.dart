import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown/flutter_markdown.dart';

class MarkdownDisplayPage extends StatelessWidget {
  final String markdownData;

  const MarkdownDisplayPage({Key? key, required this.markdownData}) : super(key: key);

  @override
Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(
      title: Text("Comparison Result"),
      backgroundColor: Colors.blue,
    ),
    body: Padding(
      padding: const EdgeInsets.all(16.0),
      child: Container(
        height: MediaQuery.of(context).size.height - 100, // Adjust height as needed
        child: Markdown(data: markdownData),
      ),
    ),
  );
}

}