class PortURL {
  // static const baseURL = 'http://172.30.8.85:9005';
  static const baseURL = 'http://172.18.14.2:9026';
  static const baseSocketURL = 'ws://172.18.14.2:9026/ws';
}

class FontNames {
  static const fontFamilyName = 'Roboto';
  static const fontFamilyNameMono = 'mono';
  static const fontFamilyNameBold = 'noto';
}

class Names {
  // static const sideBarTitleName = '𝐀𝐮𝐭𝐨𝐬𝐚𝐫 𝐂𝐡𝐚𝐭𝐁𝐨𝐭';
  static const sideBarTitleName = 'AUTOSAR \nCHATBOT';

  static const hintTextName = 'Type a message...';
}

class Messages {
  static const reponseMessage =
      'It seems like your message is incomplete or not properly formatted. Could you please provide the information again?';
}
