import 'package:login_signup_page/autosar_chat_app/ChatScreen/strings.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'dart:async';

class WebSocketService {
  final WebSocketChannel channel;
  String currentUserData = ''; // To accumulate user data
  late final Stream<String>
      stream; // The stream that will be exposed for listening

  // Constructor to initialize the WebSocket connection
  WebSocketService()
      : channel = WebSocketChannel.connect(
          Uri.parse(PortURL.baseSocketURL), // WebSocket server URL
        ) {
    // Expose the channel stream as a `Stream<String>`
    stream = channel.stream.map((data) => data.toString());
  }

  // Method to handle adding new data to currentUserData
  void addToCurrentUserData(String data) {
    currentUserData += data; // Append incoming data to current user data
    // print("stream data : $data");
  }

  // Reset the currentUserData for the next user
  void resetCurrentUserData() {
    currentUserData = '';
  }

  // Method to send a prompt message to the server
  Future<String> sendPrompt(String message) async {
    // Send the prompt message to the server
    channel.sink.add(message);

    // Listen for a full response from the server and return it
    return _getFullResponse();
  }

  // Private method to listen to the server's response and accumulate it
  Future<String> _getFullResponse() async {
    // Create a Completer to complete when the response is fully received
    Completer<String> completer = Completer<String>();

    // Listen to the WebSocket stream for multiple chunks of data
    stream.listen(
      (data) {
        // Process data immediately instead of accumulating

        // print("Received data: $data");

        // Check for end-of-message condition

        if (data.contains("END_OF_MESSAGE")) {
          // Handle the complete message

          // print("Full message received: $currentUserData");

          resetCurrentUserData(); // Reset for the next message
        } else {
          addToCurrentUserData(data); // Accumulate if not complete
        }
      },
      onError: (error) {
        print("Error: $error");
      },
      onDone: () {
        // print("Connection closed");
      },
    );

    return completer
        .future; // Return the future that will be completed when the full response is received
  }

  // Dispose of the WebSocket connection when no longer needed
  void dispose() {
    channel.sink.close();
  }
}
