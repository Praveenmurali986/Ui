import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';

class ApiService {
  final String baseUrl;

  ApiService(this.baseUrl);

  // / Creates a response based on the given prompt.
  Future<Map<String, dynamic>> createResponse(String prompt) async {
    print("calling the createResponse ...............");
    // final response = await http.post(Uri.parse('$baseUrl/qwery-db/'),
    final response = await http.post(Uri.parse('$baseUrl/api/generate'),

        // headers: <String, String>{
        //   'Content-Type': 'application/json; charset=UTF-8',
        // },
        body: jsonEncode(
            // <String, String>{'prompt': prompt, 'db_name': 'master_index'}));
            {'prompt': prompt, 'model': 'llama3.1', 'stream': true}));

    if (response.statusCode == 200) {
      // If the server returns a 200 OK response, parse the JSON.
      return jsonDecode(response.body);
    } else {
      // If the server did not return a 200 OK response, throw an exception.
      throw Exception('Failed to create response: ${response.body}');
    }
  }

  Stream<Map<String, dynamic>> createResponseStream(
      String prompt, List<Map<String, dynamic>> message) async* {
    // print("Calling the createResponseStream  ...............");

    // Create the request

    var request = http.Request('POST', Uri.parse('$baseUrl/api/generate'))
      ..headers['Content-Type'] = 'application/json'
      ..body = jsonEncode({
        // 'db_names': 'master_index',
        // 'messages': message,
        'prompt': prompt,
        'model_name': 'llama3.1',
        'stream': true,
      });

    // Send the request

    var response = await request.send();
    //   print('ressp $response');

    //     await for (var line in response.stream.transform(utf8.decoder).transform(const LineSplitter())) {

    //   // Assuming each line is a JSON string representing a Map

    //   yield json.decode(line) as Map<String, dynamic>;

    // }
    if (response.statusCode == 200) {
      StringBuffer buffer = StringBuffer();

      // Listen to the stream of data
      await for (var chunk in response.stream.transform(utf8.decoder)) {
        // Append the chunk to the buffer
        buffer.write(chunk);

        // Attempt to decode the buffer
        while (buffer.isNotEmpty) {
          try {
            // Try to decode the JSON object
            var jsonData = jsonDecode(buffer.toString());
            // print('this is a jsonData : $jsonData');
            yield jsonData; // Yield the decoded JSON data
            buffer.clear(); // Clear the buffer after successful decoding
          } catch (e) {
            // If decoding fails, check if we have a complete JSON object
            int endIndex = buffer.toString().indexOf('}');
            if (endIndex == -1) break; // No complete JSON object found

            // Extract the complete JSON object
            String jsonString = buffer.toString().substring(0, endIndex + 1);
            buffer = StringBuffer(buffer.toString().substring(endIndex + 1));

            // Decode the JSON object
            try {
              var jsonData = jsonDecode(jsonString);
              yield jsonData; // Yield the decoded JSON data
            } catch (e) {
              print("Error decoding JSON: $e");
              // print("Buffer content: ${buffer.toString()}");
            }
          }
        }
      }
    } else {
      // If the server did not return a 200 OK response, throw an exception.
      throw Exception('Failed to create response: ${response.reasonPhrase}');
    }
  }

  /// Sends files to the server.
  Future<String> sendFiles(List<Uint8List> files) async {
    // print("calling the sendFiles ...............");
    var request =
        http.MultipartRequest('POST', Uri.parse('$baseUrl/index-file/'));

    for (var file in files) {
      request.files.add(
        http.MultipartFile.fromBytes(
          'input_files', // Changed the key to 'input_files'
          file,
          filename:
              'file${files.indexOf(file) + 1}.txt', // Changed the filename
          contentType: MediaType.parse('application/octet-stream'),
        ),
      );
    }

    var response = await request.send();

    if (response.statusCode == 200) {
      // If the server returns a 200 OK response, return the file IDs.
      return await response.stream.bytesToString();
    } else {
      // If the server did not return a 200 OK response, throw an exception.
      throw Exception(
          'Failed to send files: ${response.reasonPhrase} ${response.request}');
    }
  }

  /// Sends a prompt to the server.
  Future<Map<String, dynamic>> sendPrompt(String fileId, String prompt) async {
    // print("calling the sendPrompt ...............");
    final response = await http.post(
      Uri.parse('$baseUrl/process-file/'), // Changed the endpoint URL
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(<String, String>{
        'file_id': fileId,
        'prompt': prompt,
      }),
    );

    if (response.statusCode == 200) {
      // If the server returns a 200 OK response, parse the JSON.
      return jsonDecode(response.body);
    } else {
      // If the server did not return a 200 OK response, throw an exception.
      throw Exception('Failed to send prompt: ${response.statusCode}');
    }
  }
}
