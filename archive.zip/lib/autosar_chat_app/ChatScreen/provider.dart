import 'package:flutter/material.dart';
 
class SelectedVersionProvider with ChangeNotifier {
  String _selectedVersion = 'R24-11'; // Default value
 
  String get selectedVersion => _selectedVersion;
 
  void updateSelectedVersion(String newVersion) {
    _selectedVersion = newVersion;
    notifyListeners(); // Notify listeners about the change
  }
}