import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:login_signup_page/autosar_chat_app/ChatScreen/Api_service.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:login_signup_page/autosar_chat_app/ChatScreen/Api_web_socket_service.dart';
import 'dart:typed_data';
import 'package:login_signup_page/autosar_chat_app/ChatScreen/mark_down_list.dart';
import 'package:login_signup_page/autosar_chat_app/ChatScreen/provider.dart';
import 'package:login_signup_page/autosar_chat_app/ChatScreen/strings.dart';
import 'package:login_signup_page/autosar_chat_app/ChatScreen/theme.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';

class ChatSection extends StatefulWidget {
  const ChatSection({super.key});

  @override
  _ChatSectionState createState() => _ChatSectionState();
}

class _ChatSectionState extends State<ChatSection> {
  final TextEditingController _controller = TextEditingController();
  final List<Map<String, dynamic>> _messages = [];
  List<String?>? _uploadedFileNames;
  List<Uint8List?>? _uploadedFiles;

  final ApiService apiService = ApiService(PortURL.baseURL);
  String _currentResponse = ''; // For holding concatenated responses
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();

    // Step 2: Initialize the ScrollController

    _scrollController.addListener(() {
      // Optional: You can add logic here if you want to do something when the scroll position changes
    });
  }

  void _scrollToBottom() {
    // Check if the controller has any listeners and if the list is not empty

    if (_scrollController.hasClients && _messages.isNotEmpty) {
      // Scroll to the bottom

      _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
    }
  }

  void _handleSendMessage(String clickedMessage,String selectedVersion) {
    final String userMessage = _controller.text.trim();
    if (userMessage.isNotEmpty) {
      setState(() {
        _messages.add({'role': 'User ', 'content': userMessage});
      });
      _controller.clear();
      _getAIDAResponse(userMessage, clickedMessage,selectedVersion);
      _scrollToBottom();
    }
  }

  void _getAIDAResponse(String userMessage, String clickedMessage,String selectedVersion) async {
    if (userMessage.isEmpty) {
      String response = "Please enter a message.";

      setState(() {
        _messages.add({'role': 'assistant', 'content': response});
      });
    } else {
      try {
        // Create the WebSocket service

        WebSocketService webSocketService = WebSocketService();

        // Initialize the partial response to hold the current message

        String partialResponse = '';

        // Add an assistant message placeholder (empty response)

        setState(() {
          _messages.add({
            'role': 'assistant',

            'content': partialResponse, // Start with an empty message
          });
        });

        // Prepare the JSON message to send

        // print("clicked message is : $clickedMessage");

        String jsonMessage =
            '{"messages": [{"role": "user", "content": "$userMessage","additional":"$clickedMessage","version":"$selectedVersion"}]}';

        // print("content inside the _message : $_messages");
        // String jsonMessage = '{"messages": "$_messages"}';

        // Send the user message (prompt) to the WebSocket server

        webSocketService.channel.sink.add(jsonMessage);

        // Listen for responses from the WebSocket server

        await for (var data in webSocketService.stream) {
          // Accumulate the response data progressively

          webSocketService.addToCurrentUserData(data);

          partialResponse = webSocketService.currentUserData;

          // Print for debugging

          // print(partialResponse);

          // Update the UI with the progressively built message

          setState(() {
            if (_messages[_messages.length - 1]['role'] == 'assistant') {
              // Update the last assistant message with the new content

              _messages[_messages.length - 1]['content'] = partialResponse;
            }
          });

          // Optional: Add a small delay for the "typing" effect

          // await Future.delayed(
          //     Duration(milliseconds: 150)); // Adjust delay as needed
        }

        // Once the response is complete, you can finalize the UI update (optional)

        // print('Final Response: $partialResponse');

        // Close the WebSocket connection

        webSocketService.dispose();
      } catch (e) {
        setState(() {
          _messages.add({'role': 'assistant', 'content': 'Error: $e'});
        });
      }
    }
    _scrollToBottom();
  }

  void _uploadFiles() async {
    FilePickerResult? result =
        await FilePicker.platform.pickFiles(allowMultiple: true);
    if (result != null) {
      setState(() {
        _uploadedFileNames = result.files.map((file) => file.name).toList();
        _uploadedFiles = result.files.map((file) => file.bytes).toList();
        _messages.add({
          'role': 'User ',
          'content': 'Uploading   : ${_uploadedFileNames!.join(', ')}',
          'files': _uploadedFiles,
        });
        // print("this is the file name : $_uploadedFileNames");
        _sendFiles();
      });
    }
  }

  void _sendFiles() async {
    if (_uploadedFiles != null) {
      try {
        final files = _uploadedFiles!
            .where((file) => file != null)
            .map((file) => file!)
            .toList();
        final response = await apiService.sendFiles(
          files,
        );
        setState(() {
          _messages.add(
              {'role': 'assistant', 'content': 'Files uploaded successfully'});
        });
      } catch (e) {
        setState(() {
          _messages.add(
              {'role': 'assistant', 'content': 'Error uploading files: $e'});
        });
      }
      setState(() {
        _uploadedFiles = null;
        _uploadedFileNames = null;
      });
    }
  }

  @override
  void dispose() {
    super.dispose();
    _scrollController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final double screenHeight = MediaQuery.of(context).size.height;

    String clickedMessage =
        ModalRoute.of(context)!.settings.arguments as String? ??
            'Wireless Communication Drivers';

    String selectedVersion =
        Provider.of<SelectedVersionProvider>(context).selectedVersion;

    // print("clicked message is : $clickedMessage");

    // Gradually scale the font size based on screen width
    double fontSize = (screenWidth / 80)
        .clamp(8.0, 20.0); // Adjust the divisor and clamp values as needed

    double IconSize = (screenWidth / 10)
        .clamp(22.0, 24.0); // Adjust the divisor and clamp values as needed
    double IconSize_add = (screenWidth / 25).clamp(10.0, 40.0);

    double minimumSize = (screenHeight * 0.1).clamp(50, 100);

    return Container(
      padding: EdgeInsets.all(screenWidth * 0.010),
      decoration: BoxDecoration(
        color: AppTheme.lightBackgroundColor,
        borderRadius: const BorderRadius.only(
          topRight: Radius.circular(30.0),
          bottomRight: Radius.circular(30.0),
        ),
      ),
      child: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final message = _messages[index];
                final isUser = message['role'] == 'User ';
                if (message.containsKey('files')) {
                  return Align(
                    alignment:
                        isUser ? Alignment.centerRight : Alignment.centerLeft,
                    child: _isCodeBlock(message['content'])
                        ? _buildCodeContainer(message['content'])
                        : Container(
                            padding: const EdgeInsets.all(15),
                            margin: const EdgeInsets.symmetric(
                                vertical: 5, horizontal: 10),
                            decoration: BoxDecoration(
                              color: isUser
                                  ? (AppTheme.lightSecondaryColor)
                                  : (AppTheme.lightPrimaryColor),
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(1)),
                            ),
                            child: SelectableText(
                              message['content']!,
                              style: TextStyle(
                                  fontSize: 12,
                                  color: AppTheme.lightTextColor,
                                  fontWeight: FontWeight.normal,
                                  fontFamily: FontNames.fontFamilyName),
                            ),
                          ),
                  );
                } else {
                  return Align(
                    alignment:
                        isUser ? Alignment.centerRight : Alignment.centerLeft,
                    child: Container(
                      padding: EdgeInsets.all(screenWidth * 0.012),
                      margin: const EdgeInsets.symmetric(
                          vertical: 2, horizontal: 10),
                      decoration: BoxDecoration(
                        color: isUser
                            ? (AppTheme.lightPrimaryColor)
                            : (AppTheme.lightBackgroundColor),
                        borderRadius: BorderRadius.circular(105),
                      ),
                      child: isUser
                          ? SelectableText(
                              message['content'],
                              style: TextStyle(
                                color: AppTheme.lightTextColor,
                                // fontSize: screenWidth * 0.013,
                                fontSize: fontSize,
                                fontWeight: FontWeight.normal,
                              ),
                            )
                          : MarkdownBody(
                              selectable: true,
                              data: message['content'],
                              styleSheet: MarkdownStyles.getMarkdownStyleSheet(
                                  false, context),
                            ),
                    ),
                  );
                }
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                PopupMenuButton(
                  icon: Container(
                    padding: const EdgeInsets.all(12.0),
                    decoration: BoxDecoration(
                      color: AppTheme.lightUploadIconBackgroundColor,
                      borderRadius: BorderRadius.circular(60.0),
                      boxShadow: [
                        BoxShadow(
                          color: AppTheme.darkShadowColor,
                          blurRadius: 0.1,
                          spreadRadius: 0.5,
                        ),
                      ],
                    ),
                    child: Icon(
                      size: IconSize_add,
                      Icons.add,
                      color: AppTheme.lightUploadIconColor,
                    ),
                  ),
                  itemBuilder: (context) => [
                    PopupMenuItem(
                      onTap: _uploadFiles,
                      child: const Row(
                        children: [
                          Icon(Icons.upload_file),
                          SizedBox(width: 8),
                          SelectableText('Upload Files'),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _controller,
                    cursorHeight: fontSize,
                    style: TextStyle(
                      height: screenHeight * 0.003,
                      fontSize: fontSize,
                      color: AppTheme.lightTextColor,
                      fontWeight: FontWeight.normal,
                    ),
                    decoration: InputDecoration(
                      hintText: Names.hintTextName,
                      hintStyle: TextStyle(
                          fontSize: fontSize,
                          color: AppTheme.lightTextColor.withValues()),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(40.0),
                        borderSide:
                            BorderSide(color: AppTheme.lightPrimaryColor),
                      ),
                      filled: true,
                      fillColor: AppTheme.lightPromptAreaColor,
                      contentPadding: const EdgeInsets.all(16),
                    ),
                    onSubmitted: (value) {
                      _handleSendMessage(clickedMessage,selectedVersion);
                    },
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    elevation: 3,
                    shadowColor: AppTheme.darkShadowColor,
                    minimumSize: Size(
                        // screenHeight * 0.09,
                        IconSize,
                        minimumSize), // Adjusted minimum size for a circular button
                    backgroundColor:
                        AppTheme.lightUploadIconBackgroundColor, // Button color
                    shape: const CircleBorder(), // Make the button circular
                  ),
                  onPressed: () => _handleSendMessage(clickedMessage,selectedVersion),
                  child: SvgPicture.asset(
                    'assets/send_icon.svg', // Path to your SVG asset
                    semanticsLabel:
                        'Your SVG Image', // Optional label for accessibility
                    height: IconSize, // Set the height to match the icon size
                    width: IconSize, // Set the width to match the icon size
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

bool _isCodeBlock(String content) {
  // print("Content being checked: '$content'");
  String trimmedContent = content.trim();
  // print("trimmed content : '$trimmedContent'");
  // print(trimmedContent);
  if (trimmedContent.startsWith('```')) {
    // print("The code is identified");
    return true;
  } else {
    // print("The code is not identified");
    return false;
  }
}

Widget _buildCodeContainer(String content) {
  // Extract the language and code from the content
  // print("buildCodeContainer is called .........");

  final lines = content.split('\n');

  final language = lines[0].replaceAll('```', '').trim(); // Get the language

  final code = lines.sublist(1, lines.length - 1).join('\n'); // Get the code

  return Container(
    padding: EdgeInsets.all(15),
    margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
    decoration: BoxDecoration(
      color: Colors.grey[200], // Change this to your desired color

      borderRadius: BorderRadius.circular(10),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SelectableText(
          language, // Display the language

          style: TextStyle(
            fontWeight: FontWeight.bold,

            color: Colors.black, // Change this to your desired color
          ),
        ),
        SizedBox(height: 5),
        SelectableText(
          code, // Display the code

          style: TextStyle(
            fontFamily: 'Courier', // Use a monospace font for code

            color: Colors.black, // Change this to your desired color
          ),
        ),
      ],
    ),
  );
}
