import 'package:flutter/material.dart';
import 'package:login_signup_page/autosar_chat_app/ChatScreen/chatscreen.dart';
import 'package:login_signup_page/autosar_chat_app/ChatScreen/theme.dart';
import 'package:login_signup_page/autosar_chat_app/ChatScreen/topBar.dart';
 
class ChatLayout extends StatelessWidget {
  const ChatLayout({super.key});
 
  @override
  Widget build(BuildContext context) {
    double screenPadding = 10;
    double screenHeight = MediaQuery.of(context).size.height;
    double screenWidth = MediaQuery.of(context).size.width;
 
    // Define thresholds for visibility
    double chatAreaThreshold = 170; // Height threshold for Chat Area
 
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.white,
              Colors.white,
            ],
          ),
        ),
        child: Row(
          children: [
            // Vertical Icon Container on the left
            Container(
              margin: EdgeInsets.all(screenPadding),
              // padding: const EdgeInsets.all(5.0),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15.0),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    spreadRadius: 3,
                    blurRadius: 5,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: const TopBar(), // Use the new VerticalIconContainer
            ),
 
            // Check if the available height is sufficient for the Chat Area
            if (screenHeight > chatAreaThreshold) ...[
              Expanded(
                flex: 5,
                child: Container(
                  margin: EdgeInsets.all(screenPadding),
                  padding: const EdgeInsets.all(12.0),
                  decoration: BoxDecoration(
                    color: AppTheme.lightBackgroundColor,
                    borderRadius: BorderRadius.circular(15.0),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        spreadRadius: 3,
                        blurRadius: 5,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: const ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(15.0)),
                    child: ChatSection(),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
 