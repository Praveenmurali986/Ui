import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:login_signup_page/autosar_chat_app/ChatScreen/dropdown.dart';
import 'package:login_signup_page/autosar_chat_app/ChatScreen/provider.dart';
import 'package:login_signup_page/autosar_chat_app/ChatScreen/strings.dart';
import 'package:login_signup_page/autosar_chat_app/ChatScreen/theme.dart';
import 'package:provider/provider.dart';
class TopBar extends StatelessWidget {
  const TopBar({super.key});

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final double screenHeight = MediaQuery.of(context).size.height;

    // Define responsive padding
    double horizontalPadding = screenWidth * 0.04; // 4% of screen width
    double verticalPadding = screenHeight * 0.04; // 4% of screen height

    // Define responsive icon size using the smaller dimension
    double iconSize =
        (screenWidth < screenHeight ? screenWidth : screenHeight) /
            6; // Adjusted for both dimensions
    iconSize =
        iconSize.clamp(50.0, 100.0); // Clamp to a minimum and maximum size

    double minimumSize = (screenHeight * 0.15).clamp(80, 250);

    return Container(
      height: screenHeight, // Set the height to match the screen height
      padding:
          EdgeInsets.all(horizontalPadding), // Padding around the container
      decoration: BoxDecoration(
        color: AppTheme.lightBackgroundColor, // Background color
        borderRadius: BorderRadius.circular(15), // Rounded corners
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2), // Shadow color
            spreadRadius: 2,
            blurRadius: 5,
            offset: const Offset(0, 3), // Offset for the shadow
          ),
        ],
      ),
      child: SingleChildScrollView(
        // Allow scrolling if content exceeds height
        child: Column(
          mainAxisAlignment:
              MainAxisAlignment.start, // Align items at the start
          crossAxisAlignment: CrossAxisAlignment.center, // Center align items
          children: [
            // First Icon
            Padding(
              padding: EdgeInsets.symmetric(vertical: verticalPadding),
              child: FittedBox(
                child: SizedBox(
                  height: minimumSize,
                  width: minimumSize,
                  child: SvgPicture.asset(
                    'assets/Lila_logo.svg', // Path to your SVG file
                    fit: BoxFit.contain,
                  ),
                ),
              ),
            ),
            // Space between icons
            SizedBox(height: verticalPadding), // Increased space between icons
            // Second Icon
            Padding(
              padding: EdgeInsets.symmetric(vertical: verticalPadding),
              child: FittedBox(
                child: SizedBox(
                  height: minimumSize*0.9,
                  width: minimumSize*0.9,
                  child: Image.asset(
                    'assets/ChatIcon.png', // Replace with your chat icon path
                    fit: BoxFit.contain,
                  ),
                ),
              ),
            ),
            // Space between icons
            SizedBox(height: verticalPadding), // Increased space between icons
            // Third Icon
            // Padding(
            //   padding: EdgeInsets.symmetric(vertical: verticalPadding),
            //   child: FittedBox(
            //     child: SizedBox(
            //       height: minimumSize,
            //       width: minimumSize,
            //       child: Image.asset(
            //         'assets/BMWlogo.png', // Replace with your right image path
            //         fit: BoxFit.contain,
            //       ),
            //     ),
            //   ),
            // ),

            Padding(
              padding: EdgeInsets.symmetric(vertical: verticalPadding),
              child: FittedBox(
                child: SizedBox(
                  height: minimumSize,
                  width: minimumSize,
                  child: Text("AUTOSAR Chat Bot",style: TextStyle(
                    color: Colors.black,
                    fontSize: screenWidth * 0.017,  // Optional: Adjust font size if needed
                    fontFamily: FontNames.fontFamilyNameMono,
                    fontWeight: FontWeight.bold
                  ),
                  ),
                ),
              ),
            ),
            SizedBox(height: verticalPadding),
            Center(child: DropdownAbove(
              onSelected: (String value) {
                print('the selected option is : $value');
                Provider.of<SelectedVersionProvider>(context, listen: false)
                    .updateSelectedVersion(value);
              },
            ),
            ),
 
          ],
        ),
      ),
    );
  }
}
