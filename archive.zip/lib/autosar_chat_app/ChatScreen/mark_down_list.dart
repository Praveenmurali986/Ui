import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:login_signup_page/autosar_chat_app/ChatScreen/strings.dart';
import 'package:login_signup_page/autosar_chat_app/ChatScreen/theme.dart';

class MarkdownStyles {
  static MarkdownStyleSheet getMarkdownStyleSheet(
      bool isDarkMode, BuildContext context) {
    final Color textColor =
        isDarkMode ? const Color.fromARGB(255, 216, 211, 211) : Colors.black;
    final Color blockquoteColor = isDarkMode ? Colors.grey[300]! : Colors.black;
    final Color codeColor = isDarkMode ? Colors.white : Colors.black;
    final Color codeBackgroundColor =
        isDarkMode ? Colors.black : AppTheme.lightPrimaryColor!;

    final double screenWidth = MediaQuery.of(context).size.width;

    // Calculate the base font size
    double baseFontSize = (screenWidth / 80).clamp(8, 24.0);

    return MarkdownStyleSheet(
      p: TextStyle(
          fontSize: baseFontSize, // Adjusted font size
          fontWeight: FontWeight.w400,
          color: textColor,
          fontFamily: FontNames.fontFamilyName),
      h1: TextStyle(
          fontSize: baseFontSize * 1.5, // 1.5 times the base size
          fontWeight: FontWeight.bold,
          color: isDarkMode ? Colors.white : Colors.blueAccent,
          fontFamily: FontNames.fontFamilyName),
      h2: TextStyle(
          fontSize: baseFontSize * 1.4, // 1.4 times the base size
          fontWeight: FontWeight.bold,
          color: isDarkMode ? Colors.white70 : Colors.blue,
          fontFamily: FontNames.fontFamilyName),
      h3: TextStyle(
          fontSize: baseFontSize * 1.3, // 1.3 times the base size
          fontWeight: FontWeight.bold,
          color: isDarkMode ? Colors.white60 : Colors.black87,
          fontFamily: FontNames.fontFamilyName),
      h4: TextStyle(
          fontSize: baseFontSize * 1.2, // 1.2 times the base size
          fontWeight: FontWeight.w600,
          color: textColor,
          fontFamily: FontNames.fontFamilyName),
      h5: TextStyle(
          fontSize: baseFontSize * 1.1, // 1.1 times the base size
          fontWeight: FontWeight.w500,
          color: textColor,
          fontFamily: FontNames.fontFamilyName),
      h6: TextStyle(
          fontSize: baseFontSize, // Same as base size
          fontWeight: FontWeight.w400,
          color: textColor,
          fontFamily: FontNames.fontFamilyName),
      blockquote: TextStyle(
          fontSize: baseFontSize, // Same as base size
          fontWeight: FontWeight.w400,
          color: blockquoteColor,
          fontFamily: FontNames.fontFamilyName),
      strong: TextStyle(
          fontSize: baseFontSize, // Same as base size
          fontWeight: FontWeight.bold,
          color: textColor,
          fontFamily: FontNames.fontFamilyName),
      em: TextStyle(
          fontSize: baseFontSize, // Same as base size
          fontStyle: FontStyle.italic,
          color: textColor,
          fontFamily: FontNames.fontFamilyName),
      code: TextStyle(
          fontSize: baseFontSize * 0.9, // Slightly smaller than base size
          fontWeight: FontWeight.w600,
          fontFamily: FontNames.fontFamilyNameMono,
          color: codeColor),
      listBullet: TextStyle(
          fontSize: baseFontSize, // Same as base size
          color: textColor,
          fontFamily: FontNames.fontFamilyName),
      // Add styles for code blocks
      codeblockDecoration: BoxDecoration(
        color: codeBackgroundColor, // Background color for code blocks
        borderRadius: BorderRadius.circular(4), // Optional: rounded corners
      ),
      codeblockPadding:
          const EdgeInsets.all(8), // Padding inside the code block
    );
  }
}
