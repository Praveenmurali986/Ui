import 'package:flutter/material.dart';

class DropdownAbove extends StatefulWidget {
  final ValueChanged<String> onSelected; // Callback to pass the selected value

  DropdownAbove(
      {required this.onSelected}); // Constructor to accept the callback

  @override
  _DropdownAboveState createState() => _DropdownAboveState();
}

class _DropdownAboveState extends State<DropdownAbove> {
  String? selectedValue = 'R24-11'; // Set default option here

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        PopupMenuButton<String>(
          onSelected: (String value) {
            setState(() {
              selectedValue = value;
            });
            widget
                .onSelected(value); // Call the callback with the selected value
          },
          itemBuilder: (BuildContext context) {
            return {'R24-11', 'R23-11'}.map((String choice) {
              return PopupMenuItem<String>(
                value: choice,
                child: Text(choice),
              );
            }).toList();
          },
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey),
              borderRadius: BorderRadius.circular(5),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(selectedValue ?? 'Select an option'),
                Icon(Icons.arrow_drop_down),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
