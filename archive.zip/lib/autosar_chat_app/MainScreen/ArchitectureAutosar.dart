import 'package:flutter/material.dart';
 
class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});
 
  @override
  _MyHomePageState createState() => _MyHomePageState();
}
 
class _MyHomePageState extends State<MyHomePage> {
  // Function to divide container names into three groups
  List<List<String>> divideContainers(List<String> containerNames) {
    return [
      containerNames.sublist(0, 3), // First 3 containers
      containerNames.sublist(3, 15), // Next 12 containers
      containerNames.sublist(15, 18), // Last 3 containers
    ];
  }
 
  bool _isHovered = false;
  int? _hoveredIndex;
 
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        // Get the screen height and width from constraints
        double screenHeight = constraints.maxHeight;
        double screenWidth = constraints.maxWidth;
 
        // Define the height of top containers, bottom container
        double topContainerHeight = screenHeight * 0.12; // 12% of screen height
        double bottomContainerHeight =
            screenHeight * 0.08; // 8% of screen height
 
        double bigContainerSize = (screenHeight * 0.1).clamp(50, 100);
        double mediumContainerSize = (screenHeight * 0.1).clamp(50, 100);
        double smallContainerSize = (screenHeight * 0.1).clamp(50, 100);
 
        List<String> containerNames = [
          'System\n Services',
          'Onboard\nDevice\nAbstraction',
          'Microcon-\ntroller\nDrivers',
          'Memory Services',
          'Crypto\n Services',
          'Off Board\nCommunication\nServices',
          'Communication Services',
          'Memory\nHardware\nAbstraction',
          'Crypto\nHardware\nAbstraction',
          'Wireless\nCommunication\nHardware\nAbstraction',
          'Communication\nHardware\nAbstraction',
          'Memory\nDrivers',
          'Crypto\nDrivers',
          'Wireless Communication Drivers',
          'Communication\nDrivers',
          'I/O\nHardware\nAbstraction',
          'I/O Drivers',
          'Complex\n Drivers',
        ];
 
        // Divide the containers into three groups
        List<List<String>> dividedContainers = divideContainers(containerNames);
 
        return Scaffold(
          body: Padding(
            padding: const EdgeInsets.all(30.0), // Padding for the entire UI
            child: Column(
              children: [
                // Top two containers
                MouseRegion(
                  onEnter: (_) => setState(() {
                    _isHovered = true;
                  }),
                  onExit: (_) => setState(() {
                    _isHovered = false;
                  }),
                  child: GestureDetector(
                    onTap: () => {
                      Navigator.pushNamed(context, '/second',
                          arguments: 'Application Layer')
                    },
                    child: Container(
                      width: double.infinity,
                      height: topContainerHeight,
                      decoration: BoxDecoration(
                        color: _isHovered ? Colors.grey : Colors.white,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(
                            screenWidth * 0.015), // Rounded corners
                      ),
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment
                              .center, // Center the row contents
                          children: [
                            Spacer(),
                            Text(
                              'Application Layer',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: screenWidth * 0.011,
                              ),
                            ),
                            Spacer(), // Add some space between the text and the icon
                            Icon(
                              Icons.navigate_next_rounded,
                              size: screenWidth * 0.03,
                              color: _isHovered ? Colors.white : Colors.black,
                            ),
                            SizedBox(width: screenWidth * 0.02),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: screenHeight * 0.010),
                Container(
                  width: double.infinity,
                  height: topContainerHeight,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: Colors.red),
                    borderRadius: BorderRadius.circular(
                        screenWidth * 0.015), // Rounded corners
                  ),
                  child: Center(
                      child: Text('Runtime Environment',
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: screenWidth * 0.011))),
                ),
                SizedBox(height: screenHeight * 0.010),
 
                // Main layout with staggered containers
                Expanded(
                  child: Row(
                    children: [
                      // Left staggered containers (3)
                      buildLeftContainers(context, screenHeight, screenWidth,
                          dividedContainers[0]),
 
                      SizedBox(width: screenWidth * 0.010),
 
                      // Center containers (12)
                      buildCenterContainers(context, screenHeight, screenWidth,
                          dividedContainers[1]),
 
                      SizedBox(width: screenWidth * 0.010),
 
                      // Right staggered containers (3)
                      buildRightContainers(
                          context,
                          screenHeight,
                          screenWidth,
                          mediumContainerSize,
                          smallContainerSize,
                          dividedContainers[2]),
                    ],
                  ),
                ),
 
                SizedBox(width: screenHeight * 0.01),
                // Bottom container
                Container(
                  width: double.infinity,
                  height: bottomContainerHeight,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: Colors.black),
                    borderRadius: BorderRadius.circular(
                        screenWidth * 0.015), // Rounded corners
                  ),
                  child: Center(
                      child: Text('Microcontroller',
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: screenWidth * 0.011))),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
 
  // Function to build left staggered containers (3)
  Widget buildLeftContainers(BuildContext context, double screenHeight,
      double screenWidth, List<String> containers) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        // Left big container
        GestureDetector(
          onTap: () {
            showDialog(
              context: context,
              builder: (BuildContext context) {
                return AlertDialog(
                  title: Text('You tapped on ${containers[0]}'),
                  content: Text('This is ${containers[0]}'),
                  actions: [
                    TextButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      child: const Text('OK'),
                    ),
                  ],
                );
              },
            );
          },
          child: Container(
            height: screenHeight, // Adjust height as needed
            width: screenWidth * 0.10, // Adjust width as needed
            margin: EdgeInsets.only(bottom: screenHeight * 0.055),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: Colors.green),
              borderRadius: BorderRadius.circular(screenWidth * 0.015),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  spreadRadius: 2,
                  blurRadius: 5,
                ),
              ],
            ),
            child: Center(
              child: Text(
                containers[0],
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Colors.black, fontSize: screenWidth * 0.011),
              ),
            ),
          ),
        ),
        SizedBox(width: screenWidth * 0.010),
        // Column for the three left containers
        Column(
          children: [
            // Top container (System Service)
            GestureDetector(
              onTap: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Text('You tapped on System Service'),
                      content: Text('This is System Service'),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          child: const Text('OK'),
                        ),
                      ],
                    );
                  },
                );
              },
              child: Container(
                height:
                    screenHeight * 0.163, // Set height for the small containers
                width: screenWidth * 0.10, // Adjust width as needed
                margin: EdgeInsets.only(bottom: screenHeight * 0.009),
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(color: Colors.green),
                  borderRadius: BorderRadius.circular(screenWidth * 0.015),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      spreadRadius: 2,
                      blurRadius: 5,
                    ),
                  ],
                ),
                child: Center(
                  child: Text(
                    'System Service',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Colors.black, fontSize: screenWidth * 0.011),
                  ),
                ),
              ),
            ),
            SizedBox(height: screenHeight * 0.006), // Space between containers
            // Second and third containers
            for (int i = 1; i < 3; i++)
              GestureDetector(
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: Text('You tapped on ${containers[i]}'),
                        content: Text('This is ${containers[i]}'),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            child: const Text('OK'),
                          ),
                        ],
                      );
                    },
                  );
                },
                child: Container(
                  height: screenHeight *
                      0.16, // Same height for all small containers
                  width: screenWidth * 0.10, // Adjust width as needed
                  margin: EdgeInsets.only(bottom: screenHeight * 0.015),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: Colors.green),
                    borderRadius: BorderRadius.circular(screenWidth * 0.015),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        spreadRadius: 2,
                        blurRadius: 5,
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      containers[i],
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.black, fontSize: screenWidth * 0.011),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ],
    );
  }
 
  // Function to build center containers (12)
  Widget buildCenterContainers(BuildContext context, double screenHeight,
      double screenWidth, List<String> containers) {
    return Expanded(
      child: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 4,
          crossAxisSpacing: screenHeight * 0.015,
          mainAxisSpacing: screenHeight * 0.015,
          childAspectRatio: (screenWidth * 1) / (screenHeight * 1.3),
        ),
        itemCount: containers.length,
        itemBuilder: (context, index) {
          return MouseRegion(
            onEnter: (_) => setState(() {
              _hoveredIndex = index;
              // print("hover index is : $_hoveredIndex");
            }),
            onExit: (_) => setState(() {
              _hoveredIndex = null;
            }),
            child: GestureDetector(
              onTap: () {
                if (containers[index] == "Communication Services" ||
                    containers[index] == "Memory Services") {
                  Navigator.pushNamed(
                    context,
                    '/second',
                    arguments: containers[index], // Passing the argument
                  );
                } else {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: Text('You tapped on ${containers[index]}'),
                        content: Text('This is ${containers[index]}'),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            child: const Text('OK'),
                          ),
                        ],
                      );
                    },
                  );
                }
              },
              child: SizedBox(
                width: screenHeight * 0.1,
                height: screenHeight * 0.1,
                child: Container(
                  decoration: BoxDecoration(
                    color: _hoveredIndex == index &&
                            (containers[index] == 'Memory Services' ||
                                containers[index] == 'Communication Services')
                        ? Colors.green
                        : Colors.white,
                    border: Border.all(color: Colors.green),
                    borderRadius: BorderRadius.circular(screenWidth * 0.015),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        spreadRadius: 2,
                        blurRadius: 5,
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        containers[index],
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black, fontSize: screenWidth * 0.011),
                      ),
                      SizedBox(height: 8), // Space between text and button
                      if (containers[index] == 'Memory Services' ||
                          containers[index] ==
                              'Communication Services') // Show button only for specific containers
                        TextButton(
                          onPressed: () {
                            // Define the action for the button here
                            Navigator.pushNamed(
                              context,
                              '/second',
                              arguments:
                                  containers[index], // Passing the argument
                            );
                          },
                          child: Icon(
                            Icons.navigate_next_rounded,
                            size: screenWidth * 0.03,
                            color: _hoveredIndex == index
                                ? Colors.white
                                : Colors.black,
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
 
  // Function to build right staggered containers (3)
  Widget buildRightContainers(
      BuildContext context,
      double screenHeight,
      double screenWidth,
      double mediumContainerSize,
      smallContainerSize,
      List<String> containers) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        // Column for the two right containers
        Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            // Top container (height of 2 small containers)
            GestureDetector(
              onTap: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Text('You tapped on ${containers[0]}'),
                      content: Text('This is ${containers[0]}'),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          child: const Text('OK'),
                        ),
                      ],
                    );
                  },
                );
              },
              child: Container(
                height: screenHeight * 0.335, // Adjust height as needed
                width: screenWidth * 0.10, // Adjust width as needed
                margin: EdgeInsets.only(
                    top: screenHeight * 0.002, bottom: screenHeight * 0.004),
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(color: Colors.green),
                  borderRadius: BorderRadius.circular(screenWidth * 0.015),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      spreadRadius: 2,
                      blurRadius: 5,
                    ),
                  ],
                ),
                child: Center(
                  child: Text(
                    containers[0],
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Colors.black, fontSize: screenWidth * 0.011),
                  ),
                ),
              ),
            ),
            SizedBox(height: screenHeight * 0.006), // Space between containers
            // Bottom container (height of 1 small container)
            GestureDetector(
              onTap: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Text('You tapped on ${containers[1]}'),
                      content: Text('This is ${containers[1]}'),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          child: const Text('OK'),
                        ),
                      ],
                    );
                  },
                );
              },
              child: Container(
                height: screenHeight * 0.156, // Adjust height as needed
                width: screenWidth * 0.10, // Adjust width as needed
                margin: EdgeInsets.only(
                    top: screenHeight * 0.006, bottom: screenHeight * 0.006),
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(color: Colors.green),
                  borderRadius: BorderRadius.circular(screenWidth * 0.015),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      spreadRadius: 2,
                      blurRadius: 5,
                    ),
                  ],
                ),
                child: Center(
                  child: Text(
                    containers[1],
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Colors.black, fontSize: screenWidth * 0.011),
                  ),
                ),
              ),
            ),
          ],
        ),
        SizedBox(width: screenWidth * 0.010),
        // Right big container (height of 3 small containers)
        GestureDetector(
          onTap: () {
            showDialog(
              context: context,
              builder: (BuildContext context) {
                return AlertDialog(
                  title: Text('You tapped on ${containers[2]}'),
                  content: Text('This is ${containers[2]}'),
                  actions: [
                    TextButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      child: const Text('OK'),
                    ),
                  ],
                );
              },
            );
          },
          child: Container(
            height: screenHeight, // Adjust height as needed
            width: screenWidth * 0.10, // Adjust width as needed
            margin: EdgeInsets.only(bottom: screenHeight * 0.061),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: Colors.green),
              borderRadius: BorderRadius.circular(screenWidth * 0.015),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  spreadRadius: 2,
                  blurRadius: 5,
                ),
              ],
            ),
            child: Center(
              child: Text(
                containers[2],
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Colors.black, fontSize: screenWidth * 0.011),
              ),
            ),
          ),
        ),
      ],
    );
  }
}