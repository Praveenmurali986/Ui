import 'package:flutter/material.dart';

class ClassicPlatformScreen extends StatelessWidget {
  const ClassicPlatformScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Classic Platform'),
        titleTextStyle: const TextStyle(
          fontSize: 32,
          fontWeight: FontWeight.bold,
          color: Colors.grey,
        ),
      ),
      body: const Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'About',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16),
            Text(
              '• The AUTOSAR Classic Platform architecture distinguishes between three software layers running on a microcontroller:',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 8),
            Text(
              '• Application Software Layer: Mostly hardware independent.',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              '• Runtime Environment (RTE):',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              '• Facilitates communication between software components.',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              '• Provides access to Basic Software (BSW).',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              '• Represents the full interface for applications.',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              '• Basic Software (BSW):',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              '• Divided into three major layers and complex drivers:',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              '• Services: Further divided into functional groups for system, memory, and communication services.',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              '• ECU (Electronic Control Unit) Abstraction.',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              '• Microcontroller Abstraction.',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 16),
            Text(
              'Key Features:',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            Text(
              '• Scalability: Supports a wide range of applications from simple to complex.',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              '• Modularity: Allows for easy integration of new components.',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              '• Standardization: Provides a common framework for automotive software development.',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}
