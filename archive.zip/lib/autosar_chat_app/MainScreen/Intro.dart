import 'package:flutter/material.dart';
import 'package:login_signup_page/autosar_chat_app/MainScreen/ArchitectureAutosar.dart';
import 'package:login_signup_page/autosar_chat_app/MainScreen/ClassicPlatformScreen.dart';

class ScrollableScreen extends StatelessWidget {
  const ScrollableScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize:
            Size.fromHeight(40), // Set the height of the AppBar

        child: Container(
          // padding: const EdgeInsets.only(left: 16.0), // Add left padding
          child: AppBar(
            backgroundColor: Colors.transparent,
            title: const Text('AUTOSAT CHATBOT'),
            titleTextStyle:
                const TextStyle(fontWeight: FontWeight.w400, fontSize: 35),
          ),
        ),
      ),
      body: SingleChildScrollView(
        // Make the body scrollable
        child: Padding(
          padding: const EdgeInsets.all(36.0), // Add padding from all sides
          child: Column(
            children: [
              // ClassicPlatformScreen with a fixed height
              SizedBox(
                height: MediaQuery.of(context).size.height *
                    1, // 100% of screen height
                child: const ClassicPlatformScreen(),
              ),

              // MyHomePage with a fixed height
              SizedBox(
                height: MediaQuery.of(context).size.height *
                    1, // 100% of screen height
                child: const MyHomePage(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
