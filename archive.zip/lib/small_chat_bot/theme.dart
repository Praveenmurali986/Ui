import 'package:flutter/material.dart';

class AppTheme {
  // Light Theme Colors
  static const Color lightPrimaryColor = Color.fromARGB(255, 186, 225, 254);
  static const Color lightSecondaryColor = Color.fromARGB(255, 180, 197, 227);
  static const Color lightBackgroundColor = Color.fromARGB(255, 244, 249, 255);
  static const Color lightTextColor = Colors.black;
  static const Color lightShadowColor = Colors.grey;
  static const Color lightUploadIconColor = Colors.white;
  static const Color lightUploadIconBackgroundColor =
      Color.fromARGB(255, 52, 171, 255);
  static const Color lightGradientStartColor = Color.fromARGB(255, 36, 51, 136);
  static const Color lightGradientEndColor = Color.fromARGB(255, 111, 132, 177);
  static const Color lightSidebarColor = Color.fromARGB(255, 13, 102, 175);
  static const Color lightSidebarTextColor = Colors.white;
  static const Color lightPromptAreaColor = Colors.white;

  // Dark Theme Colors
  static const Color darkPrimaryColor =
      Color.fromARGB(255, 40, 92, 170); // Darker Blue
  static const Color darkSecondaryColor = Color(0xFFB0BEC5); // Grey
  static const Color darkBackgroundColor =
      Color(0xFF1E1E1E); // Slightly lighter dark background
  static const Color darkTextColor = Colors.black; // White text
  static const Color darkShadowColor = Color(0xFF1F1F1F); // Dark shadow
  static const Color darkUploadIconColor =
      Color(0xFFBBDEFB); // Light Blue for contrast
  static const Color darkUploadIconBackgroundColor =
      Color(0xFF0D47A1); // Darker Blue
  static const Color darkGradientStartColor =
      Color.fromARGB(255, 53, 52, 52); // Dark gradient start
  static const Color darkGradientEndColor =
      Color.fromARGB(255, 65, 62, 62); // Dark gradient end
  static const Color darkSidebarColor = Color(0xFF0D47A1); // Darker Blue
  static const Color darkSidebarTextColor = Colors.white; // White
  static const Color darkPromptAreaColor = Color(0xFFB0BEC5); // Light Grey
  // White sidebar text color

  // Light Theme
  static ThemeData get lightTheme {
    return ThemeData(
      primaryColor: lightPrimaryColor,
      scaffoldBackgroundColor: lightBackgroundColor,
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: lightTextColor),
        bodyMedium: TextStyle(color: lightTextColor),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: lightPrimaryColor,
        titleTextStyle: TextStyle(color: lightTextColor),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          foregroundColor: lightTextColor,
          backgroundColor: lightPrimaryColor,
        ),
      ),
    );
  }

  // Dark Theme
  static ThemeData get darkTheme {
    return ThemeData(
      primaryColor: darkPrimaryColor,
      scaffoldBackgroundColor: darkBackgroundColor,
      textTheme: const TextTheme(
        bodyLarge: TextStyle(color: darkTextColor),
        bodyMedium: TextStyle(color: darkTextColor),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: darkPrimaryColor,
        titleTextStyle: TextStyle(color: darkTextColor),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          foregroundColor: darkTextColor,
          backgroundColor: darkPrimaryColor,
        ),
      ),
    );
  }
}
