class FontNames {
  static const fontFamilyName = 'Roboto';
  static const fontFamilyNameMono = 'mono';
}

class PortURL {
  // static const baseURL = 'http://172.30.8.85:9005';
  static const baseURL = 'http://172.18.14.2:9026';
  static const baseSocketURL = 'ws://172.18.14.2:9809/ws/chat';
}

