import 'dart:async'; // Import StreamController
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
// import 'package:login_signup_page/small_chat_bot/Api_service.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:login_signup_page/small_chat_bot/Api_web_socket_service.dart';
import 'package:login_signup_page/small_chat_bot/mark_down_list_pop.dart';
import 'package:login_signup_page/small_chat_bot/theme.dart';
import 'dart:typed_data';

class ChatSection extends StatefulWidget {
  const ChatSection({super.key});

  @override
  _ChatSectionState createState() => _ChatSectionState();
}

class _ChatSectionState extends State<ChatSection> {
  final TextEditingController _controller = TextEditingController();
  final List<Map<String, dynamic>> _messages = [];
  List<String?>? _uploadedFileNames;
  List<Uint8List?>? _uploadedFiles;
  int currentIndex = 0;

  @override
  void initState() {
    super.initState();
    currentIndex = 0;

    // Add the bot's default message when the chat starts
    setState(() {
      _messages.add({
        'role': 'assistant',
        'content': 'Hi there! You\'re now chatting with the LiLA. What can I help you with?', 
      });
    });
  }

  // final ApiService apiService = ApiService(PortURL.baseURL);

    //       setState(() {
  //         _messages.add(
  //             {'role': 'assistant', 'content': 'Files uploaded successfully'});
  //       });

  void _handleSendMessage(String clickedMessage) {
    final String userMessage = _controller.text.trim();
    if (userMessage.isNotEmpty) {
      setState(() {
        _messages.add({'role': 'User ', 'content': userMessage});
      });
      _controller.clear();
      _getAIDAResponse(userMessage, clickedMessage);
    }
  }

  void _getAIDAResponse(String userMessage, String clickedMessage) async {
    if (userMessage.isEmpty) {
      String response = "Please enter a message.";

      setState(() {
        _messages.add({'role': 'assistant', 'content': response});
      });
    } else {
      try {
        WebSocketService webSocketService = WebSocketService();

        String partialResponse = '';

        setState(() {
          _messages.add({
            'role': 'assistant',
            'content': partialResponse,
          });
        });

        // print("clicked message is : $clickedMessage");

        String jsonMessage =
            '{"messages": [{"role": "user", "content": "$userMessage"}]}';

        webSocketService.channel.sink.add(jsonMessage);

        await for (var data in webSocketService.stream) {
          webSocketService.addToCurrentUserData(data);
          partialResponse = webSocketService.currentUserData;

          // print(partialResponse);

          setState(() {
            if (_messages[_messages.length - 1]['role'] == 'assistant') {
              _messages[_messages.length - 1]['content'] = partialResponse;
            }
          });
          await Future.delayed(
              Duration(milliseconds: 150)); // Adjust delay as needed
        }
        // print('Final Response: $partialResponse');
        webSocketService.dispose();
      } catch (e) {
        setState(() {
          _messages.add({'role': 'assistant', 'content': 'Error: $e'});
        });
      }
    }
  }

  void _uploadFiles() async {
    print("this file is calling ");
    FilePickerResult? result =
        await FilePicker.platform.pickFiles(allowMultiple: true);
    if (result != null) {
      setState(() {
        _uploadedFileNames = result.files.map((file) => file.name).toList();
        _uploadedFiles = result.files.map((file) => file.bytes).toList();
        _messages.add({
          'role': 'User ',
          'content': 'Uploading   : ${_uploadedFileNames!.join(', ')}',
          'files': _uploadedFiles,
        });
        print("this is the file name : $_uploadedFileNames");
        // _sendFiles();
      });
    }
  }

  // void _sendFiles() async {
  //   if (_uploadedFiles != null) {
  //     try {
  //       final files = _uploadedFiles!
  //           .where((file) => file != null)
  //           .map((file) => file!)
  //           .toList();
  //       final response = await apiService.sendFiles(
  //         files,
  //       );
  //       setState(() {
  //         _messages.add(
  //             {'role': 'assistant', 'content': 'Files uploaded successfully'});
  //       });
  //     } catch (e) {
  //       setState(() {
  //         _messages.add(
  //             {'role': 'assistant', 'content': 'Error uploading files: $e'});
  //       });
  //     }
  //     setState(() {
  //       _uploadedFiles = null;
  //       _uploadedFileNames = null;
  //     });
  //   }
  // }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // final themeNotifier = Provider.of<ThemeNotifier>(context);
    // final isDarkMode = themeNotifier.isDarkMode;

    final double screenWidth = MediaQuery.of(context).size.width;
    final double screenHeight = MediaQuery.of(context).size.height;


    double fontSize = (screenWidth / 90).clamp(
        8.0, 24.0); // Reduced divisor and min size // Increased min font size
    double iconSize =
        (screenWidth / 20).clamp(24.0, 32.0); // Increased icon size

    return Container(
      padding: EdgeInsets.all(screenWidth * 0.0001), // Increased padding
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: const BorderRadius.all(
          Radius.circular(30.0),
        ),
      ),
      child: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final message = _messages[index];
                final isUser =
                    message['role'] == 'User '; // Corrected role check

                return Align(
                  alignment:
                      isUser ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    padding: EdgeInsets.all(
                        screenWidth * 0.004), // Increased padding
                    margin: const EdgeInsets.symmetric(
                        vertical: 8, horizontal: 12), // Increased margin
                    decoration: BoxDecoration(
                        color: isUser
                            ? (  const Color.fromARGB(255, 67, 190, 247))
                            : ( Colors.white),
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.3),
                            offset: const Offset(0, 1),
                            blurRadius: 1,
                            spreadRadius: 1,
                          ),
                        ]),
                    child: isUser    
    ? SelectableText( // User's message
        message['content'],
        style: TextStyle(
          fontSize: fontSize,
          color: Colors.white,
        ),
      )
    : MarkdownBody( // Bot's response
        selectable: true,
        data: message['content'],
        styleSheet: MarkdownStyles.getMarkdownStyleSheet(false, context),
      ),
                  ),
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.all(1),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10.0),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withAlpha(22),
                  blurRadius: 5,
                  spreadRadius: 5,
                ),
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    cursorHeight: fontSize,
                    style: TextStyle(
                      fontSize: fontSize,
                      color: AppTheme.lightTextColor,
                    ),
                    decoration: InputDecoration(
                      hintText:"Type a message....",
                      hintStyle: TextStyle(
                        fontSize: fontSize,
                        color: AppTheme.lightTextColor.withOpacity(0.5),
                      ),
                      border: InputBorder.none,
                      filled: true,
                      fillColor: AppTheme.lightPromptAreaColor,
                      contentPadding: const EdgeInsets.symmetric(
                          vertical: 12, horizontal: 16), // Adjusted padding
                    ),
                    onSubmitted: (value) {
                      _handleSendMessage(value);
                    },
                  ),
                ),
                const SizedBox(width: 8),
                Row(
                  children: [
                    // IconButton(
                    //   icon: const Icon(Icons.file_upload_outlined),
                    //   iconSize: iconSize,
                    //   onPressed: _uploadFiles,
                    // ),
                    IconButton(
                      icon: const Icon(Icons.send),
                      iconSize: iconSize,
                      color: Colors.lightBlue,
                      onPressed: () {
                        _handleSendMessage(_controller.text);
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
