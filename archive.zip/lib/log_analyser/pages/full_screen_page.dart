import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';


class MarkdownDisplayPage extends StatelessWidget 
{

  final String markdownData;
  final String type;
  const MarkdownDisplayPage({Key? key, required this.markdownData, required this.type}) : super(key: key);

  String _getTitle() {

    switch (type) {
      case 'rule':
        return 'Generated Result';
      case 'report':
        return 'Generated Result';
      default:
        return 'Generated Result';
    }

  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_getTitle()),
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Container(
          height: MediaQuery.of(context).size.height - 100, // Adjust height as needed
          child: HtmlWidget(
                markdownData,
                
              ),
        ),
      ),
    );
  }

}