import 'dart:async';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:login_signup_page/log_analyser//utils/app_colors.dart';  // Import colors from app_colors.dart
import 'package:flutter_svg/flutter_svg.dart';  // Import for SVG support
import 'package:login_signup_page/log_analyser/widgets/custom_tab_bar.dart';
import 'package:login_signup_page/log_analyser/widgets/tab_content.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  Uint8List? _fileBytes1;
  String? _fileName1;
  Uint8List? _fileBytes2;
  String? _fileName2;
  String? _comparisonResult;
  bool _isLoading = false; // Loading state
  Timer? _timer; // Timer variable
  int _elapsedTime = 0; // Elapsed time in seconds
  // Define colors for each tab
  final List<Color> tabBackgroundColors = [
    AppColors.appBarBackground,  // Background for Option 1
    AppColors.appBarBackground,  // Background for Option 2
  ];

  @override
  void initState() {
    super.initState();
    // Initialize the TabController
    _tabController = TabController(length: 1, vsync: this);  // Length set to 2 to match tabs count
    // Listen for tab changes to update the background color of the header
    _tabController.addListener(() {
      setState(() {}); // Update UI when the tab is changed
    });
  }

  

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    // Get screen width and height using MediaQuery
    double screenHeight = MediaQuery.of(context).size.height;
    double screenWidth = MediaQuery.of(context).size.width;

    // Adjust padding dynamically based on the screen size for better scalability
    double horizontalPadding = screenWidth * 0.02;
    double verticalPadding = screenHeight * 0.015;
    double tabHorizontalPadding = screenWidth * 0.02;  // Add extra padding inside tab
    double tabVerticalPadding = screenHeight * 0.01;  // Add extra vertical padding for tab

    // Determine header background color based on the selected tab
    Color headerBackgroundColor = _tabController.index == 0
        ? AppColors.appBarBackground // Color for Option 1
        : AppColors.appBarBackground; // Color for Option 2

    return Scaffold(
      body: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: horizontalPadding,  // Use scalable horizontal padding
          vertical: verticalPadding,
        ),
        child: Column(
          children: [
            // Custom header with logo and tabs
            Container(
              height: screenHeight * 0.18,  // Adjust header height to better fit content
              padding: EdgeInsets.only(
                left: screenWidth * 0.02,
                right: screenWidth * 0.02,
              ),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(20)),
                color: headerBackgroundColor,  // Background color dynamically set
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start, // Space out logo and tab bar
                crossAxisAlignment: CrossAxisAlignment.end, // Align both elements to the bottom
                children: [
                  Padding(
                    padding: EdgeInsets.only(bottom: screenWidth*0.022, left: screenWidth*0.015),
                    child: SvgPicture.asset(
                      'assets/Lila_Logo.svg',
                      width: screenWidth * 0.05,
                      height: screenWidth * 0.05,
                    ),
                  ),
                  // Add padding between the logo and the new image
                  SizedBox(width: screenWidth * 0.13), // Padding between the logo and new image
                  // Text("Log Analyser"),

                  // // New image (after the logo)
                  // Padding(
                  //   padding: EdgeInsets.only(left: screenWidth*0.015),  // Proper padding below the image
                  //   child: Image.asset(
                  //     'assets/BMWlogo.png',
                  //     width: screenWidth * 0.1,
                  //     height: screenWidth * 0.1,
                  //   ),
                  // ),
                  // SizedBox(width: screenWidth * 0.2),  // Space between image and tab bar
                  // TabBar placed to the right of the logo
                  CustomTabBar(
                    tabController: _tabController,
                    screenWidth: screenWidth,
                    tabVerticalPadding: tabVerticalPadding,
                    tabHorizontalPadding: tabHorizontalPadding,
                  ),
                ],
              ),
            ),
            SizedBox(height: screenHeight * 0.01),  // Add space after the header
            // Tab content area (removing the large box, just showing content)
            TabContent(
              context: context,
              tabController: _tabController,
              screenWidth: screenWidth,
              screenHeight: screenHeight,
            ),            
          ],
        ),
      ),
    );
  }
}
