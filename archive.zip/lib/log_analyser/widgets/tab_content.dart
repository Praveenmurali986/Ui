import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:login_signup_page/log_analyser//utils/app_colors.dart';  // Import colors from app_colors.dart
import 'dart:async';
import 'dart:typed_data';
import 'dart:convert';
import 'package:login_signup_page/log_analyser//utils/methods.dart';
import 'package:http/http.dart' as http;
import 'dart:html' as html;
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:login_signup_page/log_analyser//pages/full_screen_page.dart';
// import 'package:csv/csv.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';



class TabContent extends StatefulWidget {
  final TabController tabController;
  final double screenWidth;
  final double screenHeight;
  final BuildContext context;

  TabContent({
    required this.context,
    required this.tabController,
    required this.screenWidth,
    required this.screenHeight,
  });

  @override
  State<TabContent> createState() => _TabContentState();
}

class _TabContentState extends State<TabContent> {

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  TextEditingController _controller = TextEditingController();
  FocusNode _focusNode = FocusNode();

  Uint8List? _fileBytes1;
  String? _fileName1;
  Uint8List? _fileBytesPcap;
  String? _fileNamePcap;
  Uint8List? _fileBytesRulesFile;
  String? _fileNameRulesFile;
  Uint8List? _fileBytesPcapUploadFile;
  String? _fileNameUploadFile;
  String comparisonResult = '';
  bool _isLoading = false;
  Timer? _timer;
  int _elapsedTime = 0;
  bool _isResultGenerated = false;
  String comparisonResultTopology = '';
  bool _isGeneratingRules = false;
  bool _isGeneratingTopology = false;
  bool _isGeneratingReport = false;
  String reportResult = '';


Future<void> pickFile(int fileNumber) async {
  FilePickerResult? result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf','pcapng','docx','txt']);

  if (result != null && result.files.isNotEmpty) {
    final platformFile = result.files.single;
    if (platformFile.bytes != null) {
      setState(() {
        if (fileNumber == 1) {
          _fileBytes1 = platformFile.bytes;
          _fileName1 = platformFile.name;  // Store file name for file 1
        } 
        else if(fileNumber == 2)
        {
          _fileBytesPcap = platformFile.bytes;
          _fileNamePcap = platformFile.name;
        }
        else if(fileNumber == 3)
        {
          _fileBytesRulesFile = platformFile.bytes;
          _fileNameRulesFile = platformFile.name;
        }
        else if(fileNumber == 4)
        {
          _fileBytesPcapUploadFile = platformFile.bytes;
          _fileNameUploadFile = platformFile.name;
        }
      });
    } else {
      ScaffoldMessenger.of(widget.context).showSnackBar(const SnackBar(
        content: Text('File selected, but bytes are not available.'),
      ));
    }
  } else {
    ScaffoldMessenger.of(widget.context).showSnackBar(const SnackBar(
      content: Text('No file selected. Please try again.'),
    ));
  }
}



Future<void> generateRule() async {
  // Check if a file is selected
  if (_fileName1 == null) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('Please select a file first.'),
    ));
    return;
  }


  if (_isGeneratingRules ) {
    ScaffoldMessenger.of(widget.context).showSnackBar(
      SnackBar(content: Text("Generation in progress. Please wait.")),
    );
    return; // Exit the function if a download is already in progress
  }

  setState(() {
    _isGeneratingRules= true;
    _isLoading = true;
    _elapsedTime = 0;
  });

  // Start the timer to show elapsed time
  _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
    setState(() {
      _elapsedTime++;
    });
  });

  // Construct the URL dynamically using the text from the controller
  // String dynamicContext = Uri.encodeQueryComponent(_controller.text);
  var url = Uri.parse('http://172.18.14.2:7077/log-upload/');

  var request = http.MultipartRequest('POST', url);

  // Add the file to the request
  request.files.add(http.MultipartFile.fromBytes('file1', _fileBytes1!, filename: _fileName1));

  // Add any necessary headers
  request.headers.addAll({'accept': 'application/json'});

  try {
    // Send the request
    var response = await request.send();
    
    // Check if the server responded successfully
    if (response.statusCode == 200) {
      String result = await response.stream.bytesToString();
      // Map<String, dynamic> jsonResponse = jsonDecode(result);
      // var comparisonValue = jsonResponse['response'];

      setState(() {
        comparisonResult = result;
        _isLoading = false;
        _isGeneratingRules = false;
      });
    } else {
      throw Exception('Failed to generate rule: ${response.statusCode}');
    }

  } catch (e) {
    setState(() {
      _isGeneratingRules= false;
      _isLoading = false;
    });
    _timer?.cancel();

    // Show error message
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Error: $e'),
    ));
  }
}

// logic for downloading the file 
void downloadComparisonResult(int value) {
  if(value==1)
  {
    print("downloadComparisonResult1");
    if (comparisonResult.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('No generated result to download.'),
      ));
      return;
    }
    else{
      // Download as Text File
    final blob = html.Blob([comparisonResult], 'text/plain', 'native');
    final url = html.Url.createObjectUrlFromBlob(blob);
    final anchor = html.AnchorElement(href: url)
      ..target = 'blank'
      ..setAttribute('download', 'generated_rules.txt')
      ..click();
    html.Url.revokeObjectUrl(url);
    }
  }
  else if(value==2)
  {
    print("downloadComparisonResult2");
    if (reportResult.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('No report generated to download.'),
      ));
      return;
    }
    else{
      // Download as csv File
    final blob = html.Blob([reportResult], 'text/plain', 'native');
    final url = html.Url.createObjectUrlFromBlob(blob);
    final anchor = html.AnchorElement(href: url)
      ..target = 'blank'
      ..setAttribute('download', 'generated_report.csv')
      ..click();
    html.Url.revokeObjectUrl(url);
    }

  }
    
  }

@override
void dispose() {
  _focusNode.dispose();  // Dispose the focus node when the widget is disposed
  super.dispose();
}

void showFullscreenResult( int value) {

    if(value==1)
    {
      if (comparisonResult.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('No generated result to display.'),
      ));
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MarkdownDisplayPage(markdownData: comparisonResult,type: "rule"),
      ),
    );
    }
    else if(value==2)
    {
      if (reportResult.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('No report generated to display.'),
      ));
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MarkdownDisplayPage(markdownData: reportResult, type: "report",),
      ),
    );
      
    }
    
  }

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: TabBarView(
        controller: widget.tabController,
        children: [
// Content for Option 1 - PCAP Rule Generation
          Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                // First box inside the content for Option 1 with decoration
                Container(
                  width: widget.screenWidth * 0.3,
                  height: widget.screenHeight * 0.77,
                  decoration: BoxDecoration(
                    color: AppColors.appBarBackground, // Box color
                    borderRadius: BorderRadius.all(Radius.circular(15)),  // Rounded corners
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(16),  // Add padding inside the box
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,  // Center the buttons inside the box
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Stack(
                          children: [
                            // ElevatedButton
                            // Replace ElevatedButton with Container
                            Container(
  width: widget.screenWidth * 0.25,
  height: widget.screenHeight * 0.5,
  decoration: BoxDecoration(
    color: Colors.white,  // Background color of the container
    borderRadius: BorderRadius.circular(15),  // Rounded corners
  ),
  child: Stack(
    children: [
      // Image at the center
      Center(
        child: SvgPicture.asset(
          height: widget.screenHeight * 0.1,
          width: widget.screenWidth * 0.06,
          'assets/Drop_button.svg',  // Replace with your image path
          // fit: BoxFit.contain,  // Adjust image to fit within the container
        ),
      ),
      // Text at the bottom
      Positioned(
        bottom: widget.screenHeight*0.008,  // 8px from the bottom edge
        left: 0,
        right: 0,
        child: Text(
          "Drag and drop file",  // Display file name or default text
          textAlign: TextAlign.center,
          style: TextStyle(
            color: const Color.fromARGB(210, 141, 153, 161),
            fontSize: widget.screenWidth*0.0095,
            fontWeight: FontWeight.w100,
          ),
        ),
      ),
      // Text at the top-left corner
      Positioned(
        top: widget.screenHeight*0.008,  // 8px from the top edge
        left: widget.screenWidth*0.008,  // 8px from the left edge
        child: Text(
          _fileName1 ?? "Select File",  // Text at the top-left corner
          style: TextStyle(
            color: const Color.fromARGB(210, 50, 54, 58),
            fontSize: widget.screenWidth*0.012,
            fontWeight: FontWeight.w200,
          ),
        ),
      ),
      // "+" Button positioned on top-right of Container
      Positioned(
        right: widget.screenWidth*0.008,  // 8px from the right edge
        top: widget.screenHeight*0.01,
        // right: 8,  // 8px from the right edge
        // top: 8,    // 8px from the top edge
        child: GestureDetector(
          onTap: () {
            // Define action for the "+" button here
            pickFile(1);
          },
          child: CircleAvatar(
            backgroundColor: Colors.blue,  // Background color of the button
            radius:  widget.screenWidth*0.0155,  // Radius of the circular button
            child: Icon(
              Icons.add,  // "+" icon
              color: Colors.white,  // Icon color
              size: widget.screenWidth*0.02,  // Icon size
            ),
          ),
        ),
      ),
    ],
  ),
),

                          ],
                        ),
                        SizedBox(height: widget.screenHeight * 0.03),  // Space between buttons
                        
                        Center(
  child: Padding(
    padding: EdgeInsets.symmetric(vertical: widget.screenHeight * 0.03),
    child: ElevatedButton(
      
      onPressed: () async {
        // Start the comparison process by setting _isLoading to true
        setState(() {
          if(_controller.text.isNotEmpty)
          {
            _isLoading = true;
          _elapsedTime = 0;  // Reset the elapsed time when the comparison starts
          }
          
        });

        // Call the compareFiles method and wait for the result
        generateRule();

      },
      style: ElevatedButton.styleFrom(
        padding: EdgeInsets.symmetric(
          vertical: widget.screenHeight * 0.04, // Vertical padding
          horizontal: widget.screenWidth * 0.1, // Horizontal padding
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20), // Rounded corners
        ),
        backgroundColor: Colors.blue,
      ),
      child: Text(
        _isLoading 
            ? formatElapsedTime(_elapsedTime)  // Display elapsed time when loading
            : (  // Display comparison result when available
               "Generate"),  // Display "Compare" when not loading
               style: TextStyle(color: Colors.white, fontSize: widget.screenWidth*0.013),
      ),
    ),
  ),
),


                      ],
                    ),
                  ),
                ),
                
                SizedBox(width: widget.screenWidth * 0.01), // Space between boxes
                // Second box inside the content for Option 1 with decoration
                Container(
  width: widget.screenWidth * 0.65,
  height: widget.screenHeight * 0.77,
  decoration: BoxDecoration(
    color: AppColors.appBarBackground, // Box color
    borderRadius: BorderRadius.all(Radius.circular(15)),  // Rounded corners
  ),
  child: Stack(
    children: [
      // Main content of the container (existing content)
      if (comparisonResult.isEmpty)
            Center(
              child: SvgPicture.asset(
                'assets/Generate_Icon.svg',
                width: widget.screenWidth * 0.2,
                height: widget.screenWidth * 0.2,
                color: const Color.fromARGB(210, 163, 212, 247),
              ),
            )
          else
            // Display markdown after the result is loaded
            Container(
              padding: EdgeInsets.all(widget.screenHeight*0.05),
              child: HtmlWidget(
                comparisonResult,
                
              ),
            ),
      
      // Image at the top-right corner
      Positioned(
        top: widget.screenWidth * 0.01,  // Align to the top of the container
        right: widget.screenWidth * 0.01,  // Align to the right of the container
        child: GestureDetector(
          onTap: () {
            showFullscreenResult(1);  // Call the function
          },
          child: Icon(
            Icons.fullscreen,
            size: widget.screenWidth * 0.03,
            color: Colors.grey,
          ),
        ),
      ),


      // Image at the bottom-right corner
      Positioned(
        bottom: widget.screenWidth * 0.01,  // Align to the bottom of the container
        right: widget.screenWidth * 0.01,   // Align to the right of the container
        child: GestureDetector(
          onTap: () {
            downloadComparisonResult(1);  // Call the function
            print("downloadComparisonResult");
          },
          child: Icon(
            Icons.download,
            size: widget.screenWidth * 0.03,
            color: Colors.blue,
          ),
        ),
        // child: Icon(Icons.download,size: widget.screenWidth*0.03,color: Colors.blue,)
      ),
    ],
  ),
)

              ],
            ),
          ),



        ],
      ),
    );
  }
}
