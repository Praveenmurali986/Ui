import 'package:flutter/material.dart';
import 'package:login_signup_page/log_analyser//utils/app_colors.dart';  // Import colors from app_colors.dart
import 'package:flutter_svg/flutter_svg.dart';

class CustomTabBar extends StatelessWidget {
  final TabController _tabController;
  final double screenWidth;
  final double tabVerticalPadding;
  final double tabHorizontalPadding;

  CustomTabBar({
    required TabController tabController,
    required this.screenWidth,
    required this.tabVerticalPadding,
    required this.tabHorizontalPadding,
  }) : _tabController = tabController;

  @override
  Widget build(BuildContext context) {

    final screenHeight = MediaQuery.of(context).size.height;
    return Expanded(
      child: TabBar(
        controller: _tabController,
        labelColor: AppColors.tabSelected,  // Selected tab color
        unselectedLabelColor: AppColors.tabUnselected,  // Unselected tab color
        indicator: BoxDecoration(),  // Completely remove the indicator (underline)
        indicatorWeight: 0,  // Remove underline weight
        indicatorSize: TabBarIndicatorSize.tab,  // Only cover selected tab
        isScrollable: true,
        labelPadding: EdgeInsets.zero,  // Remove any extra padding
        dividerColor: Colors.transparent,
        tabs: [

//Tab 1
          Tab(
            // height: screenHeight*0.1,
  child: Container(
    width: screenWidth*0.25,
    padding: EdgeInsets.symmetric(
      vertical: tabVerticalPadding,  // Increased vertical padding
      horizontal: tabHorizontalPadding,  // Increased horizontal padding
    ),
    decoration: BoxDecoration(
      color: _tabController.index == 0
          ? AppColors.tabSelected  // Change background color when selected
          : AppColors.tabUnselected,
      borderRadius: BorderRadius.only(
        topLeft: Radius.circular(20),
        topRight: Radius.circular(20),
        
      ),  // Rounded corners for tabs
      
    ),
    child: Row(
      // mainAxisSize: MainAxisSize.min,  // Ensure the row takes the minimal width
      children: [
        SizedBox(width: screenWidth*0.01),
        SvgPicture.asset(
          'assets/Generate_Icon.svg',  // Replace with your SVG asset path
          height: screenWidth*0.03,  // Adjust the size as needed
          width: screenWidth*0.03,   // Adjust the size as needed
        ),
        SizedBox(width: screenWidth*0.02),  // Add space between the icon and the text
        Text(
          "Log Analyzer",
          style: TextStyle(
            color: Colors.black,
            fontSize: screenWidth * 0.013,  // Optional: Adjust font size if needed
          ),
        ),
      ],
    ),
  ),
),


        ],
      ),
    );
  }
}
