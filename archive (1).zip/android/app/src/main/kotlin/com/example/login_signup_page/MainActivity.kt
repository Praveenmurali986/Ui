package com.example.login_signup_page

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
